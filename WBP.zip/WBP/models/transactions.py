from datetime import datetime
from decimal import Decimal
from sqlalchemy.dialects.postgresql import JSONB
from app import db
from models.user import User
from services.payment_integration_service import PaymentProvider, TransactionType, TransactionStatus

class Transaction(db.Model):
    """Model for tracking payment transactions."""
    __tablename__ = 'transactions'

    id = db.Column(db.Integer, primary_key=True)
    reference = db.Column(db.String(50), unique=True, nullable=False)
    provider_reference = db.Column(db.String(100), unique=True)
    
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('transactions', lazy=True))
    
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    transaction_type = db.Column(db.Enum(TransactionType), nullable=False)
    provider = db.Column(db.Enum(PaymentProvider), nullable=False)
    status = db.Column(db.Enum(TransactionStatus), nullable=False, default=TransactionStatus.PENDING)
    
    wallet_number = db.Column(db.String(20), nullable=False)
    error_message = db.Column(db.String(500))
    metadata = db.Column(JSONB)
    
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<Transaction {self.reference}>'

class TransactionLog(db.Model):
    """Model for tracking transaction state changes."""
    __tablename__ = 'transaction_logs'

    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey('transactions.id'), nullable=False)
    transaction = db.relationship('Transaction', backref=db.backref('logs', lazy=True))
    
    previous_status = db.Column(db.Enum(TransactionStatus))
    new_status = db.Column(db.Enum(TransactionStatus), nullable=False)
    message = db.Column(db.String(500))
    metadata = db.Column(JSONB)
    
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    def __repr__(self):
        return f'<TransactionLog {self.id} for {self.transaction_id}>'

class UserWallet(db.Model):
    """Model for tracking user's mobile money wallets."""
    __tablename__ = 'user_wallets'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('wallets', lazy=True))
    
    provider = db.Column(db.Enum(PaymentProvider), nullable=False)
    wallet_number = db.Column(db.String(20), nullable=False)
    is_verified = db.Column(db.Boolean, nullable=False, default=False)
    is_primary = db.Column(db.Boolean, nullable=False, default=False)
    
    last_used_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = (
        db.UniqueConstraint('user_id', 'provider', 'wallet_number', name='unique_user_wallet'),
    )

    def __repr__(self):
        return f'<UserWallet {self.wallet_number}>'

class UserBalance(db.Model):
    """Model for tracking user's susu account balance."""
    __tablename__ = 'user_balances'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)
    user = db.relationship('User', backref=db.backref('balance', uselist=False, lazy=True))
    
    available_balance = db.Column(db.Numeric(10, 2), nullable=False, default=0)
    pending_balance = db.Column(db.Numeric(10, 2), nullable=False, default=0)
    total_deposits = db.Column(db.Numeric(10, 2), nullable=False, default=0)
    total_withdrawals = db.Column(db.Numeric(10, 2), nullable=False, default=0)
    
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_transaction_at = db.Column(db.DateTime)

    def __repr__(self):
        return f'<UserBalance {self.user_id}>'
