from datetime import datetime
from enum import Enum
from app import db

class SupportTicketStatus(Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    CLOSED = "closed"

class SupportTicketPriority(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"

class SupportTicketCategory(Enum):
    ACCOUNT = "account"
    PAYMENT = "payment"
    TECHNICAL = "technical"
    FEATURE = "feature"
    OTHER = "other"

class SupportTicket(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    subject = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.Enum(SupportTicketCategory), nullable=False)
    priority = db.Column(db.Enum(SupportTicketPriority), default=SupportTicketPriority.MEDIUM)
    status = db.Column(db.Enum(SupportTicketStatus), default=SupportTicketStatus.OPEN)
    assigned_to = db.Column(db.Integer, db.ForeignKey('user.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    resolved_at = db.Column(db.DateTime)
    
    # Relationships
    user = db.relationship('User', foreign_keys=[user_id], backref='support_tickets')
    agent = db.relationship('User', foreign_keys=[assigned_to], backref='assigned_tickets')
    messages = db.relationship('SupportMessage', backref='ticket', lazy=True)

class SupportMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.Integer, db.ForeignKey('support_ticket.id'), nullable=False)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    is_internal = db.Column(db.Boolean, default=False)  # For internal notes
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    sender = db.relationship('User', backref='support_messages')

class FeedbackCategory(Enum):
    BUG = "bug"
    FEATURE = "feature"
    IMPROVEMENT = "improvement"
    GENERAL = "general"

class FeedbackStatus(Enum):
    NEW = "new"
    UNDER_REVIEW = "under_review"
    PLANNED = "planned"
    IN_PROGRESS = "in_progress"
    IMPLEMENTED = "implemented"
    DECLINED = "declined"

class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.Enum(FeedbackCategory), nullable=False)
    status = db.Column(db.Enum(FeedbackStatus), default=FeedbackStatus.NEW)
    votes = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    implemented_at = db.Column(db.DateTime)
    
    # Relationships
    user = db.relationship('User', backref='feedback')
    comments = db.relationship('FeedbackComment', backref='feedback', lazy=True)
    votes_users = db.relationship('FeedbackVote', backref='feedback', lazy=True)

class FeedbackComment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    feedback_id = db.Column(db.Integer, db.ForeignKey('feedback.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    comment = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='feedback_comments')

class FeedbackVote(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    feedback_id = db.Column(db.Integer, db.ForeignKey('feedback.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='feedback_votes')

class ReferralStatus(Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    EXPIRED = "expired"

class ReferralReward(Enum):
    ACCOUNT_CREDIT = "account_credit"
    SAVINGS_BONUS = "savings_bonus"
    CASHBACK = "cashback"

class Referral(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    referrer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    referred_email = db.Column(db.String(120), nullable=False)
    referred_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    status = db.Column(db.Enum(ReferralStatus), default=ReferralStatus.PENDING)
    reward_type = db.Column(db.Enum(ReferralReward))
    reward_amount = db.Column(db.Numeric(10, 2))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    expires_at = db.Column(db.DateTime)
    
    # Relationships
    referrer = db.relationship('User', foreign_keys=[referrer_id], backref='referrals_made')
    referred = db.relationship('User', foreign_keys=[referred_id], backref='referred_by')

    def is_expired(self):
        """Check if referral has expired."""
        return self.expires_at and self.expires_at < datetime.utcnow()

    def complete_referral(self, referred_user_id):
        """Complete a referral and assign rewards."""
        if self.status != ReferralStatus.PENDING or self.is_expired():
            return False
        
        self.referred_id = referred_user_id
        self.status = ReferralStatus.COMPLETED
        self.completed_at = datetime.utcnow()
        db.session.commit()
        
        # Trigger reward distribution
        return True
