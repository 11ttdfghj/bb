from datetime import datetime
from sqlalchemy.dialects.postgresql import JSONB
from app import db
from services.partnership_service import (
    PartnerType, PartnershipStatus,
    ProductType, ProductStatus
)

class Partner(db.Model):
    """Model for partner organizations."""
    __tablename__ = 'partners'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    partner_type = db.Column(db.Enum(PartnerType), nullable=False)
    status = db.Column(db.Enum(PartnershipStatus), nullable=False, default=PartnershipStatus.PENDING)
    
    contact_info = db.Column(JSONB, nullable=False)
    integration_details = db.Column(JSONB)
    primary_contact_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    primary_contact = db.relationship('User', backref=db.backref('managed_partners', lazy=True))
    
    suspension_reason = db.Column(db.String(500))
    termination_reason = db.Column(db.String(500))
    
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    activated_at = db.Column(db.DateTime)
    suspended_at = db.Column(db.DateTime)
    terminated_at = db.Column(db.DateTime)

    def __repr__(self):
        return f'<Partner {self.name}>'

class PartnerProduct(db.Model):
    """Model for partner-provided financial products."""
    __tablename__ = 'partner_products'

    id = db.Column(db.Integer, primary_key=True)
    partner_id = db.Column(db.Integer, db.ForeignKey('partners.id'), nullable=False)
    partner = db.relationship('Partner', backref=db.backref('products', lazy=True))
    
    product_type = db.Column(db.Enum(ProductType), nullable=False)
    status = db.Column(db.Enum(ProductStatus), nullable=False, default=ProductStatus.DRAFT)
    product_details = db.Column(JSONB, nullable=False)
    
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    activated_at = db.Column(db.DateTime)
    deactivated_at = db.Column(db.DateTime)

    def __repr__(self):
        return f'<PartnerProduct {self.id} by {self.partner.name}>'

class PartnerEvent(db.Model):
    """Model for partner-organized events."""
    __tablename__ = 'partner_events'

    id = db.Column(db.Integer, primary_key=True)
    partner_id = db.Column(db.Integer, db.ForeignKey('partners.id'), nullable=False)
    partner = db.relationship('Partner', backref=db.backref('events', lazy=True))
    
    event_details = db.Column(JSONB, nullable=False)
    event_date = db.Column(db.DateTime, nullable=False)
    location = db.Column(JSONB)
    max_participants = db.Column(db.Integer)
    
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    cancelled_at = db.Column(db.DateTime)

    def __repr__(self):
        return f'<PartnerEvent {self.id} by {self.partner.name}>'

class PartnerEventRegistration(db.Model):
    """Model for event registrations."""
    __tablename__ = 'partner_event_registrations'

    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('partner_events.id'), nullable=False)
    event = db.relationship('PartnerEvent', backref=db.backref('registrations', lazy=True))
    
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('event_registrations', lazy=True))
    
    status = db.Column(db.String(20), nullable=False, default='registered')  # registered, attended, cancelled
    registration_data = db.Column(JSONB)
    
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    cancelled_at = db.Column(db.DateTime)
    
    __table_args__ = (
        db.UniqueConstraint('event_id', 'user_id', name='unique_event_registration'),
    )

    def __repr__(self):
        return f'<EventRegistration {self.id} for {self.event_id}>'

class UserProduct(db.Model):
    """Model for tracking user subscriptions to partner products."""
    __tablename__ = 'user_products'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('partner_products', lazy=True))
    
    product_id = db.Column(db.Integer, db.ForeignKey('partner_products.id'), nullable=False)
    product = db.relationship('PartnerProduct', backref=db.backref('subscriptions', lazy=True))
    
    status = db.Column(db.String(20), nullable=False, default='active')  # active, suspended, terminated
    subscription_details = db.Column(JSONB)
    
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    activated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    suspended_at = db.Column(db.DateTime)
    terminated_at = db.Column(db.DateTime)
    
    __table_args__ = (
        db.UniqueConstraint('user_id', 'product_id', name='unique_user_product'),
    )

    def __repr__(self):
        return f'<UserProduct {self.id} for {self.user_id}>'
