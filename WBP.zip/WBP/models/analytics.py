from database import db
from datetime import datetime

class SavingsProjection(db.Model):
    """Model for savings projections."""
    __tablename__ = 'savings_projections'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    months = db.Column(db.Integer, nullable=False)
    amount = db.Column(db.Float, nullable=False)
    confidence_level = db.Column(db.String(20), nullable=False)  # low, medium, high
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'months': self.months,
            'amount': self.amount,
            'confidence_level': self.confidence_level,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class SavingsInsight(db.Model):
    """Model for savings insights and recommendations."""
    __tablename__ = 'savings_insights'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    type = db.Column(db.String(50), nullable=False)  # consistency, trend, timing, etc.
    message = db.Column(db.Text, nullable=False)
    priority = db.Column(db.String(20), nullable=False)  # low, medium, high
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=True)
    is_dismissed = db.Column(db.Boolean, default=False)

    def to_dict(self):
        return {
            'id': self.id,
            'type': self.type,
            'message': self.message,
            'priority': self.priority,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'is_dismissed': self.is_dismissed
        }

class SavingsMilestone(db.Model):
    """Model for tracking savings milestones and achievements."""
    __tablename__ = 'savings_milestones'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    target_amount = db.Column(db.Float, nullable=False)
    current_amount = db.Column(db.Float, default=0.0)
    achieved_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'target_amount': self.target_amount,
            'current_amount': self.current_amount,
            'progress': (self.current_amount / self.target_amount * 100) if self.target_amount > 0 else 0,
            'achieved_at': self.achieved_at.isoformat() if self.achieved_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class AnalyticsPreference(db.Model):
    """Model for user analytics preferences."""
    __tablename__ = 'analytics_preferences'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)
    enable_projections = db.Column(db.Boolean, default=True)
    enable_insights = db.Column(db.Boolean, default=True)
    enable_milestone_notifications = db.Column(db.Boolean, default=True)
    report_frequency = db.Column(db.String(20), default='monthly')  # daily, weekly, monthly
    preferred_currency = db.Column(db.String(3), default='GHS')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'enable_projections': self.enable_projections,
            'enable_insights': self.enable_insights,
            'enable_milestone_notifications': self.enable_milestone_notifications,
            'report_frequency': self.report_frequency,
            'preferred_currency': self.preferred_currency,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
