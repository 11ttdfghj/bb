from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean, Float, JSON
from sqlalchemy.orm import relationship
from app import db

class UserEducationPreference(db.Model):
    """Model for storing user preferences for educational content."""
    __tablename__ = 'user_education_preferences'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), unique=True)
    preferred_language = Column(String(10), default='en')
    difficulty_level = Column(String(20), default='beginner')
    topics_of_interest = Column(JSON)  # Store topics as JSON array
    notification_preferences = Column(JSON)  # Store notification settings as JSON
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship
    user = relationship('User', backref='education_preferences')

class UserProgress(db.Model):
    """Model for tracking user progress through educational content."""
    __tablename__ = 'user_progress'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    content_id = Column(Integer, ForeignKey('educational_content.id'))
    progress_percentage = Column(Float, default=0)
    completed = Column(Boolean, default=False)
    last_accessed = Column(DateTime, default=datetime.utcnow)
    time_spent = Column(Integer, default=0)  # Time spent in seconds
    quiz_scores = Column(JSON)  # Store quiz scores as JSON
    
    # Relationships
    user = relationship('User', backref='learning_progress')
    content = relationship('EducationalContent')

class UserQuizAttempt(db.Model):
    """Model for tracking user quiz attempts."""
    __tablename__ = 'user_quiz_attempts'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    content_id = Column(Integer, ForeignKey('educational_content.id'))
    score = Column(Float)
    answers = Column(JSON)  # Store user answers as JSON
    started_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)
    
    # Relationships
    user = relationship('User', backref='quiz_attempts')
    content = relationship('EducationalContent')

class UserEngagement(db.Model):
    """Model for tracking user engagement metrics."""
    __tablename__ = 'user_engagement'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), unique=True)
    total_points = Column(Integer, default=0)
    articles_read = Column(Integer, default=0)
    quizzes_completed = Column(Integer, default=0)
    forum_posts = Column(Integer, default=0)
    challenges_completed = Column(Integer, default=0)
    achievements_earned = Column(Integer, default=0)
    last_active = Column(DateTime, default=datetime.utcnow)
    engagement_streak = Column(Integer, default=0)
    
    # Relationship
    user = relationship('User', backref='engagement_metrics')

class LearningPath(db.Model):
    """Model for customized learning paths."""
    __tablename__ = 'learning_paths'

    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    difficulty_level = Column(String(20))
    estimated_duration = Column(Integer)  # Duration in hours
    prerequisites = Column(JSON)  # Store prerequisites as JSON
    content_sequence = Column(JSON)  # Store content IDs in sequence as JSON
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)

class UserLearningPath(db.Model):
    """Model for tracking user progress in learning paths."""
    __tablename__ = 'user_learning_paths'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    path_id = Column(Integer, ForeignKey('learning_paths.id'))
    current_step = Column(Integer, default=0)
    progress_percentage = Column(Float, default=0)
    started_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    user = relationship('User', backref='learning_paths')
    path = relationship('LearningPath')
