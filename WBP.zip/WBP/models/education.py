from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Boolean, Float, JSON
from sqlalchemy.orm import relationship
from app import db

class EducationalContent(db.Model):
    """Model for educational content like articles, guides, and tutorials."""
    __tablename__ = 'educational_content'

    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    content = Column(Text, nullable=False)
    content_type = Column(String(50), nullable=False)  # article, guide, tutorial, video, etc.
    difficulty_level = Column(String(20))  # beginner, intermediate, advanced
    language = Column(String(10), default='en')
    tags = Column(JSON)  # Store tags as JSON array
    author_id = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_published = Column(Boolean, default=False)
    views_count = Column(Integer, default=0)
    likes_count = Column(Integer, default=0)
    
    # Relationships
    author = relationship('User', backref='authored_content')
    comments = relationship('ContentComment', backref='content', cascade='all, delete-orphan')

class ContentComment(db.Model):
    """Model for comments on educational content."""
    __tablename__ = 'content_comments'

    id = Column(Integer, primary_key=True)
    content_id = Column(Integer, ForeignKey('educational_content.id'))
    user_id = Column(Integer, ForeignKey('users.id'))
    comment = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship
    user = relationship('User', backref='content_comments')

class ForumTopic(db.Model):
    """Model for forum topics/categories."""
    __tablename__ = 'forum_topics'

    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    posts = relationship('ForumPost', backref='topic', cascade='all, delete-orphan')

class ForumPost(db.Model):
    """Model for forum posts."""
    __tablename__ = 'forum_posts'

    id = Column(Integer, primary_key=True)
    topic_id = Column(Integer, ForeignKey('forum_topics.id'))
    user_id = Column(Integer, ForeignKey('users.id'))
    title = Column(String(255), nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_pinned = Column(Boolean, default=False)
    views_count = Column(Integer, default=0)
    
    # Relationships
    user = relationship('User', backref='forum_posts')
    replies = relationship('ForumReply', backref='post', cascade='all, delete-orphan')

class ForumReply(db.Model):
    """Model for replies to forum posts."""
    __tablename__ = 'forum_replies'

    id = Column(Integer, primary_key=True)
    post_id = Column(Integer, ForeignKey('forum_posts.id'))
    user_id = Column(Integer, ForeignKey('users.id'))
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship
    user = relationship('User', backref='forum_replies')

class SavingsGroup(db.Model):
    """Model for user-created savings groups."""
    __tablename__ = 'savings_groups'

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    creator_id = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=datetime.utcnow)
    target_amount = Column(Float)
    duration_weeks = Column(Integer)
    member_limit = Column(Integer)
    is_private = Column(Boolean, default=False)
    
    # Relationships
    creator = relationship('User', backref='created_groups')
    members = relationship('GroupMembership', backref='group')

class GroupMembership(db.Model):
    """Model for user membership in savings groups."""
    __tablename__ = 'group_memberships'

    id = Column(Integer, primary_key=True)
    group_id = Column(Integer, ForeignKey('savings_groups.id'))
    user_id = Column(Integer, ForeignKey('users.id'))
    joined_at = Column(DateTime, default=datetime.utcnow)
    role = Column(String(20), default='member')  # member, admin, moderator
    
    # Relationship
    user = relationship('User', backref='group_memberships')

class Achievement(db.Model):
    """Model for user achievements and badges."""
    __tablename__ = 'achievements'

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    badge_image_url = Column(String(255))
    points = Column(Integer, default=0)
    criteria = Column(JSON)  # Store achievement criteria as JSON
    created_at = Column(DateTime, default=datetime.utcnow)

class UserAchievement(db.Model):
    """Model for tracking user achievements."""
    __tablename__ = 'user_achievements'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    achievement_id = Column(Integer, ForeignKey('achievements.id'))
    earned_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship('User', backref='achievements')
    achievement = relationship('Achievement')

class Challenge(db.Model):
    """Model for savings challenges."""
    __tablename__ = 'challenges'

    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=False)
    target_amount = Column(Float)
    reward_points = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    participants = relationship('ChallengeParticipant', backref='challenge')

class ChallengeParticipant(db.Model):
    """Model for tracking challenge participants."""
    __tablename__ = 'challenge_participants'

    id = Column(Integer, primary_key=True)
    challenge_id = Column(Integer, ForeignKey('challenges.id'))
    user_id = Column(Integer, ForeignKey('users.id'))
    joined_at = Column(DateTime, default=datetime.utcnow)
    current_amount = Column(Float, default=0)
    completed = Column(Boolean, default=False)
    completed_at = Column(DateTime)
    
    # Relationship
    user = relationship('User', backref='challenges')
