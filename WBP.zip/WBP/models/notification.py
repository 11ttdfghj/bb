from datetime import datetime
from enum import Enum
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Enum as SQLEnum
from sqlalchemy.orm import relationship
from . import db

class NotificationType(Enum):
    DEPOSIT = "deposit"
    WITHDRAWAL = "withdrawal"
    GOAL_REACHED = "goal_reached"
    ACHIEVEMENT = "achievement"
    SYSTEM = "system"
    MARKETING = "marketing"
    REMINDER = "reminder"

class NotificationPriority(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"

class NotificationChannel(Enum):
    WEB_PUSH = "web_push"
    SMS = "sms"
    BOTH = "both"

class NotificationGroup(db.Model):
    __tablename__ = 'notification_groups'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    notifications = db.relationship('Notification', back_populates='group')

class Notification(db.Model):
    __tablename__ = 'notifications'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    message = db.Column(db.String(500), nullable=False)
    type = db.Column(SQLEnum(NotificationType), nullable=False)
    priority = db.Column(SQLEnum(NotificationPriority), default=NotificationPriority.MEDIUM)
    channel = db.Column(SQLEnum(NotificationChannel), default=NotificationChannel.WEB_PUSH)
    phone_number = db.Column(db.String(20))
    is_read = db.Column(db.Boolean, default=False)
    is_sent = db.Column(db.Boolean, default=False)
    sent_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    group_id = db.Column(db.Integer, db.ForeignKey('notification_groups.id'))
    
    # Relationships
    user = db.relationship('User', backref=db.backref('notifications', lazy=True))
    group = db.relationship('NotificationGroup', back_populates='notifications')

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'title': self.title,
            'message': self.message,
            'type': self.type.value,
            'priority': self.priority.value,
            'channel': self.channel.value,
            'phone_number': self.phone_number,
            'is_read': self.is_read,
            'is_sent': self.is_sent,
            'sent_at': self.sent_at.isoformat() if self.sent_at else None,
            'created_at': self.created_at.isoformat(),
            'group_id': self.group_id
        }
