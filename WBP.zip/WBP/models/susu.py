from datetime import datetime
from sqlalchemy import Enum
from . import db

class SavingsGoalCategory(Enum):
    EMERGENCY = 'emergency'
    EDUCATION = 'education'
    VACATION = 'vacation'
    BUSINESS = 'business'
    RETIREMENT = 'retirement'
    HOME = 'home'
    OTHER = 'other'

class SavingsGoalPriority(Enum):
    LOW = 'low'
    MEDIUM = 'medium'
    HIGH = 'high'

class DepositFrequency(Enum):
    DAILY = 'daily'
    WEEKLY = 'weekly'
    BIWEEKLY = 'biweekly'
    MONTHLY = 'monthly'

class TransactionType(Enum):
    DEPOSIT = 'deposit'
    WITHDRAWAL = 'withdrawal'
    INTEREST = 'interest'
    FEE = 'fee'
    ADJUSTMENT = 'adjustment'

class SusuAccount(db.Model):
    __tablename__ = 'susu_accounts'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    nickname = db.Column(db.String(100))
    balance = db.Column(db.Numeric(10, 2), default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    goals = db.relationship('SavingsGoal', backref='susu_account', lazy=True)
    deposits = db.relationship('RecurringDeposit', backref='susu_account', lazy=True)
    transactions = db.relationship('Transaction', backref='susu_account', lazy=True)
    
    def __repr__(self):
        return f'<SusuAccount {self.nickname or "Unnamed"}>'

class SavingsGoal(db.Model):
    __tablename__ = 'savings_goals'
    
    id = db.Column(db.Integer, primary_key=True)
    susu_account_id = db.Column(db.Integer, db.ForeignKey('susu_accounts.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    target_amount = db.Column(db.Numeric(10, 2), nullable=False)
    current_amount = db.Column(db.Numeric(10, 2), default=0)
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    target_date = db.Column(db.DateTime, nullable=False)
    category = db.Column(db.Enum(SavingsGoalCategory), nullable=False)
    priority = db.Column(db.Enum(SavingsGoalPriority), default=SavingsGoalPriority.MEDIUM)
    is_active = db.Column(db.Boolean, default=True)
    is_achieved = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<SavingsGoal {self.name}>'

class RecurringDeposit(db.Model):
    __tablename__ = 'recurring_deposits'
    
    id = db.Column(db.Integer, primary_key=True)
    susu_account_id = db.Column(db.Integer, db.ForeignKey('susu_accounts.id'), nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    frequency = db.Column(db.Enum(DepositFrequency), nullable=False)
    start_date = db.Column(db.DateTime, nullable=False)
    next_deposit_date = db.Column(db.DateTime, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    source_type = db.Column(db.String(50), nullable=False)  # 'bank' or 'mobile'
    source_id = db.Column(db.Integer, nullable=False)  # ID of BankAccount or MobileWallet
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<RecurringDeposit {self.amount} {self.frequency.value}>'

class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    susu_account_id = db.Column(db.Integer, db.ForeignKey('susu_accounts.id'), nullable=False)
    type = db.Column(db.Enum(TransactionType), nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    description = db.Column(db.String(200))
    reference_number = db.Column(db.String(50), unique=True)
    savings_goal_id = db.Column(db.Integer, db.ForeignKey('savings_goals.id'))
    status = db.Column(db.String(20), default='completed')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Transaction {self.reference_number}>'
