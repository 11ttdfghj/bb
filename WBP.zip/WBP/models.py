from app import db
from flask_login import UserMixin
from datetime import datetime
import enum
from enum import Enum
from datetime import timedelta

class VerificationStatus(enum.Enum):
    PENDING = "pending"
    IN_REVIEW = "in_review"
    VERIFIED = "verified"
    REJECTED = "rejected"

class User(UserMixin, db.Model):
    __table_args__ = {'extend_existing': True}
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    phone_number = db.Column(db.String(20))
    profile_pic = db.Column(db.String(200))
    preferred_language = db.Column(db.String(10), default='en')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # MFA fields
    mfa_type = db.Column(db.String(20))  # 'totp' or 'sms'
    totp_secret = db.Column(db.String(32))
    mfa_code = db.Column(db.String(6))
    mfa_code_expiry = db.Column(db.DateTime)
    
    # Security fields
    last_login = db.Column(db.DateTime)
    failed_login_attempts = db.Column(db.Integer, default=0)
    account_locked_until = db.Column(db.DateTime)
    password_changed_at = db.Column(db.DateTime)
    
    # User preferences
    preferred_notification_channel = db.Column(db.String(20), default='email')
    notification_enabled = db.Column(db.Boolean, default=True)
    
    # KYC Information
    kyc_status = db.Column(db.Enum(VerificationStatus), default=VerificationStatus.PENDING)
    kyc_submitted_at = db.Column(db.DateTime)
    kyc_verified_at = db.Column(db.DateTime)
    kyc_rejection_reason = db.Column(db.Text)
    last_kyc_reverification = db.Column(db.DateTime)
    
    # Relationships
    kyc_documents = db.relationship('KYCDocument', backref='user', lazy=True)
    bank_accounts = db.relationship('BankAccount', backref='user', lazy=True)
    mobile_wallets = db.relationship('MobileWallet', backref='user', lazy=True)

    def __init__(self, email, name, phone_number=None, profile_pic=None):
        self.email = email
        self.name = name
        self.phone_number = phone_number
        self.profile_pic = profile_pic
        self.last_login = datetime.utcnow()
        
    def is_mfa_enabled(self):
        """Check if MFA is enabled for the user."""
        return bool(self.mfa_type)
        
    def needs_password_change(self):
        """Check if user needs to change password."""
        if not self.password_changed_at:
            return True
        # Password change required every 90 days
        return (datetime.utcnow() - self.password_changed_at).days >= 90
        
    def is_account_locked(self):
        """Check if account is locked due to failed login attempts."""
        if self.account_locked_until and datetime.utcnow() < self.account_locked_until:
            return True
        return False
        
    def record_login_attempt(self, success):
        """Record login attempt and handle account locking."""
        if success:
            self.failed_login_attempts = 0
            self.last_login = datetime.utcnow()
        else:
            self.failed_login_attempts += 1
            if self.failed_login_attempts >= 5:  # Lock after 5 failed attempts
                self.account_locked_until = datetime.utcnow() + timedelta(minutes=30)
                
    def get_security_info(self):
        """Get user's security information."""
        return {
            'mfa_enabled': self.is_mfa_enabled(),
            'mfa_type': self.mfa_type,
            'last_login': self.last_login,
            'needs_password_change': self.needs_password_change(),
            'account_locked': self.is_account_locked()
        }

class KYCDocument(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    document_type = db.Column(db.String(50), nullable=False)  # passport, national_id, drivers_license
    document_number = db.Column(db.String(50), nullable=False)
    document_file = db.Column(db.String(200), nullable=False)  # File path or URL
    expiry_date = db.Column(db.Date)
    is_verified = db.Column(db.Boolean, default=False)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    verified_at = db.Column(db.DateTime)
    verification_notes = db.Column(db.Text)

class BankAccount(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    bank_name = db.Column(db.String(100), nullable=False)
    account_number = db.Column(db.String(50), nullable=False)
    account_name = db.Column(db.String(100), nullable=False)
    is_verified = db.Column(db.Boolean, default=False)
    is_primary = db.Column(db.Boolean, default=False)
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_used = db.Column(db.DateTime)

class MobileWallet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    provider = db.Column(db.String(50), nullable=False)  # MTN, Airtel, Vodafone
    phone_number = db.Column(db.String(20), nullable=False)
    account_name = db.Column(db.String(100), nullable=False)
    is_verified = db.Column(db.Boolean, default=False)
    is_primary = db.Column(db.Boolean, default=False)
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_used = db.Column(db.DateTime)

class UserOnboarding(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    tutorial_completed = db.Column(db.Boolean, default=False)
    current_step = db.Column(db.String(50))  # personal_info, kyc, bank_linking, etc.
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
