from flask_wtf import FlaskForm
from wtforms import (
    StringField, TextAreaField, SelectField, IntegerField,
    FloatField, BooleanField, DateTimeField, FileField
)
from wtforms.validators import DataRequired, Length, Optional, NumberRange

class EducationalContentForm(FlaskForm):
    """Form for creating and editing educational content."""
    title = StringField('Title', validators=[
        DataRequired(),
        Length(min=5, max=255)
    ])
    content = TextAreaField('Content', validators=[DataRequired()])
    content_type = SelectField('Content Type', choices=[
        ('article', 'Article'),
        ('guide', 'Guide'),
        ('tutorial', 'Tutorial'),
        ('video', 'Video'),
        ('infographic', 'Infographic'),
        ('webinar', 'Webinar')
    ])
    difficulty_level = SelectField('Difficulty Level', choices=[
        ('beginner', 'Beginner'),
        ('intermediate', 'Intermediate'),
        ('advanced', 'Advanced')
    ])
    language = SelectField('Language', choices=[
        ('en', 'English'),
        ('tw', 'Twi'),
        ('ga', 'Ga'),
        ('ha', 'Hausa')
    ])
    tags = StringField('Tags')
    media_file = FileField('Media File')
    is_published = BooleanField('Publish')

class ForumTopicForm(FlaskForm):
    """Form for creating forum topics."""
    title = StringField('Title', validators=[
        DataRequired(),
        Length(min=5, max=255)
    ])
    description = TextAreaField('Description', validators=[DataRequired()])

class ForumPostForm(FlaskForm):
    """Form for creating forum posts."""
    title = StringField('Title', validators=[
        DataRequired(),
        Length(min=5, max=255)
    ])
    content = TextAreaField('Content', validators=[DataRequired()])
    topic_id = SelectField('Topic', coerce=int)

class ForumReplyForm(FlaskForm):
    """Form for replying to forum posts."""
    content = TextAreaField('Reply', validators=[DataRequired()])

class SavingsGroupForm(FlaskForm):
    """Form for creating savings groups."""
    name = StringField('Group Name', validators=[
        DataRequired(),
        Length(min=3, max=255)
    ])
    description = TextAreaField('Description', validators=[DataRequired()])
    target_amount = FloatField('Target Amount (GHS)', validators=[
        DataRequired(),
        NumberRange(min=0)
    ])
    duration_weeks = IntegerField('Duration (Weeks)', validators=[
        DataRequired(),
        NumberRange(min=1, max=52)
    ])
    member_limit = IntegerField('Member Limit', validators=[Optional()])
    is_private = BooleanField('Private Group')

class ChallengeForm(FlaskForm):
    """Form for creating savings challenges."""
    title = StringField('Challenge Title', validators=[
        DataRequired(),
        Length(min=5, max=255)
    ])
    description = TextAreaField('Description', validators=[DataRequired()])
    target_amount = FloatField('Target Amount (GHS)', validators=[
        DataRequired(),
        NumberRange(min=0)
    ])
    duration_days = IntegerField('Duration (Days)', validators=[
        DataRequired(),
        NumberRange(min=1, max=365)
    ])
    reward_points = IntegerField('Reward Points', validators=[
        DataRequired(),
        NumberRange(min=0)
    ])

class LearningPathForm(FlaskForm):
    """Form for creating learning paths."""
    title = StringField('Path Title', validators=[
        DataRequired(),
        Length(min=5, max=255)
    ])
    description = TextAreaField('Description', validators=[DataRequired()])
    difficulty_level = SelectField('Difficulty Level', choices=[
        ('beginner', 'Beginner'),
        ('intermediate', 'Intermediate'),
        ('advanced', 'Advanced')
    ])
    estimated_duration = IntegerField('Estimated Duration (Hours)', validators=[
        DataRequired(),
        NumberRange(min=1)
    ])
    prerequisites = TextAreaField('Prerequisites')

class UserEducationPreferenceForm(FlaskForm):
    """Form for user education preferences."""
    preferred_language = SelectField('Preferred Language', choices=[
        ('en', 'English'),
        ('tw', 'Twi'),
        ('ga', 'Ga'),
        ('ha', 'Hausa')
    ])
    difficulty_level = SelectField('Preferred Difficulty', choices=[
        ('beginner', 'Beginner'),
        ('intermediate', 'Intermediate'),
        ('advanced', 'Advanced')
    ])
    topics_of_interest = StringField('Topics of Interest')
    enable_notifications = BooleanField('Enable Notifications')
    email_updates = BooleanField('Email Updates')
    sms_updates = BooleanField('SMS Updates')
