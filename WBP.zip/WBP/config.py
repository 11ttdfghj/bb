"""Configuration settings for the application."""

import os
from datetime import timedelta
from cryptography.fernet import Fernet
import secrets
import base64

class Config:
    """Base configuration."""
    # Load environment variables
    NOTIFICATION_ENCRYPTION_KEY = os.getenv('NOTIFICATION_ENCRYPTION_KEY')
    HMAC_KEY = os.getenv('HMAC_KEY')
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev'
    
    # Generate secure keys if not provided
    if not NOTIFICATION_ENCRYPTION_KEY:
        NOTIFICATION_ENCRYPTION_KEY = Fernet.generate_key()
        print("WARNING: Generated new NOTIFICATION_ENCRYPTION_KEY. Please save this in your .env file:")
        print(f"NOTIFICATION_ENCRYPTION_KEY={NOTIFICATION_ENCRYPTION_KEY.decode()}")
    
    if not HMAC_KEY:
        HMAC_KEY = base64.b64encode(secrets.token_bytes(32)).decode()
        print("WARNING: Generated new HMAC_KEY. Please save this in your .env file:")
        print(f"HMAC_KEY={HMAC_KEY}")
    
    # Security settings
    SESSION_COOKIE_SECURE = os.getenv('SESSION_COOKIE_SECURE', 'True').lower() == 'true'
    SESSION_COOKIE_HTTPONLY = os.getenv('SESSION_COOKIE_HTTPONLY', 'True').lower() == 'true'
    SESSION_COOKIE_SAMESITE = os.getenv('SESSION_COOKIE_SAMESITE', 'Strict')
    PERMANENT_SESSION_LIFETIME = timedelta(seconds=int(os.getenv('PERMANENT_SESSION_LIFETIME', 1800)))
    
    # SMS Configuration
    AFRICAS_TALKING_API_KEY = os.getenv('AFRICAS_TALKING_API_KEY')
    AFRICAS_TALKING_USERNAME = os.getenv('AFRICAS_TALKING_USERNAME')
    
    # Web Push Configuration
    VAPID_PUBLIC_KEY = os.getenv('VAPID_PUBLIC_KEY')
    VAPID_PRIVATE_KEY = os.getenv('VAPID_PRIVATE_KEY')
    VAPID_CLAIM_EMAIL = os.getenv('VAPID_CLAIM_EMAIL')
    
    # MAMP MySQL Configuration
    MYSQL_HOST = 'localhost'
    MYSQL_PORT = 8889  # MAMP default MySQL port
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'root'  # MAMP default password
    MYSQL_DB = 'wbp_susu'
    
    SQLALCHEMY_DATABASE_URI = f'mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Security Headers
    SECURITY_HEADERS = {
        'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
        'X-Frame-Options': 'SAMEORIGIN',
        'X-XSS-Protection': '1; mode=block',
        'X-Content-Type-Options': 'nosniff'
    }

    @staticmethod
    def init_app(app):
        pass

class DevelopmentConfig(Config):
    """Development configuration."""
    DEBUG = True
    TESTING = False
    HOST = 'localhost'
    PORT = 8888  # MAMP default Apache port

class TestingConfig(Config):
    """Testing configuration."""
    TESTING = True
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = os.getenv('TEST_DATABASE_URL', 'sqlite:///test.db')
    WTF_CSRF_ENABLED = False

class ProductionConfig(Config):
    """Production configuration."""
    DEBUG = False
    TESTING = False
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Strict'
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=30)
    SECURITY_HEADERS = {
        **Config.SECURITY_HEADERS,
        'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self';"
    }

    @classmethod
    def init_app(cls, app):
        Config.init_app(app)
        
        # Production specific setup
        app.config['SERVER_NAME'] = 'keen-gnat-joint.ngrok-free.app'
        app.config['PREFERRED_URL_SCHEME'] = 'https'

# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}
