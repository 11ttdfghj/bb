from datetime import datetime, timedelta
import numpy as np
from models.susu import SusuAccount, SavingsGoal, Transaction
from models.analytics import SavingsProjection, SavingsInsight
from sqlalchemy import func
from database import db

def calculate_savings_growth(account_ids, start_date, end_date):
    """Calculate savings growth over time."""
    # Get daily balances
    daily_balances = (
        db.session.query(
            func.date_trunc('day', Transaction.date).label('date'),
            func.sum(Transaction.amount).label('amount')
        )
        .filter(
            Transaction.account_id.in_(account_ids),
            Transaction.date.between(start_date, end_date)
        )
        .group_by('date')
        .order_by('date')
        .all()
    )

    # Convert to cumulative sum
    dates = [b.date for b in daily_balances]
    amounts = np.cumsum([float(b.amount) for b in daily_balances])

    return {
        'dates': dates,
        'amounts': amounts.tolist()
    }

def calculate_goal_progress(account_ids):
    """Calculate progress towards savings goals."""
    goals = SavingsGoal.query.filter(
        SavingsGoal.account_id.in_(account_ids)
    ).all()

    for goal in goals:
        goal.progress = (goal.current_amount / goal.target_amount) * 100

    return goals

def analyze_spending_patterns(account_ids, start_date, end_date):
    """Analyze spending patterns and identify trends."""
    transactions = Transaction.query.filter(
        Transaction.account_id.in_(account_ids),
        Transaction.date.between(start_date, end_date)
    ).order_by(Transaction.date).all()

    # Calculate daily savings rate
    daily_savings = {}
    for transaction in transactions:
        date = transaction.date.date()
        if date not in daily_savings:
            daily_savings[date] = 0
        daily_savings[date] += transaction.amount

    # Calculate average daily savings
    avg_daily_savings = sum(daily_savings.values()) / len(daily_savings) if daily_savings else 0

    # Identify patterns
    patterns = {
        'avg_daily_savings': avg_daily_savings,
        'consistency': calculate_savings_consistency(daily_savings),
        'peak_days': identify_peak_savings_days(daily_savings),
        'trends': analyze_savings_trends(daily_savings)
    }

    return patterns

def calculate_savings_consistency(daily_savings):
    """Calculate how consistent savings deposits are."""
    if not daily_savings:
        return 0

    values = list(daily_savings.values())
    std_dev = np.std(values)
    mean = np.mean(values)
    
    # Calculate coefficient of variation (lower means more consistent)
    cv = (std_dev / mean) if mean != 0 else float('inf')
    
    # Convert to a 0-100 consistency score (100 being most consistent)
    consistency = max(0, min(100, 100 * (1 - cv)))
    
    return consistency

def identify_peak_savings_days(daily_savings):
    """Identify days with highest savings."""
    if not daily_savings:
        return []

    # Sort days by savings amount
    sorted_days = sorted(
        daily_savings.items(),
        key=lambda x: x[1],
        reverse=True
    )

    # Return top 5 days
    return [
        {
            'date': day.strftime('%Y-%m-%d'),
            'amount': amount
        }
        for day, amount in sorted_days[:5]
    ]

def analyze_savings_trends(daily_savings):
    """Analyze trends in savings behavior."""
    if not daily_savings:
        return {
            'trend': 'neutral',
            'growth_rate': 0
        }

    dates = sorted(daily_savings.keys())
    if len(dates) < 2:
        return {
            'trend': 'neutral',
            'growth_rate': 0
        }

    # Calculate linear regression
    x = np.array(range(len(dates)))
    y = np.array([daily_savings[date] for date in dates])
    
    slope, _ = np.polyfit(x, y, 1)
    
    # Determine trend
    if slope > 0:
        trend = 'increasing'
    elif slope < 0:
        trend = 'decreasing'
    else:
        trend = 'neutral'

    # Calculate growth rate
    initial_value = y[0]
    final_value = y[-1]
    time_period = len(dates)
    
    if initial_value != 0:
        growth_rate = ((final_value - initial_value) / abs(initial_value)) * 100
    else:
        growth_rate = 0

    return {
        'trend': trend,
        'growth_rate': growth_rate
    }

def generate_savings_recommendations(patterns):
    """Generate personalized savings recommendations."""
    recommendations = []
    projections = []

    # Analyze consistency
    if patterns['consistency'] < 50:
        recommendations.append(
            SavingsInsight(
                type='consistency',
                message='Consider setting up automatic deposits to improve savings consistency',
                priority='high'
            )
        )

    # Analyze peak days
    if patterns['peak_days']:
        peak_day_message = (
            f"Your best saving days are typically around "
            f"{patterns['peak_days'][0]['date']}. Consider scheduling "
            "regular deposits on these days."
        )
        recommendations.append(
            SavingsInsight(
                type='timing',
                message=peak_day_message,
                priority='medium'
            )
        )

    # Analyze trends
    trend_data = patterns['trends']
    if trend_data['trend'] == 'decreasing':
        recommendations.append(
            SavingsInsight(
                type='trend',
                message=(
                    'Your savings rate has been decreasing. Consider reviewing '
                    'your budget to identify areas for improvement.'
                ),
                priority='high'
            )
        )
    elif trend_data['trend'] == 'increasing':
        recommendations.append(
            SavingsInsight(
                type='trend',
                message=(
                    'Great job! Your savings rate is increasing. Keep up the '
                    'good work and consider setting more ambitious goals.'
                ),
                priority='low'
            )
        )

    # Generate projections
    avg_daily = patterns['avg_daily_savings']
    for months in [1, 3, 6, 12]:
        projected_amount = avg_daily * 30 * months
        projections.append(
            SavingsProjection(
                months=months,
                amount=projected_amount,
                confidence_level='medium'
            )
        )

    return {
        'recommendations': recommendations,
        'projections': projections
    }

def calculate_milestone_progress(account_ids):
    """Calculate progress towards savings milestones."""
    milestones = []
    
    # Get total savings
    total_savings = db.session.query(
        func.sum(Transaction.amount)
    ).filter(
        Transaction.account_id.in_(account_ids)
    ).scalar() or 0

    # Define milestone levels
    milestone_levels = [
        (1000, "First Thousand"),
        (5000, "Savings Expert"),
        (10000, "Savings Master"),
        (50000, "Savings Legend"),
        (100000, "Savings Guru")
    ]

    # Calculate progress for each milestone
    for amount, title in milestone_levels:
        if total_savings >= amount:
            progress = 100
            status = "completed"
        else:
            progress = (total_savings / amount) * 100
            status = "in_progress"

        milestones.append({
            'title': title,
            'target_amount': amount,
            'current_amount': min(total_savings, amount),
            'progress': progress,
            'status': status
        })

    return milestones
