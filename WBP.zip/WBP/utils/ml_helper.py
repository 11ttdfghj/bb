import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import joblib
from datetime import datetime, timedelta
import os

class SavingsPredictionModel:
    def __init__(self, model_dir='ml_models'):
        """Initialize the savings prediction model."""
        self.model_dir = model_dir
        self.model = None
        self.scaler = None
        self.features = [
            'current_balance',
            'avg_monthly_savings',
            'savings_frequency',
            'goal_amount',
            'time_to_goal',
            'income_level',
            'expense_ratio'
        ]
        
        # Create model directory if it doesn't exist
        if not os.path.exists(model_dir):
            os.makedirs(model_dir)

    def preprocess_data(self, data):
        """Preprocess the input data for model training or prediction."""
        df = pd.DataFrame(data)
        
        # Handle missing values
        df = df.fillna({
            'current_balance': 0,
            'avg_monthly_savings': df['avg_monthly_savings'].mean(),
            'savings_frequency': df['savings_frequency'].mode()[0],
            'goal_amount': df['goal_amount'].mean(),
            'time_to_goal': df['time_to_goal'].mean(),
            'income_level': df['income_level'].mean(),
            'expense_ratio': df['expense_ratio'].mean()
        })
        
        # Feature engineering
        df['savings_rate'] = df['avg_monthly_savings'] / df['income_level']
        df['goal_progress'] = df['current_balance'] / df['goal_amount']
        
        return df

    def train_model(self, training_data, target_variable='future_savings'):
        """Train the savings prediction model."""
        # Preprocess data
        df = self.preprocess_data(training_data)
        X = df[self.features]
        y = df[target_variable]
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        # Scale features
        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Train model
        self.model = GradientBoostingRegressor(
            n_estimators=100,
            learning_rate=0.1,
            max_depth=5,
            random_state=42
        )
        self.model.fit(X_train_scaled, y_train)
        
        # Evaluate model
        y_pred = self.model.predict(X_test_scaled)
        mse = mean_squared_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        
        # Save model and scaler
        self.save_model()
        
        return {
            'mse': mse,
            'r2': r2,
            'feature_importance': dict(zip(self.features, self.model.feature_importances_))
        }

    def predict_savings(self, user_data):
        """Make savings predictions for a user."""
        if self.model is None:
            self.load_model()
        
        # Preprocess user data
        df = self.preprocess_data([user_data])
        X = df[self.features]
        
        # Scale features
        X_scaled = self.scaler.transform(X)
        
        # Make prediction
        prediction = self.model.predict(X_scaled)[0]
        
        return prediction

    def generate_savings_trajectory(self, user_data, months=12):
        """Generate a savings trajectory for the next n months."""
        trajectory = []
        current_data = user_data.copy()
        
        for month in range(months):
            # Predict next month's savings
            prediction = self.predict_savings(current_data)
            
            # Update trajectory
            trajectory.append({
                'month': month + 1,
                'predicted_savings': prediction,
                'cumulative_savings': current_data['current_balance'] + prediction
            })
            
            # Update current data for next prediction
            current_data['current_balance'] += prediction
            current_data['avg_monthly_savings'] = (
                (current_data['avg_monthly_savings'] * month + prediction) / (month + 1)
            )
        
        return trajectory

    def save_model(self):
        """Save the trained model and scaler."""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        model_path = os.path.join(self.model_dir, f'savings_model_{timestamp}.joblib')
        scaler_path = os.path.join(self.model_dir, f'scaler_{timestamp}.joblib')
        
        joblib.dump(self.model, model_path)
        joblib.dump(self.scaler, scaler_path)

    def load_model(self, model_path=None, scaler_path=None):
        """Load the latest trained model and scaler."""
        if model_path is None or scaler_path is None:
            # Find latest model and scaler
            model_files = [f for f in os.listdir(self.model_dir) if f.startswith('savings_model_')]
            scaler_files = [f for f in os.listdir(self.model_dir) if f.startswith('scaler_')]
            
            if not model_files or not scaler_files:
                raise FileNotFoundError("No trained model found")
            
            model_path = os.path.join(self.model_dir, sorted(model_files)[-1])
            scaler_path = os.path.join(self.model_dir, sorted(scaler_files)[-1])
        
        self.model = joblib.load(model_path)
        self.scaler = joblib.load(scaler_path)

class SavingsOptimizer:
    def __init__(self, prediction_model):
        """Initialize the savings optimizer."""
        self.prediction_model = prediction_model

    def optimize_savings_plan(self, user_data, goal_amount, target_date):
        """Optimize the savings plan to reach a goal amount by target date."""
        current_balance = user_data['current_balance']
        months_to_goal = (
            datetime.strptime(target_date, '%Y-%m-%d') - datetime.now()
        ).days / 30
        
        if months_to_goal <= 0:
            return None
        
        required_monthly_savings = (goal_amount - current_balance) / months_to_goal
        
        # Generate different savings scenarios
        scenarios = []
        for adjustment_factor in [0.8, 0.9, 1.0, 1.1, 1.2]:
            test_data = user_data.copy()
            test_data['avg_monthly_savings'] = required_monthly_savings * adjustment_factor
            
            trajectory = self.prediction_model.generate_savings_trajectory(
                test_data,
                months=int(months_to_goal)
            )
            
            final_savings = trajectory[-1]['cumulative_savings']
            scenarios.append({
                'monthly_savings': test_data['avg_monthly_savings'],
                'final_savings': final_savings,
                'goal_achieved': final_savings >= goal_amount,
                'trajectory': trajectory
            })
        
        # Find the optimal scenario
        optimal_scenario = None
        for scenario in scenarios:
            if scenario['goal_achieved']:
                if (optimal_scenario is None or
                    scenario['monthly_savings'] < optimal_scenario['monthly_savings']):
                    optimal_scenario = scenario
        
        return optimal_scenario

    def generate_recommendations(self, user_data, savings_history):
        """Generate personalized savings recommendations."""
        recommendations = []
        
        # Analyze savings patterns
        df = pd.DataFrame(savings_history)
        avg_savings = df['amount'].mean()
        savings_volatility = df['amount'].std() / avg_savings
        
        # Generate recommendations based on patterns
        if savings_volatility > 0.5:
            recommendations.append({
                'type': 'consistency',
                'message': 'Consider setting up automatic savings transfers to maintain consistent savings.',
                'impact': 'high'
            })
        
        if user_data['expense_ratio'] > 0.7:
            recommendations.append({
                'type': 'expense_reduction',
                'message': 'Your expenses are high relative to income. Review monthly expenses for potential savings.',
                'impact': 'high'
            })
        
        # Predict future savings with current behavior
        trajectory = self.prediction_model.generate_savings_trajectory(user_data)
        projected_savings = trajectory[-1]['cumulative_savings']
        
        if projected_savings < user_data['goal_amount']:
            shortfall = user_data['goal_amount'] - projected_savings
            recommended_increase = shortfall / 12
            recommendations.append({
                'type': 'savings_adjustment',
                'message': f'Increase monthly savings by {recommended_increase:.2f} GHS to reach your goal.',
                'impact': 'medium'
            })
        
        return recommendations

# Example usage
"""
# Initialize models
prediction_model = SavingsPredictionModel()
optimizer = SavingsOptimizer(prediction_model)

# Train model with historical data
training_data = [...] # Load your training data
model_metrics = prediction_model.train_model(training_data)

# Make predictions for a user
user_data = {
    'current_balance': 1000,
    'avg_monthly_savings': 200,
    'savings_frequency': 30,
    'goal_amount': 5000,
    'time_to_goal': 180,
    'income_level': 3000,
    'expense_ratio': 0.6
}

# Generate savings trajectory
trajectory = prediction_model.generate_savings_trajectory(user_data)

# Optimize savings plan
optimal_plan = optimizer.optimize_savings_plan(
    user_data,
    goal_amount=5000,
    target_date='2024-12-31'
)

# Generate recommendations
savings_history = [...] # Load user's savings history
recommendations = optimizer.generate_recommendations(user_data, savings_history)
"""
