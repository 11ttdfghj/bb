from io import BytesIO
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.units import inch

def generate_pdf_report(data):
    """Generate a PDF report with analytics data."""
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        spaceAfter=30
    )
    elements.append(Paragraph("Savings Analytics Report", title_style))
    elements.append(Spacer(1, 12))

    # Add sections based on available data
    if 'savingsGrowth' in data:
        elements.extend(_create_savings_growth_section(data['savingsGrowth'], styles))
    
    if 'goalsProgress' in data:
        elements.extend(_create_goals_section(data['goalsProgress'], styles))
    
    if 'projections' in data:
        elements.extend(_create_projections_section(data['projections'], styles))
    
    if 'insights' in data:
        elements.extend(_create_insights_section(data['insights'], styles))

    # Build PDF
    doc.build(elements)
    buffer.seek(0)
    return buffer

def _create_savings_growth_section(growth_data, styles):
    """Create savings growth section for PDF report."""
    elements = []
    
    # Section title
    elements.append(Paragraph("Savings Growth", styles['Heading2']))
    elements.append(Spacer(1, 12))
    
    # Create table data
    table_data = [['Date', 'Amount']]
    for date, amount in zip(growth_data['dates'], growth_data['amounts']):
        table_data.append([
            date.strftime('%Y-%m-%d') if hasattr(date, 'strftime') else date,
            f"${amount:,.2f}"
        ])
    
    # Create and style table
    table = Table(table_data, colWidths=[2*inch, 2*inch])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 14),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 12),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    elements.append(table)
    elements.append(Spacer(1, 20))
    return elements

def _create_goals_section(goals_data, styles):
    """Create goals section for PDF report."""
    elements = []
    
    elements.append(Paragraph("Savings Goals Progress", styles['Heading2']))
    elements.append(Spacer(1, 12))
    
    table_data = [['Goal', 'Progress (%)', 'Status']]
    for goal in goals_data:
        status = 'Completed' if goal.progress >= 100 else 'In Progress'
        table_data.append([
            goal.name,
            f"{goal.progress:.1f}%",
            status
        ])
    
    table = Table(table_data, colWidths=[2*inch, 2*inch, 2*inch])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 14),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    elements.append(table)
    elements.append(Spacer(1, 20))
    return elements

def _create_projections_section(projections_data, styles):
    """Create projections section for PDF report."""
    elements = []
    
    elements.append(Paragraph("Savings Projections", styles['Heading2']))
    elements.append(Spacer(1, 12))
    
    table_data = [['Time Period', 'Projected Amount', 'Confidence']]
    for proj in projections_data:
        table_data.append([
            f"{proj.months} months",
            f"${proj.amount:,.2f}",
            proj.confidence_level.title()
        ])
    
    table = Table(table_data, colWidths=[2*inch, 2*inch, 2*inch])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 14),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    elements.append(table)
    elements.append(Spacer(1, 20))
    return elements

def _create_insights_section(insights_data, styles):
    """Create insights section for PDF report."""
    elements = []
    
    elements.append(Paragraph("Savings Insights", styles['Heading2']))
    elements.append(Spacer(1, 12))
    
    for insight in insights_data:
        elements.append(Paragraph(
            f"• {insight.message}",
            styles['Normal']
        ))
        elements.append(Spacer(1, 6))
    
    elements.append(Spacer(1, 20))
    return elements

def generate_excel_report(data):
    """Generate an Excel report with analytics data."""
    buffer = BytesIO()
    
    with pd.ExcelWriter(buffer, engine='xlsxwriter') as writer:
        if 'savingsGrowth' in data:
            df_growth = pd.DataFrame({
                'Date': data['savingsGrowth']['dates'],
                'Amount': data['savingsGrowth']['amounts']
            })
            df_growth.to_excel(writer, sheet_name='Savings Growth', index=False)
            
            # Format the sheet
            workbook = writer.book
            worksheet = writer.sheets['Savings Growth']
            
            # Add formats
            header_format = workbook.add_format({
                'bold': True,
                'text_wrap': True,
                'valign': 'top',
                'fg_color': '#D7E4BC',
                'border': 1
            })
            
            # Write headers with format
            for col_num, value in enumerate(['Date', 'Amount']):
                worksheet.write(0, col_num, value, header_format)
                
            # Set column widths
            worksheet.set_column('A:A', 15)
            worksheet.set_column('B:B', 15)
        
        if 'goalsProgress' in data:
            goals_data = [
                {
                    'Goal': goal.name,
                    'Progress (%)': goal.progress,
                    'Status': 'Completed' if goal.progress >= 100 else 'In Progress'
                }
                for goal in data['goalsProgress']
            ]
            df_goals = pd.DataFrame(goals_data)
            df_goals.to_excel(writer, sheet_name='Goals Progress', index=False)
        
        if 'projections' in data:
            projections_data = [
                {
                    'Months': proj.months,
                    'Projected Amount': proj.amount,
                    'Confidence': proj.confidence_level
                }
                for proj in data['projections']
            ]
            df_projections = pd.DataFrame(projections_data)
            df_projections.to_excel(writer, sheet_name='Projections', index=False)
        
        if 'insights' in data:
            insights_data = [
                {
                    'Type': insight.type,
                    'Message': insight.message,
                    'Priority': insight.priority
                }
                for insight in data['insights']
            ]
            df_insights = pd.DataFrame(insights_data)
            df_insights.to_excel(writer, sheet_name='Insights', index=False)
    
    buffer.seek(0)
    return buffer
