from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, BooleanField, TelField
from wtforms.validators import DataRequired, Length, Regexp

class BankAccountForm(FlaskForm):
    bank_name = SelectField('Bank Name', validators=[DataRequired()],
                          choices=[
                              ('', 'Select Bank'),
                              ('GCB', 'GCB Bank'),
                              ('ECOBANK', 'Ecobank'),
                              ('ABSA', 'Absa Bank'),
                              # Add more banks as needed
                          ])
    account_number = StringField('Account Number', 
                               validators=[DataRequired(),
                                         Length(min=10, max=20),
                                         Regexp(r'^\d+$', message='Account number must contain only digits')])
    account_name = StringField('Account Name', 
                             validators=[DataRequired(),
                                       Length(min=2, max=100)])
    is_primary = BooleanField('Set as Primary Account')

class MobileWalletForm(FlaskForm):
    provider = SelectField('Mobile Money Provider', 
                         validators=[DataRequired()],
                         choices=[
                             ('', 'Select Provider'),
                             ('MTN', 'MTN Mobile Money'),
                             ('VODAFONE', 'Vodafone Cash'),
                             ('AIRTEL', 'AirtelTigo Money')
                         ])
    phone_number = TelField('Phone Number',
                          validators=[DataRequired(),
                                    Regexp(r'^\+?1?\d{9,15}$', 
                                          message='Please enter a valid phone number')])
    account_name = StringField('Account Name',
                             validators=[DataRequired(),
                                       Length(min=2, max=100)])
    is_primary = BooleanField('Set as Primary Account')
