// Cache management
const analyticsCache = {
    data: new Map(),
    timeouts: new Map(),
    maxAge: 5 * 60 * 1000, // 5 minutes default cache duration

    set(key, value, timeout = this.maxAge) {
        this.data.set(key, {
            value,
            timestamp: Date.now()
        });
        
        // Set expiration timeout
        if (this.timeouts.has(key)) {
            clearTimeout(this.timeouts.get(key));
        }
        
        this.timeouts.set(key, setTimeout(() => {
            this.data.delete(key);
            this.timeouts.delete(key);
        }, timeout));
    },

    get(key) {
        const entry = this.data.get(key);
        if (!entry) return null;
        
        if (Date.now() - entry.timestamp > this.maxAge) {
            this.data.delete(key);
            return null;
        }
        
        return entry.value;
    },

    clear() {
        this.data.clear();
        this.timeouts.forEach(timeout => clearTimeout(timeout));
        this.timeouts.clear();
    }
};

// Analytics API client
class SavingsAnalyticsAPI {
    constructor() {
        this.baseUrl = '/api/analytics';
    }

    async getChartData(timeframe = '30', startDate = null, endDate = null) {
        const cacheKey = `chart_data_${timeframe}_${startDate}_${endDate}`;
        const cachedData = analyticsCache.get(cacheKey);
        if (cachedData) return cachedData;

        const params = new URLSearchParams({
            timeframe: timeframe
        });
        
        if (startDate && endDate) {
            params.append('start_date', startDate);
            params.append('end_date', endDate);
        }

        const response = await fetch(`${this.baseUrl}/chart-data?${params}`);
        if (!response.ok) {
            throw new Error('Failed to fetch chart data');
        }

        const data = await response.json();
        analyticsCache.set(cacheKey, data);
        return data;
    }

    async getInsights() {
        const cacheKey = 'insights';
        const cachedData = analyticsCache.get(cacheKey);
        if (cachedData) return cachedData;

        const response = await fetch(`${this.baseUrl}/insights`);
        if (!response.ok) {
            throw new Error('Failed to fetch insights');
        }

        const data = await response.json();
        analyticsCache.set(cacheKey, data);
        return data;
    }

    async exportAnalytics(format, selectedCharts, options = {}) {
        const response = await fetch(`${this.baseUrl}/export`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                format,
                selectedCharts,
                options
            })
        });

        if (!response.ok) {
            throw new Error('Failed to export analytics');
        }

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `savings-analytics.${format}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }
}

// Chart management
class SavingsAnalyticsCharts {
    constructor(api) {
        this.api = api;
        this.charts = new Map();
        this.initializeCharts();
    }

    async initializeCharts() {
        try {
            const data = await this.api.getChartData();
            this.createSavingsGrowthChart(data.savingsGrowth);
            this.createGoalsProgressChart(data.goalsProgress);
            this.createMonthlyContributionsChart(data.monthlyContributions);
            this.createSavingsDistributionChart(data.savingsDistribution);
            this.updateInsights(data.insights);
            this.updateMilestones(data.milestones);
        } catch (error) {
            console.error('Failed to initialize charts:', error);
            this.showError('Failed to load analytics data');
        }
    }

    createSavingsGrowthChart(data) {
        const ctx = document.getElementById('savingsGrowthChart').getContext('2d');
        this.charts.set('savingsGrowth', new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Savings Growth',
                    data: data.values,
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `GHS ${context.parsed.y.toFixed(2)}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'GHS ' + value.toFixed(2);
                            }
                        }
                    }
                }
            }
        }));
    }

    createGoalsProgressChart(data) {
        const ctx = document.getElementById('goalsProgressChart').getContext('2d');
        this.charts.set('goalsProgress', new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: [
                        '#4CAF50',
                        '#2196F3',
                        '#FFC107',
                        '#9C27B0',
                        '#FF5722'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: ${context.parsed}%`;
                            }
                        }
                    }
                }
            }
        }));
    }

    createMonthlyContributionsChart(data) {
        const ctx = document.getElementById('monthlyContributionsChart').getContext('2d');
        this.charts.set('monthlyContributions', new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Monthly Contributions',
                    data: data.values,
                    backgroundColor: '#2196F3'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `GHS ${context.parsed.y.toFixed(2)}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'GHS ' + value.toFixed(2);
                            }
                        }
                    }
                }
            }
        }));
    }

    createSavingsDistributionChart(data) {
        const ctx = document.getElementById('savingsDistributionChart').getContext('2d');
        this.charts.set('savingsDistribution', new Chart(ctx, {
            type: 'pie',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: [
                        '#4CAF50',
                        '#2196F3',
                        '#FFC107',
                        '#9C27B0',
                        '#FF5722'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: GHS ${context.parsed.toFixed(2)}`;
                            }
                        }
                    }
                }
            }
        }));
    }

    async updateCharts(timeframe = '30', startDate = null, endDate = null) {
        try {
            const data = await this.api.getChartData(timeframe, startDate, endDate);
            
            this.charts.get('savingsGrowth').data.labels = data.savingsGrowth.labels;
            this.charts.get('savingsGrowth').data.datasets[0].data = data.savingsGrowth.values;
            this.charts.get('savingsGrowth').update();

            this.charts.get('goalsProgress').data.labels = data.goalsProgress.labels;
            this.charts.get('goalsProgress').data.datasets[0].data = data.goalsProgress.values;
            this.charts.get('goalsProgress').update();

            this.charts.get('monthlyContributions').data.labels = data.monthlyContributions.labels;
            this.charts.get('monthlyContributions').data.datasets[0].data = data.monthlyContributions.values;
            this.charts.get('monthlyContributions').update();

            this.charts.get('savingsDistribution').data.labels = data.savingsDistribution.labels;
            this.charts.get('savingsDistribution').data.datasets[0].data = data.savingsDistribution.values;
            this.charts.get('savingsDistribution').update();

            this.updateInsights(data.insights);
            this.updateMilestones(data.milestones);
        } catch (error) {
            console.error('Failed to update charts:', error);
            this.showError('Failed to update analytics data');
        }
    }

    updateInsights(insights) {
        const container = document.getElementById('insightsContainer');
        container.innerHTML = '';

        insights.recommendations.forEach(insight => {
            const card = document.createElement('div');
            card.className = `insight-card ${insight.priority}`;
            card.innerHTML = `
                <div class="insight-icon">
                    <i class="fas fa-${this.getInsightIcon(insight.type)}"></i>
                </div>
                <div class="insight-content">
                    <p>${insight.message}</p>
                    <span class="insight-priority">${insight.priority}</span>
                </div>
            `;
            container.appendChild(card);
        });
    }

    updateMilestones(milestones) {
        const container = document.getElementById('milestonesContainer');
        container.innerHTML = '';

        milestones.forEach(milestone => {
            const card = document.createElement('div');
            card.className = `milestone-card ${milestone.status}`;
            card.innerHTML = `
                <div class="milestone-header">
                    <h3>${milestone.title}</h3>
                    <span class="milestone-status">${milestone.status}</span>
                </div>
                <div class="milestone-progress">
                    <div class="progress-bar" style="width: ${milestone.progress}%"></div>
                </div>
                <div class="milestone-details">
                    <p>Target: GHS ${milestone.target_amount.toFixed(2)}</p>
                    <p>Current: GHS ${milestone.current_amount.toFixed(2)}</p>
                </div>
            `;
            container.appendChild(card);
        });
    }

    getInsightIcon(type) {
        const icons = {
            consistency: 'calendar-check',
            trend: 'chart-line',
            timing: 'clock',
            default: 'lightbulb'
        };
        return icons[type] || icons.default;
    }

    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert alert-danger';
        errorDiv.textContent = message;
        document.querySelector('.analytics-container').prepend(errorDiv);
        setTimeout(() => errorDiv.remove(), 5000);
    }
}

// Initialize analytics when document is ready
document.addEventListener('DOMContentLoaded', () => {
    const api = new SavingsAnalyticsAPI();
    const charts = new SavingsAnalyticsCharts(api);

    // Set up event listeners for timeframe selection
    document.getElementById('timeframeSelect').addEventListener('change', (e) => {
        const timeframe = e.target.value;
        if (timeframe === 'custom') {
            document.getElementById('dateRangeContainer').style.display = 'block';
        } else {
            document.getElementById('dateRangeContainer').style.display = 'none';
            charts.updateCharts(timeframe);
        }
    });

    // Set up date range picker
    const dateRangePicker = new DateRangePicker(document.getElementById('dateRange'), {
        onChange: (start, end) => {
            charts.updateCharts('custom', start.format('YYYY-MM-DD'), end.format('YYYY-MM-DD'));
        }
    });

    // Set up export buttons
    document.querySelectorAll('[data-export-format]').forEach(button => {
        button.addEventListener('click', async () => {
            const format = button.dataset.exportFormat;
            const selectedCharts = {
                savingsGrowth: true,
                goalsProgress: true,
                monthlyContributions: true,
                savingsDistribution: true
            };
            const options = {
                includeProjections: true,
                includeInsights: true
            };
            
            try {
                await api.exportAnalytics(format, selectedCharts, options);
            } catch (error) {
                charts.showError('Failed to export analytics');
            }
        });
    });
});
