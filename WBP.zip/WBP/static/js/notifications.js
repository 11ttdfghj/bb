class NotificationManager {
    constructor() {
        this.vapidPublicKey = null;
        this.registration = null;
        this.isSubscribed = false;
    }

    async initialize() {
        try {
            // Check if service worker and push messaging is supported
            if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
                console.log('Push messaging is not supported');
                return;
            }

            // Get VAPID public key from server
            const response = await fetch('/api/notifications/vapid-public-key');
            const data = await response.json();
            this.vapidPublicKey = data.vapidPublicKey;

            // Register service worker
            this.registration = await navigator.serviceWorker.register('/static/js/service-worker.js');
            console.log('Service Worker registered');

            // Check if already subscribed
            const subscription = await this.registration.pushManager.getSubscription();
            this.isSubscribed = !!subscription;

            if (this.isSubscribed) {
                console.log('User is already subscribed to push notifications');
            }
        } catch (error) {
            console.error('Error initializing notifications:', error);
        }
    }

    async subscribe() {
        try {
            if (!this.registration) {
                throw new Error('Service Worker not registered');
            }

            // Request notification permission
            const permission = await Notification.requestPermission();
            if (permission !== 'granted') {
                throw new Error('Permission not granted for notifications');
            }

            // Convert VAPID key to Uint8Array
            const applicationServerKey = this.urlBase64ToUint8Array(this.vapidPublicKey);

            // Subscribe to push notifications
            const subscription = await this.registration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: applicationServerKey
            });

            // Send subscription to server
            await fetch('/api/notifications/subscribe', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(subscription)
            });

            this.isSubscribed = true;
            console.log('Successfully subscribed to push notifications');
            return true;
        } catch (error) {
            console.error('Failed to subscribe to push notifications:', error);
            return false;
        }
    }

    async unsubscribe() {
        try {
            const subscription = await this.registration.pushManager.getSubscription();
            if (subscription) {
                // Unsubscribe from push notifications
                await subscription.unsubscribe();

                // Notify server
                await fetch('/api/notifications/unsubscribe', {
                    method: 'POST'
                });

                this.isSubscribed = false;
                console.log('Successfully unsubscribed from push notifications');
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error unsubscribing from push notifications:', error);
            return false;
        }
    }

    async updateNotificationSettings(settings) {
        try {
            const response = await fetch('/api/notifications/settings', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(settings)
            });

            if (!response.ok) {
                throw new Error('Failed to update notification settings');
            }

            console.log('Notification settings updated successfully');
            return true;
        } catch (error) {
            console.error('Error updating notification settings:', error);
            return false;
        }
    }

    async getNotifications(page = 1, perPage = 10) {
        try {
            const response = await fetch(`/api/notifications?page=${page}&per_page=${perPage}`);
            const data = await response.json();
            return data;
        } catch (error) {
            console.error('Error fetching notifications:', error);
            return null;
        }
    }

    async markAsRead(notificationIds) {
        try {
            const response = await fetch('/api/notifications/mark-read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ notification_ids: notificationIds })
            });

            if (!response.ok) {
                throw new Error('Failed to mark notifications as read');
            }

            console.log('Notifications marked as read');
            return true;
        } catch (error) {
            console.error('Error marking notifications as read:', error);
            return false;
        }
    }

    // Utility function to convert VAPID key
    urlBase64ToUint8Array(base64String) {
        const padding = '='.repeat((4 - base64String.length % 4) % 4);
        const base64 = (base64String + padding)
            .replace(/\-/g, '+')
            .replace(/_/g, '/');

        const rawData = window.atob(base64);
        const outputArray = new Uint8Array(rawData.length);

        for (let i = 0; i < rawData.length; ++i) {
            outputArray[i] = rawData.charCodeAt(i);
        }
        return outputArray;
    }
}

// Create and export notification manager instance
const notificationManager = new NotificationManager();
export default notificationManager;
