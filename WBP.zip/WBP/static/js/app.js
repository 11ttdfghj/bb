import notificationManager from './notifications.js';

// Initialize notification system when the page loads
document.addEventListener('DOMContentLoaded', async () => {
    // Initialize notification manager
    await notificationManager.initialize();

    // Add event listeners for notification controls
    setupNotificationControls();
});

function setupNotificationControls() {
    // Subscribe button
    const subscribeBtn = document.getElementById('notification-subscribe');
    if (subscribeBtn) {
        subscribeBtn.addEventListener('click', async () => {
            const success = await notificationManager.subscribe();
            if (success) {
                subscribeBtn.textContent = 'Notifications Enabled';
                subscribeBtn.disabled = true;
            }
        });
    }

    // Unsubscribe button
    const unsubscribeBtn = document.getElementById('notification-unsubscribe');
    if (unsubscribeBtn) {
        unsubscribeBtn.addEventListener('click', async () => {
            const success = await notificationManager.unsubscribe();
            if (success) {
                if (subscribeBtn) {
                    subscribeBtn.textContent = 'Enable Notifications';
                    subscribeBtn.disabled = false;
                }
            }
        });
    }

    // Notification settings form
    const notificationSettingsForm = document.getElementById('notification-settings-form');
    if (notificationSettingsForm) {
        notificationSettingsForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(notificationSettingsForm);
            const settings = {
                deposit_notifications: formData.get('deposit_notifications') === 'on',
                withdrawal_notifications: formData.get('withdrawal_notifications') === 'on',
                goal_notifications: formData.get('goal_notifications') === 'on',
                achievement_notifications: formData.get('achievement_notifications') === 'on'
            };
            await notificationManager.updateNotificationSettings(settings);
        });
    }

    // Notification list
    const notificationList = document.getElementById('notification-list');
    if (notificationList) {
        loadNotifications();
    }
}

async function loadNotifications(page = 1) {
    const notifications = await notificationManager.getNotifications(page);
    if (notifications) {
        const notificationList = document.getElementById('notification-list');
        notificationList.innerHTML = notifications.notifications.map(notification => `
            <div class="notification-item ${notification.is_read ? 'read' : 'unread'}" data-id="${notification.id}">
                <div class="notification-header">
                    <h4>${notification.title}</h4>
                    <span class="notification-time">${formatDate(notification.created_at)}</span>
                </div>
                <p>${notification.message}</p>
            </div>
        `).join('');

        // Add click handlers to mark notifications as read
        document.querySelectorAll('.notification-item.unread').forEach(item => {
            item.addEventListener('click', async () => {
                const notificationId = item.dataset.id;
                const success = await notificationManager.markAsRead([notificationId]);
                if (success) {
                    item.classList.remove('unread');
                    item.classList.add('read');
                }
            });
        });
    }
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}
