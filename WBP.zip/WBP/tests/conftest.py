"""Test configuration and fixtures."""

import os
import pytest
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from tests import config

@pytest.fixture(scope='session')
def app():
    """Create test Flask app."""
    app = Flask(__name__)
    app.config.from_object(config)
    return app

@pytest.fixture(scope='session')
def db(app):
    """Create test database."""
    db = SQLAlchemy(app)
    db.create_all()
    return db

@pytest.fixture(autouse=True)
def session(db):
    """Create new database session for a test."""
    connection = db.engine.connect()
    transaction = connection.begin()
    session = db.create_scoped_session()
    
    yield session
    
    session.close()
    transaction.rollback()
    connection.close()
