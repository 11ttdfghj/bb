import asyncio
import os
from services.notification_service import NotificationService
from models.notification import NotificationType, NotificationPriority, NotificationChannel
from app import app, db

async def test_notifications():
    with app.app_context():
        notification_service = NotificationService()
        
        # Test SMS notification
        try:
            await notification_service.send_notification(
                user_id=1,  # Replace with actual user ID
                title="Test SMS Notification",
                message="This is a test SMS notification from Bengabcom Susu Savings Platform",
                notification_type=NotificationType.SYSTEM,
                priority=NotificationPriority.HIGH,
                channel=NotificationChannel.SMS,
                phone_number="0535011211"  # Your phone number
            )
            print("SMS notification sent successfully")
        except Exception as e:
            print(f"Failed to send SMS notification: {str(e)}")
        
        # Test web push notification
        try:
            await notification_service.send_notification(
                user_id=1,  # Replace with actual user ID
                title="Test Web Push Notification",
                message="This is a test web push notification from Bengabcom Susu Savings Platform",
                notification_type=NotificationType.SYSTEM,
                priority=NotificationPriority.MEDIUM,
                channel=NotificationChannel.WEB_PUSH
            )
            print("Web push notification sent successfully")
        except Exception as e:
            print(f"Failed to send web push notification: {str(e)}")
        
        # Test both channels
        try:
            await notification_service.send_notification(
                user_id=1,  # Replace with actual user ID
                title="Test Multi-Channel Notification",
                message="This is a test notification sent through both SMS and web push",
                notification_type=NotificationType.SYSTEM,
                priority=NotificationPriority.HIGH,
                channel=NotificationChannel.BOTH,
                phone_number="0535011211"  # Your phone number
            )
            print("Multi-channel notification sent successfully")
        except Exception as e:
            print(f"Failed to send multi-channel notification: {str(e)}")

if __name__ == "__main__":
    asyncio.run(test_notifications())
