"""Unit tests for transaction logger."""

import unittest
from unittest.mock import patch, MagicMock
from datetime import datetime
from tests import config
from tests.test_db import app, db
from services.transaction_logger import TransactionLogger
from app.models.transaction_logs import TransactionLog, WebhookLog

class TestTransactionLogger(unittest.TestCase):
    """Test cases for transaction logger."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment."""
        with app.app_context():
            db.create_all()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test environment."""
        with app.app_context():
            db.session.remove()
            db.drop_all()
            
    def setUp(self):
        """Set up test environment."""
        self.logger = TransactionLogger()
        self.transaction_data = {
            'transaction_id': 'TEST-123',
            'provider': 'mtn',
            'provider_reference': 'MTN-123',
            'amount': 100.0,
            'wallet': '0241234567',
            'status': 'pending',
            'type': 'payment'
        }
        self.webhook_data = {
            'transaction_id': 'TEST-123',
            'provider': 'mtn',
            'provider_reference': 'MTN-123',
            'status': 'success',
            'payload': {
                'type': 'PAYMENT',
                'status': 'SUCCESS',
                'amount': 100.0
            }
        }
        
    @patch('services.transaction_logger.db.session')
    def test_log_transaction(self, mock_session):
        """Test transaction logging."""
        # Mock transaction log
        mock_log = MagicMock(spec=TransactionLog)
        mock_log.id = 1
        mock_session.add.return_value = None
        mock_session.commit.return_value = None
        
        # Log transaction
        log_id = self.logger.log_transaction(self.transaction_data)
        
        # Verify session calls
        mock_session.add.assert_called_once()
        mock_session.commit.assert_called_once()
        
        # Verify log data
        call_args = mock_session.add.call_args[0][0]
        self.assertEqual(call_args.transaction_id, 'TEST-123')
        self.assertEqual(call_args.provider, 'mtn')
        self.assertEqual(call_args.provider_reference, 'MTN-123')
        self.assertEqual(call_args.amount, 100.0)
        self.assertEqual(call_args.wallet, '0241234567')
        self.assertEqual(call_args.status, 'pending')
        self.assertEqual(call_args.type, 'payment')
        
    @patch('services.transaction_logger.db.session')
    def test_log_webhook(self, mock_session):
        """Test webhook logging."""
        # Mock webhook log
        mock_log = MagicMock(spec=WebhookLog)
        mock_log.id = 1
        mock_session.add.return_value = None
        mock_session.commit.return_value = None
        
        # Log webhook
        log_id = self.logger.log_webhook(self.webhook_data)
        
        # Verify session calls
        mock_session.add.assert_called_once()
        mock_session.commit.assert_called_once()
        
        # Verify log data
        call_args = mock_session.add.call_args[0][0]
        self.assertEqual(call_args.transaction_id, 'TEST-123')
        self.assertEqual(call_args.provider, 'mtn')
        self.assertEqual(call_args.provider_reference, 'MTN-123')
        self.assertEqual(call_args.status, 'success')
        self.assertEqual(call_args.payload, self.webhook_data['payload'])
        
    @patch('services.transaction_logger.db.session')
    def test_get_transaction_history(self, mock_session):
        """Test getting transaction history."""
        # Mock transaction logs
        mock_logs = [
            MagicMock(spec=TransactionLog),
            MagicMock(spec=TransactionLog)
        ]
        mock_session.query.return_value.filter.return_value.all.return_value = mock_logs
        
        # Get transaction history
        history = self.logger.get_transaction_history(
            provider='mtn',
            status='pending',
            start_date=datetime(2024, 1, 1),
            end_date=datetime(2024, 1, 31)
        )
        
        # Verify query execution
        mock_session.query.assert_called_once_with(TransactionLog)
        mock_session.query.return_value.filter.assert_called()
        self.assertEqual(len(history), 2)
        
    @patch('services.transaction_logger.db.session')
    def test_get_webhook_history(self, mock_session):
        """Test getting webhook history."""
        # Mock webhook logs
        mock_logs = [
            MagicMock(spec=WebhookLog),
            MagicMock(spec=WebhookLog)
        ]
        mock_session.query.return_value.filter.return_value.all.return_value = mock_logs
        
        # Get webhook history
        history = self.logger.get_webhook_history(
            provider='mtn',
            status='success',
            start_date=datetime(2024, 1, 1),
            end_date=datetime(2024, 1, 31)
        )
        
        # Verify query execution
        mock_session.query.assert_called_once_with(WebhookLog)
        mock_session.query.return_value.filter.assert_called()
        self.assertEqual(len(history), 2)
        
    @patch('services.transaction_logger.db.session')
    def test_update_transaction_status(self, mock_session):
        """Test updating transaction status."""
        # Mock transaction log
        mock_log = MagicMock(spec=TransactionLog)
        mock_session.query.return_value.filter_by.return_value.first.return_value = mock_log
        mock_session.commit.return_value = None
        
        # Update status
        success = self.logger.update_transaction_status('TEST-123', 'success')
        
        # Verify update
        self.assertTrue(success)
        self.assertEqual(mock_log.status, 'success')
        mock_session.commit.assert_called_once()
        
        # Test non-existent transaction
        mock_session.query.return_value.filter_by.return_value.first.return_value = None
        success = self.logger.update_transaction_status('INVALID-123', 'success')
        self.assertFalse(success)

if __name__ == '__main__':
    unittest.main()
