"""Test configuration."""

import os
from datetime import timedelta

# Database
SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
SQLALCHEMY_TRACK_MODIFICATIONS = False

# Payment Provider Configuration
MTN_API_KEY = 'test_mtn_api_key'
MTN_API_SECRET = 'test_mtn_api_secret'
MTN_API_URL = 'https://sandbox.mtn.com/api/v1'

AIRTEL_CLIENT_ID = 'test_airtel_client_id'
AIRTEL_CLIENT_SECRET = 'test_airtel_client_secret'
AIRTEL_API_URL = 'https://sandbox.airtel.com/api/v1'

VODAFONE_API_KEY = 'test_vodafone_api_key'
VODAFONE_API_SECRET = 'test_vodafone_api_secret'
VODAFONE_API_URL = 'https://sandbox.vodafone.com/api/v1'

# Transaction Limits
MIN_TRANSACTION_AMOUNT = 1.0
MAX_TRANSACTION_AMOUNT = 10000.0

# Provider Prefixes
MTN_PREFIXES = ['024', '054', '055', '059']
AIRTEL_PREFIXES = ['026', '056']
VODAFONE_PREFIXES = ['020', '050']

# JWT Configuration
JWT_SECRET_KEY = 'test_jwt_secret'
JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=1)
JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=30)

# Security
SECRET_KEY = 'test_secret_key'
NOTIFICATION_ENCRYPTION_KEY = 'test_notification_key'
HMAC_KEY = 'test_hmac_key'
