import unittest
from datetime import datetime, timedelta
from decimal import Decimal
import json
from io import BytesIO
import pandas as pd
from flask import url_for
from app import create_app, db
from models.susu import SusuAccount, SavingsGoal, Transaction
from models.analytics import (
    SavingsProjection,
    SavingsInsight,
    SavingsMilestone,
    AnalyticsPreference
)
from utils.analytics_helper import (
    calculate_savings_growth,
    calculate_goal_progress,
    analyze_spending_patterns,
    generate_savings_recommendations,
    calculate_milestone_progress
)

class TestAnalytics(unittest.TestCase):
    def setUp(self):
        self.app = create_app('testing')
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()
        self._create_test_data()

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.app_context.pop()

    def _create_test_data(self):
        """Create test data for analytics testing."""
        # Create test user and account
        self.test_user_id = 1
        self.test_account = SusuAccount(
            user_id=self.test_user_id,
            name='Test Account',
            balance=1000.0
        )
        db.session.add(self.test_account)
        db.session.commit()

        # Create test savings goals
        goals = [
            SavingsGoal(
                account_id=self.test_account.id,
                name='Emergency Fund',
                target_amount=5000.0,
                current_amount=2500.0,
                category='Emergency'
            ),
            SavingsGoal(
                account_id=self.test_account.id,
                name='Vacation',
                target_amount=3000.0,
                current_amount=1000.0,
                category='Travel'
            )
        ]
        db.session.bulk_save_objects(goals)

        # Create test transactions
        end_date = datetime.now()
        start_date = end_date - timedelta(days=90)
        transactions = []
        current_date = start_date

        while current_date <= end_date:
            amount = 100.0 if current_date.weekday() < 5 else 50.0
            transactions.append(
                Transaction(
                    account_id=self.test_account.id,
                    amount=amount,
                    type='deposit',
                    date=current_date
                )
            )
            current_date += timedelta(days=1)

        db.session.bulk_save_objects(transactions)
        db.session.commit()

    def test_chart_data_endpoint(self):
        """Test the chart data API endpoint."""
        response = self.client.get(
            url_for('analytics.get_chart_data'),
            query_string={'timeframe': '30'}
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)

        # Verify response structure
        self.assertIn('savingsGrowth', data)
        self.assertIn('goalsProgress', data)
        self.assertIn('monthlyContributions', data)
        self.assertIn('savingsDistribution', data)
        self.assertIn('insights', data)
        self.assertIn('milestones', data)

        # Verify data content
        self.assertTrue(len(data['savingsGrowth']['labels']) > 0)
        self.assertTrue(len(data['savingsGrowth']['values']) > 0)
        self.assertEqual(
            len(data['savingsGrowth']['labels']),
            len(data['savingsGrowth']['values'])
        )

    def test_insights_endpoint(self):
        """Test the insights API endpoint."""
        response = self.client.get(url_for('analytics.get_insights'))
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)

        self.assertIn('insights', data)
        self.assertIn('projections', data['insights'])
        self.assertIn('recommendations', data['insights'])

    def test_export_endpoint(self):
        """Test the analytics export endpoint."""
        export_data = {
            'format': 'pdf',
            'selectedCharts': {
                'savingsGrowth': True,
                'goalsProgress': True,
                'monthlyContributions': True,
                'savingsDistribution': True
            },
            'options': {
                'includeProjections': True,
                'includeInsights': True
            }
        }

        response = self.client.post(
            url_for('analytics.export_analytics'),
            json=export_data
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data)

    def test_calculate_savings_growth(self):
        """Test savings growth calculation."""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30)
        account_ids = [self.test_account.id]

        result = calculate_savings_growth(account_ids, start_date, end_date)
        
        self.assertIn('dates', result)
        self.assertIn('amounts', result)
        self.assertTrue(len(result['dates']) > 0)
        self.assertTrue(len(result['amounts']) > 0)
        self.assertTrue(all(isinstance(amount, (int, float)) for amount in result['amounts']))

    def test_calculate_goal_progress(self):
        """Test goal progress calculation."""
        account_ids = [self.test_account.id]
        goals = calculate_goal_progress(account_ids)

        self.assertTrue(len(goals) > 0)
        for goal in goals:
            self.assertIsInstance(goal.progress, (int, float))
            self.assertTrue(0 <= goal.progress <= 100)

    def test_analyze_spending_patterns(self):
        """Test spending pattern analysis."""
        account_ids = [self.test_account.id]
        end_date = datetime.now()
        start_date = end_date - timedelta(days=90)

        patterns = analyze_spending_patterns(account_ids, start_date, end_date)

        self.assertIn('avg_daily_savings', patterns)
        self.assertIn('consistency', patterns)
        self.assertIn('peak_days', patterns)
        self.assertIn('trends', patterns)
        self.assertTrue(0 <= patterns['consistency'] <= 100)

    def test_generate_recommendations(self):
        """Test recommendation generation."""
        account_ids = [self.test_account.id]
        end_date = datetime.now()
        start_date = end_date - timedelta(days=90)
        
        patterns = analyze_spending_patterns(account_ids, start_date, end_date)
        recommendations = generate_savings_recommendations(patterns)

        self.assertIn('recommendations', recommendations)
        self.assertIn('projections', recommendations)
        self.assertTrue(len(recommendations['recommendations']) > 0)
        self.assertTrue(len(recommendations['projections']) > 0)

    def test_calculate_milestone_progress(self):
        """Test milestone progress calculation."""
        account_ids = [self.test_account.id]
        milestones = calculate_milestone_progress(account_ids)

        self.assertTrue(len(milestones) > 0)
        for milestone in milestones:
            self.assertIn('title', milestone)
            self.assertIn('progress', milestone)
            self.assertIn('status', milestone)
            self.assertTrue(0 <= milestone['progress'] <= 100)

    def test_analytics_preferences(self):
        """Test analytics preferences functionality."""
        # Create test preferences
        prefs = AnalyticsPreference(
            user_id=self.test_user_id,
            enable_projections=True,
            enable_insights=True,
            enable_milestone_notifications=True,
            report_frequency='weekly',
            preferred_currency='GHS'
        )
        db.session.add(prefs)
        db.session.commit()

        # Verify preferences
        saved_prefs = AnalyticsPreference.query.filter_by(
            user_id=self.test_user_id
        ).first()
        self.assertIsNotNone(saved_prefs)
        self.assertEqual(saved_prefs.report_frequency, 'weekly')
        self.assertEqual(saved_prefs.preferred_currency, 'GHS')

    def test_custom_date_range(self):
        """Test analytics with custom date range."""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=15)
        
        response = self.client.get(
            url_for('analytics.get_chart_data'),
            query_string={
                'timeframe': 'custom',
                'start_date': start_date.strftime('%Y-%m-%d'),
                'end_date': end_date.strftime('%Y-%m-%d')
            }
        )
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        
        # Verify data is within specified range
        first_date = datetime.strptime(
            data['savingsGrowth']['labels'][0],
            '%Y-%m-%d'
        )
        last_date = datetime.strptime(
            data['savingsGrowth']['labels'][-1],
            '%Y-%m-%d'
        )
        
        self.assertTrue(start_date <= first_date <= end_date)
        self.assertTrue(start_date <= last_date <= end_date)

if __name__ == '__main__':
    unittest.main()
