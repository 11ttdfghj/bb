"""Unit tests for payment provider clients."""

import unittest
from unittest.mock import patch, MagicMock
from datetime import datetime
from tests import config
from tests.test_db import app, db
from services.payment_providers.mtn_client import MTNClient
from services.payment_providers.airtel_client import AirtelClient
from services.payment_providers.vodafone_client import VodafoneClient
from services.payment_providers.provider_factory import PaymentProviderFactory

class TestMTNClient(unittest.TestCase):
    """Test cases for MTN Mobile Money client."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment."""
        with app.app_context():
            db.create_all()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test environment."""
        with app.app_context():
            db.session.remove()
            db.drop_all()
            
    def setUp(self):
        """Set up test environment."""
        self.client = MTNClient()
        self.payment_data = {
            'amount': 100.0,
            'wallet': '0241234567',
            'reference': 'TEST-123'
        }
        self.withdrawal_data = {
            'amount': 50.0,
            'wallet': '0241234567',
            'reference': 'TEST-456'
        }
        
    @patch('services.payment_providers.mtn_client.requests.post')
    def test_initiate_payment(self, mock_post):
        """Test payment initiation."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'referenceId': 'MTN-123',
            'status': 'PENDING'
        }
        mock_post.return_value = mock_response
        
        result = self.client.initiate_payment(self.payment_data)
        
        self.assertIn('provider_reference', result)
        self.assertIn('external_reference', result)
        self.assertEqual(result['status'], 'pending')
        
    @patch('services.payment_providers.mtn_client.requests.post')
    def test_initiate_withdrawal(self, mock_post):
        """Test withdrawal initiation."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'referenceId': 'MTN-456',
            'status': 'PENDING'
        }
        mock_post.return_value = mock_response
        
        result = self.client.initiate_withdrawal(self.withdrawal_data)
        
        self.assertIn('provider_reference', result)
        self.assertIn('external_reference', result)
        self.assertEqual(result['status'], 'pending')
        
    def test_validate_wallet(self):
        """Test wallet number validation."""
        valid_numbers = ['0241234567', '0541234567', '0551234567', '0591234567']
        invalid_numbers = ['0261234567', '0541234', '054123456x', '1234567890']
        
        for number in valid_numbers:
            self.assertTrue(self.client.validate_wallet(number))
            
        for number in invalid_numbers:
            self.assertFalse(self.client.validate_wallet(number))

class TestAirtelClient(unittest.TestCase):
    """Test cases for Airtel Money client."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment."""
        with app.app_context():
            db.create_all()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test environment."""
        with app.app_context():
            db.session.remove()
            db.drop_all()
            
    def setUp(self):
        """Set up test environment."""
        self.client = AirtelClient()
        self.payment_data = {
            'amount': 100.0,
            'wallet': '0261234567',
            'reference': 'TEST-123'
        }
        self.withdrawal_data = {
            'amount': 50.0,
            'wallet': '0261234567',
            'reference': 'TEST-456'
        }
        
    @patch('services.payment_providers.airtel_client.requests.post')
    def test_initiate_payment(self, mock_post):
        """Test payment initiation."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'transaction': {
                'id': 'AIR-123',
                'status': 'TS'
            }
        }
        mock_post.return_value = mock_response
        
        result = self.client.initiate_payment(self.payment_data)
        
        self.assertIn('provider_reference', result)
        self.assertIn('external_reference', result)
        self.assertEqual(result['status'], 'pending')
        
    @patch('services.payment_providers.airtel_client.requests.post')
    def test_initiate_withdrawal(self, mock_post):
        """Test withdrawal initiation."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'transaction': {
                'id': 'AIR-456',
                'status': 'TS'
            }
        }
        mock_post.return_value = mock_response
        
        result = self.client.initiate_withdrawal(self.withdrawal_data)
        
        self.assertIn('provider_reference', result)
        self.assertIn('external_reference', result)
        self.assertEqual(result['status'], 'pending')
        
    def test_validate_wallet(self):
        """Test wallet number validation."""
        valid_numbers = ['0261234567', '0561234567']
        invalid_numbers = ['0241234567', '0261234', '026123456x', '1234567890']
        
        for number in valid_numbers:
            self.assertTrue(self.client.validate_wallet(number))
            
        for number in invalid_numbers:
            self.assertFalse(self.client.validate_wallet(number))

class TestVodafoneClient(unittest.TestCase):
    """Test cases for Vodafone Cash client."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment."""
        with app.app_context():
            db.create_all()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test environment."""
        with app.app_context():
            db.session.remove()
            db.drop_all()
            
    def setUp(self):
        """Set up test environment."""
        self.client = VodafoneClient()
        self.payment_data = {
            'amount': 100.0,
            'wallet': '0201234567',
            'reference': 'TEST-123'
        }
        self.withdrawal_data = {
            'amount': 50.0,
            'wallet': '0201234567',
            'reference': 'TEST-456'
        }
        
    @patch('services.payment_providers.vodafone_client.requests.post')
    def test_initiate_payment(self, mock_post):
        """Test payment initiation."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'transactionId': 'VOD-123',
            'status': 'PENDING'
        }
        mock_post.return_value = mock_response
        
        result = self.client.initiate_payment(self.payment_data)
        
        self.assertIn('provider_reference', result)
        self.assertIn('external_reference', result)
        self.assertEqual(result['status'], 'pending')
        
    @patch('services.payment_providers.vodafone_client.requests.post')
    def test_initiate_withdrawal(self, mock_post):
        """Test withdrawal initiation."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'transactionId': 'VOD-456',
            'status': 'PENDING'
        }
        mock_post.return_value = mock_response
        
        result = self.client.initiate_withdrawal(self.withdrawal_data)
        
        self.assertIn('provider_reference', result)
        self.assertIn('external_reference', result)
        self.assertEqual(result['status'], 'pending')
        
    def test_validate_wallet(self):
        """Test wallet number validation."""
        valid_numbers = ['0201234567', '0501234567']
        invalid_numbers = ['0241234567', '0201234', '020123456x', '1234567890']
        
        for number in valid_numbers:
            self.assertTrue(self.client.validate_wallet(number))
            
        for number in invalid_numbers:
            self.assertFalse(self.client.validate_wallet(number))

class TestPaymentProviderFactory(unittest.TestCase):
    """Test cases for PaymentProviderFactory."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment."""
        with app.app_context():
            db.create_all()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test environment."""
        with app.app_context():
            db.session.remove()
            db.drop_all()
            
    def test_get_provider(self):
        """Test getting provider by code."""
        mtn = PaymentProviderFactory.get_provider('mtn')
        airtel = PaymentProviderFactory.get_provider('airtel')
        vodafone = PaymentProviderFactory.get_provider('vodafone')
        
        self.assertIsInstance(mtn, MTNClient)
        self.assertIsInstance(airtel, AirtelClient)
        self.assertIsInstance(vodafone, VodafoneClient)
        
        with self.assertRaises(ValueError):
            PaymentProviderFactory.get_provider('invalid')
            
    def test_get_provider_for_wallet(self):
        """Test getting provider by wallet number."""
        mtn = PaymentProviderFactory.get_provider_for_wallet('0241234567')
        airtel = PaymentProviderFactory.get_provider_for_wallet('0261234567')
        vodafone = PaymentProviderFactory.get_provider_for_wallet('0201234567')
        
        self.assertIsInstance(mtn, MTNClient)
        self.assertIsInstance(airtel, AirtelClient)
        self.assertIsInstance(vodafone, VodafoneClient)
        
        with self.assertRaises(ValueError):
            PaymentProviderFactory.get_provider_for_wallet('0271234567')
            
    def test_validate_amount(self):
        """Test amount validation."""
        self.assertTrue(PaymentProviderFactory.validate_amount('mtn', 100.0))
        self.assertTrue(PaymentProviderFactory.validate_amount('airtel', 100.0))
        self.assertTrue(PaymentProviderFactory.validate_amount('vodafone', 100.0))
        
        self.assertFalse(PaymentProviderFactory.validate_amount('mtn', 0.0))
        self.assertFalse(PaymentProviderFactory.validate_amount('airtel', 20000.0))
        self.assertFalse(PaymentProviderFactory.validate_amount('invalid', 100.0))

if __name__ == '__main__':
    unittest.main()
