"""Unit tests for webhook handlers."""

import unittest
import json
import hmac
import hashlib
from unittest.mock import patch, MagicMock
from datetime import datetime
from flask import Request
from werkzeug.test import EnvironBuilder
from tests import config
from tests.test_db import app, db
from services.payment_providers.webhook_handlers import (
    WebhookHandler,
    MTNWebhookHandler,
    AirtelWebhookHandler,
    VodafoneWebhookHandler,
    get_webhook_handler
)

class TestMTNWebhookHandler(unittest.TestCase):
    """Test cases for MTN webhook handler."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment."""
        with app.app_context():
            db.create_all()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test environment."""
        with app.app_context():
            db.session.remove()
            db.drop_all()
        
    def setUp(self):
        """Set up test environment."""
        self.payload = {
            'type': 'PAYMENT',
            'transactionId': 'MTN-123',
            'status': 'SUCCESS',
            'amount': 100.0,
            'currency': 'GHS',
            'payer': {
                'partyId': '0241234567'
            }
        }
        
        # Create request with payload and signature
        builder = EnvironBuilder(
            path='/webhooks/mtn',
            method='POST',
            data=json.dumps(self.payload),
            content_type='application/json'
        )
        self.request = Request(builder.get_environ())
        
        # Add signature header
        signature = hmac.new(
            config.MTN_API_SECRET.encode(),
            self.request.get_data(),
            hashlib.sha256
        ).hexdigest()
        self.request.headers = {'X-MTN-Signature': signature}
        
        self.handler = MTNWebhookHandler(self.request)
        
    def test_validate_signature(self):
        """Test signature validation."""
        self.assertTrue(self.handler.validate_signature())
        
        # Test with invalid signature
        self.request.headers = {'X-MTN-Signature': 'invalid'}
        self.assertFalse(self.handler.validate_signature())
        
    @patch('services.payment_providers.webhook_handlers.TransactionLogger')
    def test_process_callback(self, mock_logger):
        """Test callback processing."""
        result = self.handler.process_callback()
        
        self.assertEqual(result['transaction_id'], 'MTN-123')
        self.assertEqual(result['status'], 'SUCCESS')
        self.assertEqual(result['amount'], 100.0)
        
        # Verify logging call
        mock_logger.return_value.log_webhook.assert_called_once()

class TestAirtelWebhookHandler(unittest.TestCase):
    """Test cases for Airtel webhook handler."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment."""
        with app.app_context():
            db.create_all()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test environment."""
        with app.app_context():
            db.session.remove()
            db.drop_all()
        
    def setUp(self):
        """Set up test environment."""
        self.payload = {
            'eventType': 'PAYMENT',
            'transaction': {
                'id': 'AIR-123',
                'status': 'TS',
                'amount': 100.0,
                'currency': 'GHS'
            },
            'subscriber': {
                'msisdn': '0261234567'
            }
        }
        
        # Create request with payload and signature
        builder = EnvironBuilder(
            path='/webhooks/airtel',
            method='POST',
            data=json.dumps(self.payload),
            content_type='application/json'
        )
        self.request = Request(builder.get_environ())
        
        # Add signature header
        signature = hmac.new(
            config.AIRTEL_CLIENT_SECRET.encode(),
            self.request.get_data(),
            hashlib.sha256
        ).hexdigest()
        self.request.headers = {'X-Auth-Signature': signature}
        
        self.handler = AirtelWebhookHandler(self.request)
        
    def test_validate_signature(self):
        """Test signature validation."""
        self.assertTrue(self.handler.validate_signature())
        
        # Test with invalid signature
        self.request.headers = {'X-Auth-Signature': 'invalid'}
        self.assertFalse(self.handler.validate_signature())
        
    @patch('services.payment_providers.webhook_handlers.TransactionLogger')
    def test_process_callback(self, mock_logger):
        """Test callback processing."""
        result = self.handler.process_callback()
        
        self.assertEqual(result['transaction_id'], 'AIR-123')
        self.assertEqual(result['status'], 'TS')
        self.assertEqual(result['amount'], 100.0)
        
        # Verify logging call
        mock_logger.return_value.log_webhook.assert_called_once()

class TestVodafoneWebhookHandler(unittest.TestCase):
    """Test cases for Vodafone webhook handler."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment."""
        with app.app_context():
            db.create_all()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test environment."""
        with app.app_context():
            db.session.remove()
            db.drop_all()
        
    def setUp(self):
        """Set up test environment."""
        self.payload = {
            'eventType': 'PAYMENT',
            'transactionId': 'VOD-123',
            'status': 'SUCCESS',
            'amount': 100.0,
            'currency': 'GHS',
            'msisdn': '0201234567'
        }
        
        # Create request with payload and signature
        builder = EnvironBuilder(
            path='/webhooks/vodafone',
            method='POST',
            data=json.dumps(self.payload),
            content_type='application/json'
        )
        self.request = Request(builder.get_environ())
        
        # Add signature header
        signature = hmac.new(
            config.VODAFONE_API_KEY.encode(),
            self.request.get_data(),
            hashlib.sha256
        ).hexdigest()
        self.request.headers = {'X-Signature': signature}
        
        self.handler = VodafoneWebhookHandler(self.request)
        
    def test_validate_signature(self):
        """Test signature validation."""
        self.assertTrue(self.handler.validate_signature())
        
        # Test with invalid signature
        self.request.headers = {'X-Signature': 'invalid'}
        self.assertFalse(self.handler.validate_signature())
        
    @patch('services.payment_providers.webhook_handlers.TransactionLogger')
    def test_process_callback(self, mock_logger):
        """Test callback processing."""
        result = self.handler.process_callback()
        
        self.assertEqual(result['transaction_id'], 'VOD-123')
        self.assertEqual(result['status'], 'SUCCESS')
        self.assertEqual(result['amount'], 100.0)
        
        # Verify logging call
        mock_logger.return_value.log_webhook.assert_called_once()

class TestWebhookHandlerFactory(unittest.TestCase):
    """Test cases for webhook handler factory."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment."""
        with app.app_context():
            db.create_all()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test environment."""
        with app.app_context():
            db.session.remove()
            db.drop_all()
        
    def test_get_webhook_handler(self):
        """Test getting appropriate webhook handler."""
        # Create test requests
        mtn_request = Request(EnvironBuilder(path='/webhooks/mtn').get_environ())
        airtel_request = Request(EnvironBuilder(path='/webhooks/airtel').get_environ())
        vodafone_request = Request(EnvironBuilder(path='/webhooks/vodafone').get_environ())
        invalid_request = Request(EnvironBuilder(path='/webhooks/invalid').get_environ())
        
        # Test handler creation
        self.assertIsInstance(get_webhook_handler(mtn_request), MTNWebhookHandler)
        self.assertIsInstance(get_webhook_handler(airtel_request), AirtelWebhookHandler)
        self.assertIsInstance(get_webhook_handler(vodafone_request), VodafoneWebhookHandler)
        
        # Test invalid path
        with self.assertRaises(ValueError):
            get_webhook_handler(invalid_request)

if __name__ == '__main__':
    unittest.main()
