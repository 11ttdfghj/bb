import json
import requests
import hashlib
import hmac
from typing import Dict, Any, Optional
from datetime import datetime
from app import config

class AirtelClient:
    """Client for Airtel Money integration."""
    
    def __init__(self):
        self.client_id = config.AIRTEL_CLIENT_ID
        self.client_secret = config.AIRTEL_CLIENT_SECRET
        self.environment = config.AIRTEL_ENVIRONMENT
        self.base_url = self._get_base_url()
        self.token = None
        self.token_expires_at = None

    def initiate_payment(self, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        """Initiate a payment collection from user's Airtel wallet."""
        endpoint = '/merchant/v1/payments'
        
        # Generate unique transaction ID
        transaction_id = f"AIR-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
        
        payload = {
            'reference': payment_data['reference'],
            'transaction': {
                'id': transaction_id,
                'amount': payment_data['amount'],
                'currency': 'GHS',
                'country': 'GHA',
                'msisdn': payment_data['wallet']
            },
            'subscriber': {
                'country': 'GHA',
                'currency': 'GHS',
                'msisdn': payment_data['wallet']
            }
        }
        
        response = self._make_request('POST', endpoint, payload)
        
        return {
            'provider_reference': response['transaction']['id'],
            'external_reference': transaction_id,
            'status': 'pending'
        }

    def initiate_withdrawal(self, withdrawal_data: Dict[str, Any]) -> Dict[str, Any]:
        """Initiate a disbursement to user's Airtel wallet."""
        endpoint = '/standard/v1/disbursements'
        
        # Generate unique transaction ID
        transaction_id = f"AIR-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
        
        payload = {
            'reference': withdrawal_data['reference'],
            'transaction': {
                'id': transaction_id,
                'amount': withdrawal_data['amount'],
                'currency': 'GHS',
                'country': 'GHA',
                'msisdn': withdrawal_data['wallet']
            },
            'payee': {
                'msisdn': withdrawal_data['wallet']
            }
        }
        
        response = self._make_request('POST', endpoint, payload)
        
        return {
            'provider_reference': response['transaction']['id'],
            'external_reference': transaction_id,
            'status': 'pending'
        }

    def check_status(self, reference_id: str) -> Dict[str, Any]:
        """Check status of a transaction."""
        endpoint = f'/standard/v1/transactions/{reference_id}'
        
        response = self._make_request('GET', endpoint)
        
        status_mapping = {
            'TS': 'pending',  # Transaction Submitted
            'TIP': 'pending',  # Transaction In Progress
            'TS': 'completed',  # Transaction Success
            'TF': 'failed'  # Transaction Failed
        }
        
        return {
            'status': status_mapping.get(response['transaction']['status'], 'failed'),
            'provider_status': response['transaction']['status'],
            'error': response.get('transaction', {}).get('errorMessage')
        }

    def validate_wallet(self, wallet_number: str) -> bool:
        """Validate Airtel wallet number."""
        # Basic validation for Airtel numbers in Ghana
        if not wallet_number.isdigit():
            return False
            
        valid_prefixes = ['026', '056']
        if len(wallet_number) != 10 or wallet_number[:3] not in valid_prefixes:
            return False
            
        return True

    def _get_base_url(self) -> str:
        """Get base URL based on environment."""
        if self.environment == 'production':
            return 'https://openapi.airtel.africa'
        return 'https://openapiuat.airtel.africa'

    def _get_auth_token(self) -> str:
        """Get authentication token."""
        if self.token and self.token_expires_at and datetime.utcnow() < self.token_expires_at:
            return self.token
            
        endpoint = '/auth/oauth2/token'
        
        payload = {
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'grant_type': 'client_credentials'
        }
        
        response = requests.post(
            f"{self.base_url}{endpoint}",
            json=payload
        )
        response.raise_for_status()
        
        data = response.json()
        self.token = data['access_token']
        self.token_expires_at = datetime.utcnow() + data['expires_in']
        
        return self.token

    def _generate_signature(self, data: Dict[str, Any]) -> str:
        """Generate signature for request."""
        message = json.dumps(data, sort_keys=True)
        signature = hmac.new(
            self.client_secret.encode(),
            message.encode(),
            hashlib.sha256
        ).hexdigest()
        return signature

    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make authenticated request to Airtel API."""
        headers = {
            'Authorization': f"Bearer {self._get_auth_token()}",
            'Content-Type': 'application/json',
            'X-Country': 'GHA',
            'X-Currency': 'GHS'
        }
        
        if data:
            headers['X-Signature'] = self._generate_signature(data)
        
        url = f"{self.base_url}{endpoint}"
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers)
            elif method == 'POST':
                response = requests.post(url, headers=headers, json=data)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
                
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            # Log error and handle specific error cases
            error_data = {
                'error': str(e),
                'response': e.response.json() if hasattr(e, 'response') else None
            }
            raise Exception(f"Airtel API error: {json.dumps(error_data)}")

    def _handle_error_response(self, response: Dict[str, Any]) -> None:
        """Handle error response from Airtel API."""
        error = response.get('error', {})
        error_message = error.get('message', 'Unknown error')
        error_code = error.get('code', 'UNKNOWN')
        
        raise Exception(f"Airtel API error {error_code}: {error_message}")
