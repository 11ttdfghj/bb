"""Factory class for managing payment provider clients."""

from typing import Dict, Optional, Type
from .mtn_client import MTNClient
from .airtel_client import AirtelClient
from .vodafone_client import VodafoneClient
from app import config

class PaymentProviderFactory:
    """Factory class for creating and managing payment provider clients."""
    
    _providers: Dict[str, Type] = {
        'mtn': MTNClient,
        'airtel': AirtelClient,
        'vodafone': VodafoneClient
    }
    
    _instances: Dict[str, object] = {}
    
    @classmethod
    def get_provider(cls, provider_code: str) -> Optional[object]:
        """Get payment provider client instance."""
        if provider_code not in cls._providers:
            raise ValueError(f"Unsupported payment provider: {provider_code}")
            
        provider_config = config.PAYMENT_PROVIDERS.get(provider_code)
        if not provider_config or not provider_config.get('enabled'):
            raise ValueError(f"Payment provider {provider_code} is not enabled")
            
        if provider_code not in cls._instances:
            provider_class = cls._providers[provider_code]
            cls._instances[provider_code] = provider_class()
            
        return cls._instances[provider_code]
    
    @classmethod
    def get_provider_for_wallet(cls, wallet_number: str) -> Optional[object]:
        """Get payment provider client instance based on wallet number."""
        prefix = wallet_number[:3]
        
        for provider_code, provider_config in config.PAYMENT_PROVIDERS.items():
            if prefix in provider_config['prefixes']:
                return cls.get_provider(provider_code)
                
        raise ValueError(f"No payment provider found for wallet number with prefix: {prefix}")
    
    @classmethod
    def validate_wallet_number(cls, wallet_number: str) -> bool:
        """Validate wallet number format and provider."""
        try:
            provider = cls.get_provider_for_wallet(wallet_number)
            return provider.validate_wallet(wallet_number)
        except ValueError:
            return False
    
    @classmethod
    def validate_amount(cls, provider_code: str, amount: float) -> bool:
        """Validate transaction amount for provider."""
        provider_config = config.PAYMENT_PROVIDERS.get(provider_code)
        if not provider_config:
            return False
            
        return (
            amount >= provider_config['min_amount'] and
            amount <= provider_config['max_amount']
        )
    
    @classmethod
    def get_enabled_providers(cls) -> Dict[str, Dict]:
        """Get list of enabled payment providers."""
        return {
            code: config
            for code, config in config.PAYMENT_PROVIDERS.items()
            if config.get('enabled')
        }
    
    @classmethod
    def get_provider_details(cls, provider_code: str) -> Optional[Dict]:
        """Get provider configuration details."""
        return config.PAYMENT_PROVIDERS.get(provider_code)
