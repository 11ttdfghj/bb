import json
import requests
from typing import Dict, Any, Optional
from datetime import datetime
from app import config

class VodafoneClient:
    """Client for Vodafone Cash integration."""
    
    def __init__(self):
        self.merchant_id = config.VODAFONE_MERCHANT_ID
        self.api_key = config.VODAFONE_API_KEY
        self.environment = config.VODAFONE_ENVIRONMENT
        self.base_url = self._get_base_url()
        self.token = None
        self.token_expires_at = None

    def initiate_payment(self, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        """Initiate a payment collection from user's Vodafone wallet."""
        endpoint = '/v1/charge'
        
        # Generate unique transaction ID
        transaction_id = f"VOD-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
        
        payload = {
            'merchantId': self.merchant_id,
            'transactionId': transaction_id,
            'amount': payment_data['amount'],
            'msisdn': payment_data['wallet'],
            'description': f"Payment for Susu deposit - {payment_data['reference']}",
            'callbackUrl': self._get_callback_url('payment')
        }
        
        response = self._make_request('POST', endpoint, payload)
        
        return {
            'provider_reference': response['transactionId'],
            'external_reference': transaction_id,
            'status': 'pending'
        }

    def initiate_withdrawal(self, withdrawal_data: Dict[str, Any]) -> Dict[str, Any]:
        """Initiate a disbursement to user's Vodafone wallet."""
        endpoint = '/v1/disburse'
        
        # Generate unique transaction ID
        transaction_id = f"VOD-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
        
        payload = {
            'merchantId': self.merchant_id,
            'transactionId': transaction_id,
            'amount': withdrawal_data['amount'],
            'msisdn': withdrawal_data['wallet'],
            'description': f"Withdrawal from Susu account - {withdrawal_data['reference']}",
            'callbackUrl': self._get_callback_url('withdrawal')
        }
        
        response = self._make_request('POST', endpoint, payload)
        
        return {
            'provider_reference': response['transactionId'],
            'external_reference': transaction_id,
            'status': 'pending'
        }

    def check_status(self, reference_id: str) -> Dict[str, Any]:
        """Check status of a transaction."""
        endpoint = f'/v1/transaction/{reference_id}'
        
        response = self._make_request('GET', endpoint)
        
        status_mapping = {
            'PENDING': 'pending',
            'PROCESSING': 'pending',
            'SUCCESS': 'completed',
            'FAILED': 'failed'
        }
        
        return {
            'status': status_mapping.get(response['status'], 'failed'),
            'provider_status': response['status'],
            'error': response.get('errorMessage')
        }

    def validate_wallet(self, wallet_number: str) -> bool:
        """Validate Vodafone wallet number."""
        # Basic validation for Vodafone numbers in Ghana
        if not wallet_number.isdigit():
            return False
            
        valid_prefixes = ['020', '050']
        if len(wallet_number) != 10 or wallet_number[:3] not in valid_prefixes:
            return False
            
        return True

    def _get_base_url(self) -> str:
        """Get base URL based on environment."""
        if self.environment == 'production':
            return 'https://api.vodafone.com.gh'
        return 'https://sandbox.vodafone.com.gh'

    def _get_callback_url(self, transaction_type: str) -> str:
        """Get callback URL for transaction type."""
        base_callback = config.VODAFONE_CALLBACK_BASE_URL
        return f"{base_callback}/vodafone/{transaction_type}/callback"

    def _get_auth_token(self) -> str:
        """Get authentication token."""
        if self.token and self.token_expires_at and datetime.utcnow() < self.token_expires_at:
            return self.token
            
        endpoint = '/v1/oauth/token'
        
        payload = {
            'merchantId': self.merchant_id,
            'apiKey': self.api_key,
            'grantType': 'client_credentials'
        }
        
        response = requests.post(
            f"{self.base_url}{endpoint}",
            json=payload
        )
        response.raise_for_status()
        
        data = response.json()
        self.token = data['accessToken']
        self.token_expires_at = datetime.utcnow() + data['expiresIn']
        
        return self.token

    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make authenticated request to Vodafone API."""
        headers = {
            'Authorization': f"Bearer {self._get_auth_token()}",
            'Content-Type': 'application/json',
            'X-Merchant-ID': self.merchant_id
        }
        
        url = f"{self.base_url}{endpoint}"
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers)
            elif method == 'POST':
                response = requests.post(url, headers=headers, json=data)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
                
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            # Log error and handle specific error cases
            error_data = {
                'error': str(e),
                'response': e.response.json() if hasattr(e, 'response') else None
            }
            raise Exception(f"Vodafone API error: {json.dumps(error_data)}")

    def _handle_error_response(self, response: Dict[str, Any]) -> None:
        """Handle error response from Vodafone API."""
        error = response.get('error', {})
        error_message = error.get('message', 'Unknown error')
        error_code = error.get('code', 'UNKNOWN')
        
        raise Exception(f"Vodafone API error {error_code}: {error_message}")
