import json
import requests
from typing import Dict, Any, Optional
from datetime import datetime
from app import config

class MTNClient:
    """Client for MTN Mobile Money integration."""
    
    def __init__(self):
        self.api_key = config.MTN_API_KEY
        self.api_secret = config.MTN_API_SECRET
        self.environment = config.MTN_ENVIRONMENT  # sandbox or production
        self.base_url = self._get_base_url()
        self.token = None
        self.token_expires_at = None

    def initiate_payment(self, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        """Initiate a payment collection from user's MTN wallet."""
        endpoint = '/collection/v1/requesttopay'
        
        # Generate unique external reference
        external_ref = f"MTN-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
        
        payload = {
            'amount': payment_data['amount'],
            'currency': 'GHS',
            'externalId': external_ref,
            'payer': {
                'partyIdType': 'MSISDN',
                'partyId': payment_data['wallet']
            },
            'payerMessage': 'Payment for Susu deposit',
            'payeeNote': payment_data['reference']
        }
        
        response = self._make_request('POST', endpoint, payload)
        
        return {
            'provider_reference': response['referenceId'],
            'external_reference': external_ref,
            'status': 'pending'
        }

    def initiate_withdrawal(self, withdrawal_data: Dict[str, Any]) -> Dict[str, Any]:
        """Initiate a disbursement to user's MTN wallet."""
        endpoint = '/disbursement/v1/transfer'
        
        # Generate unique external reference
        external_ref = f"MTN-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
        
        payload = {
            'amount': withdrawal_data['amount'],
            'currency': 'GHS',
            'externalId': external_ref,
            'payee': {
                'partyIdType': 'MSISDN',
                'partyId': withdrawal_data['wallet']
            },
            'payeeNote': 'Withdrawal from Susu account',
            'message': withdrawal_data['reference']
        }
        
        response = self._make_request('POST', endpoint, payload)
        
        return {
            'provider_reference': response['referenceId'],
            'external_reference': external_ref,
            'status': 'pending'
        }

    def check_status(self, reference_id: str) -> Dict[str, Any]:
        """Check status of a transaction."""
        endpoint = f'/collection/v1/requesttopay/{reference_id}'
        
        response = self._make_request('GET', endpoint)
        
        status_mapping = {
            'PENDING': 'pending',
            'SUCCESSFUL': 'completed',
            'FAILED': 'failed'
        }
        
        return {
            'status': status_mapping.get(response['status'], 'failed'),
            'provider_status': response['status'],
            'error': response.get('reason')
        }

    def validate_wallet(self, wallet_number: str) -> bool:
        """Validate MTN wallet number."""
        # Basic validation for MTN numbers in Ghana
        if not wallet_number.isdigit():
            return False
            
        valid_prefixes = ['024', '054', '055', '059']
        if len(wallet_number) != 10 or wallet_number[:3] not in valid_prefixes:
            return False
            
        return True

    def _get_base_url(self) -> str:
        """Get base URL based on environment."""
        if self.environment == 'production':
            return 'https://api.mtn.com'
        return 'https://sandbox.mtn.com'

    def _get_auth_token(self) -> str:
        """Get authentication token."""
        if self.token and self.token_expires_at and datetime.utcnow() < self.token_expires_at:
            return self.token
            
        endpoint = '/oauth/v1/token'
        auth = (self.api_key, self.api_secret)
        
        response = requests.post(
            f"{self.base_url}{endpoint}",
            auth=auth,
            data={'grant_type': 'client_credentials'}
        )
        response.raise_for_status()
        
        data = response.json()
        self.token = data['access_token']
        self.token_expires_at = datetime.utcnow() + data['expires_in']
        
        return self.token

    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make authenticated request to MTN API."""
        headers = {
            'Authorization': f"Bearer {self._get_auth_token()}",
            'Content-Type': 'application/json',
            'X-Target-Environment': self.environment
        }
        
        url = f"{self.base_url}{endpoint}"
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers)
            elif method == 'POST':
                response = requests.post(url, headers=headers, json=data)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
                
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            # Log error and handle specific error cases
            error_data = {
                'error': str(e),
                'response': e.response.json() if hasattr(e, 'response') else None
            }
            raise Exception(f"MTN API error: {json.dumps(error_data)}")

    def _handle_error_response(self, response: Dict[str, Any]) -> None:
        """Handle error response from MTN API."""
        error = response.get('error', {})
        error_message = error.get('message', 'Unknown error')
        error_code = error.get('code', 'UNKNOWN')
        
        raise Exception(f"MTN API error {error_code}: {error_message}")
