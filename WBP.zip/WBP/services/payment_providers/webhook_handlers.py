"""Webhook handlers for payment provider callbacks."""

import hmac
import hashlib
import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime
from flask import Request, jsonify
from app import config
from .provider_factory import PaymentProviderFactory
from ..transaction_logger import TransactionLogger

logger = logging.getLogger(__name__)

class WebhookHandler:
    """Base class for webhook handlers."""
    
    def __init__(self, request: Request):
        self.request = request
        self.logger = TransactionLogger()
        
    def validate_signature(self) -> bool:
        """Validate webhook signature."""
        raise NotImplementedError
        
    def process_callback(self) -> Dict[str, Any]:
        """Process webhook callback."""
        raise NotImplementedError
        
    def log_callback(self, data: Dict[str, Any]) -> None:
        """Log webhook callback."""
        self.logger.log_webhook(
            provider=self.get_provider_code(),
            event_type=data.get('event_type'),
            transaction_id=data.get('transaction_id'),
            status=data.get('status'),
            payload=data
        )
        
    def get_provider_code(self) -> str:
        """Get provider code."""
        raise NotImplementedError

class MTNWebhookHandler(WebhookHandler):
    """Webhook handler for MTN Mobile Money."""
    
    def validate_signature(self) -> bool:
        """Validate MTN webhook signature."""
        signature = self.request.headers.get('X-MTN-Signature')
        if not signature:
            return False
            
        payload = self.request.get_data()
        computed = hmac.new(
            config.MTN_API_SECRET.encode(),
            payload,
            hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(signature, computed)
        
    def process_callback(self) -> Dict[str, Any]:
        """Process MTN webhook callback."""
        if not self.validate_signature():
            raise ValueError("Invalid webhook signature")
            
        data = self.request.get_json()
        
        callback_data = {
            'event_type': data.get('type'),
            'transaction_id': data.get('transactionId'),
            'status': data.get('status'),
            'amount': data.get('amount'),
            'currency': data.get('currency'),
            'payer': data.get('payer', {}).get('partyId'),
            'timestamp': datetime.utcnow().isoformat()
        }
        
        self.log_callback(callback_data)
        return callback_data
        
    def get_provider_code(self) -> str:
        """Get provider code."""
        return 'mtn'

class AirtelWebhookHandler(WebhookHandler):
    """Webhook handler for Airtel Money."""
    
    def validate_signature(self) -> bool:
        """Validate Airtel webhook signature."""
        signature = self.request.headers.get('X-Auth-Signature')
        if not signature:
            return False
            
        payload = self.request.get_data()
        computed = hmac.new(
            config.AIRTEL_CLIENT_SECRET.encode(),
            payload,
            hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(signature, computed)
        
    def process_callback(self) -> Dict[str, Any]:
        """Process Airtel webhook callback."""
        if not self.validate_signature():
            raise ValueError("Invalid webhook signature")
            
        data = self.request.get_json()
        
        callback_data = {
            'event_type': data.get('eventType'),
            'transaction_id': data.get('transaction', {}).get('id'),
            'status': data.get('transaction', {}).get('status'),
            'amount': data.get('transaction', {}).get('amount'),
            'currency': data.get('transaction', {}).get('currency'),
            'msisdn': data.get('subscriber', {}).get('msisdn'),
            'timestamp': datetime.utcnow().isoformat()
        }
        
        self.log_callback(callback_data)
        return callback_data
        
    def get_provider_code(self) -> str:
        """Get provider code."""
        return 'airtel'

class VodafoneWebhookHandler(WebhookHandler):
    """Webhook handler for Vodafone Cash."""
    
    def validate_signature(self) -> bool:
        """Validate Vodafone webhook signature."""
        signature = self.request.headers.get('X-Signature')
        if not signature:
            return False
            
        payload = self.request.get_data()
        computed = hmac.new(
            config.VODAFONE_API_KEY.encode(),
            payload,
            hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(signature, computed)
        
    def process_callback(self) -> Dict[str, Any]:
        """Process Vodafone webhook callback."""
        if not self.validate_signature():
            raise ValueError("Invalid webhook signature")
            
        data = self.request.get_json()
        
        callback_data = {
            'event_type': data.get('eventType'),
            'transaction_id': data.get('transactionId'),
            'status': data.get('status'),
            'amount': data.get('amount'),
            'currency': data.get('currency'),
            'msisdn': data.get('msisdn'),
            'timestamp': datetime.utcnow().isoformat()
        }
        
        self.log_callback(callback_data)
        return callback_data
        
    def get_provider_code(self) -> str:
        """Get provider code."""
        return 'vodafone'

def get_webhook_handler(request: Request) -> WebhookHandler:
    """Get appropriate webhook handler for request."""
    provider_map = {
        '/webhooks/mtn': MTNWebhookHandler,
        '/webhooks/airtel': AirtelWebhookHandler,
        '/webhooks/vodafone': VodafoneWebhookHandler
    }
    
    handler_class = provider_map.get(request.path)
    if not handler_class:
        raise ValueError(f"No webhook handler found for path: {request.path}")
        
    return handler_class(request)
