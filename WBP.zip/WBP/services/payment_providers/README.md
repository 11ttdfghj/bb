# Mobile Money Payment Provider Integration

This module provides integration with major mobile money providers in Ghana:
- MTN Mobile Money
- Airtel Money
- Vodafone Cash

## Overview

The payment provider integration consists of:

1. Provider-specific clients (`mtn_client.py`, `airtel_client.py`, `vodafone_client.py`)
2. Provider factory for client management (`provider_factory.py`)
3. Configuration settings in `app/config.py`

## Features

- Payment collection (deposits)
- Disbursements (withdrawals)
- Transaction status checking
- Wallet number validation
- Amount validation
- Comprehensive error handling
- Automatic provider detection based on wallet number
- Token-based authentication with automatic renewal

## Configuration

Each provider requires specific API credentials that should be set in environment variables:

### MTN Mobile Money
```
MTN_API_KEY=your-api-key
MTN_API_SECRET=your-api-secret
MTN_ENVIRONMENT=sandbox|production
```

### Airtel Money
```
AIRTEL_CLIENT_ID=your-client-id
AIRTEL_CLIENT_SECRET=your-client-secret
AIRTEL_ENVIRONMENT=sandbox|production
```

### Vodafone Cash
```
VODAFONE_MERCHANT_ID=your-merchant-id
VODAFONE_API_KEY=your-api-key
VODAFONE_ENVIRONMENT=sandbox|production
VODAFONE_CALLBACK_BASE_URL=your-callback-base-url
```

## Usage

### Get Provider Instance
```python
from services.payment_providers.provider_factory import PaymentProviderFactory

# Get by provider code
mtn_client = PaymentProviderFactory.get_provider('mtn')

# Get by wallet number
wallet = '0241234567'
provider = PaymentProviderFactory.get_provider_for_wallet(wallet)
```

### Initiate Payment
```python
payment_data = {
    'amount': 100.0,
    'wallet': '0241234567',
    'reference': 'PAYMENT-123'
}

result = provider.initiate_payment(payment_data)
```

### Initiate Withdrawal
```python
withdrawal_data = {
    'amount': 50.0,
    'wallet': '0241234567',
    'reference': 'WITHDRAWAL-123'
}

result = provider.initiate_withdrawal(withdrawal_data)
```

### Check Transaction Status
```python
status = provider.check_status('transaction-reference-id')
```

### Validate Wallet Number
```python
is_valid = PaymentProviderFactory.validate_wallet_number('0241234567')
```

### Validate Amount
```python
is_valid = PaymentProviderFactory.validate_amount('mtn', 100.0)
```

## Error Handling

All provider clients include comprehensive error handling:
- API errors
- Network errors
- Authentication errors
- Validation errors

Errors are raised as exceptions with detailed error messages and codes.

## Development

### Adding a New Provider

1. Create a new client class implementing the standard interface
2. Add provider configuration to `app/config.py`
3. Register the provider in `PaymentProviderFactory._providers`

### Testing

Each provider has sandbox environments for testing:
- Use test credentials
- Test wallets
- Test transaction flows

## Security Considerations

1. API credentials are managed through environment variables
2. Tokens are automatically renewed
3. HTTPS is enforced for all API calls
4. Request signing where required (e.g., Airtel)
5. Comprehensive transaction logging
