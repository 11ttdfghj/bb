import africastalking
from datetime import datetime
from flask import current_app
from models.notification import NotificationChannel, NotificationPriority

class SMSService:
    def __init__(self, username=None, api_key=None):
        # Initialize Africa's Talking
        self.username = username or current_app.config['AT_USERNAME']
        self.api_key = api_key or current_app.config['AT_API_KEY']
        
        africastalking.initialize(self.username, self.api_key)
        self.sms = africastalking.SMS

    async def send_sms(self, notification):
        """Send SMS using Africa's Talking"""
        try:
            # Format message based on priority
            prefix = ""
            if notification.priority == NotificationPriority.URGENT:
                prefix = "🚨 URGENT: "
            elif notification.priority == NotificationPriority.HIGH:
                prefix = "⚠️ IMPORTANT: "

            message = f"{prefix}{notification.title}\n\n{notification.message}"
            
            # Send message
            response = await self.sms.send(
                message,
                [notification.phone_number],
                callback=self._handle_callback
            )

            # Update notification status
            notification.is_sent = True
            notification.sent_at = datetime.utcnow()
            
            return response
        except Exception as e:
            current_app.logger.error(f"SMS sending failed: {str(e)}")
            raise

    def _handle_callback(self, error, response):
        """Handle SMS delivery callback"""
        if error is not None:
            current_app.logger.error(f"SMS delivery failed: {str(error)}")
        else:
            # Log successful delivery
            current_app.logger.info(f"SMS delivered successfully: {response}")

    @staticmethod
    def format_phone_number(phone_number):
        """Format phone number to international format"""
        # Remove any spaces or special characters
        cleaned = ''.join(filter(str.isdigit, phone_number))
        
        # Add country code if not present
        if len(cleaned) == 10 and cleaned.startswith('0'):
            cleaned = '233' + cleaned[1:]
        elif len(cleaned) == 9:
            cleaned = '233' + cleaned
            
        return '+' + cleaned
