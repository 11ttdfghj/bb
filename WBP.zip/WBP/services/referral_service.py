from datetime import datetime, timedelta
from typing import List, Optional, Tuple
from models.support import Referral, ReferralStatus, ReferralRewardType
from app import db
from services.notification_service import NotificationService

class ReferralService:
    def __init__(self):
        self.notification_service = NotificationService()

    def create_referral(
        self,
        referrer_id: int,
        referred_email: str,
        reward_type: ReferralRewardType
    ) -> Tuple[Referral, bool]:
        """Create new referral."""
        # Check if email was already referred
        existing_referral = Referral.query.filter_by(
            referred_email=referred_email
        ).first()
        if existing_referral:
            return existing_referral, False

        # Create referral with expiry date (30 days)
        referral = Referral(
            referrer_id=referrer_id,
            referred_email=referred_email,
            reward_type=reward_type,
            expires_at=datetime.utcnow() + timedelta(days=30)
        )
        
        db.session.add(referral)
        db.session.commit()
        
        # Send invitation email
        self._send_referral_invitation(referral)
        
        return referral, True

    def get_referral(self, referral_id: int) -> Optional[Referral]:
        """Get referral by ID."""
        return Referral.query.get(referral_id)

    def get_user_referrals(self, user_id: int) -> List[Referral]:
        """Get all referrals from a user."""
        return Referral.query.filter_by(referrer_id=user_id).order_by(
            Referral.created_at.desc()
        ).all()

    def get_pending_referrals(self) -> List[Referral]:
        """Get all pending referrals."""
        return Referral.query.filter_by(status=ReferralStatus.PENDING).all()

    def complete_referral(
        self,
        referral_id: int,
        referred_user_id: int
    ) -> bool:
        """Complete a referral when referred user signs up."""
        referral = self.get_referral(referral_id)
        if not referral or referral.status != ReferralStatus.PENDING:
            return False
            
        # Check if referral hasn't expired
        if referral.expires_at and referral.expires_at < datetime.utcnow():
            referral.status = ReferralStatus.EXPIRED
            db.session.commit()
            return False
            
        # Update referral
        referral.referred_user_id = referred_user_id
        referral.status = ReferralStatus.COMPLETED
        referral.completed_at = datetime.utcnow()
        db.session.commit()
        
        # Process reward
        self._process_reward(referral)
        
        return True

    def cancel_referral(self, referral_id: int) -> bool:
        """Cancel a pending referral."""
        referral = self.get_referral(referral_id)
        if not referral or referral.status != ReferralStatus.PENDING:
            return False
            
        referral.status = ReferralStatus.CANCELLED
        db.session.commit()
        
        return True

    def get_referral_stats(self, user_id: int) -> dict:
        """Get referral statistics for a user."""
        referrals = self.get_user_referrals(user_id)
        
        stats = {
            'total': len(referrals),
            'pending': sum(1 for r in referrals if r.status == ReferralStatus.PENDING),
            'completed': sum(1 for r in referrals if r.status == ReferralStatus.COMPLETED),
            'expired': sum(1 for r in referrals if r.status == ReferralStatus.EXPIRED),
            'cancelled': sum(1 for r in referrals if r.status == ReferralStatus.CANCELLED),
            'rewards_earned': self._calculate_rewards_earned(referrals)
        }
        
        return stats

    def check_expired_referrals(self) -> int:
        """Check and update expired referrals."""
        now = datetime.utcnow()
        expired_referrals = Referral.query.filter(
            Referral.status == ReferralStatus.PENDING,
            Referral.expires_at < now
        ).all()
        
        count = 0
        for referral in expired_referrals:
            referral.status = ReferralStatus.EXPIRED
            count += 1
            
            # Notify referrer
            self._notify_referral_expired(referral)
        
        if count > 0:
            db.session.commit()
            
        return count

    def _process_reward(self, referral: Referral):
        """Process reward for completed referral."""
        if referral.reward_type == ReferralRewardType.CASH:
            self._process_cash_reward(referral)
        elif referral.reward_type == ReferralRewardType.POINTS:
            self._process_points_reward(referral)
        elif referral.reward_type == ReferralRewardType.DISCOUNT:
            self._process_discount_reward(referral)
            
        # Notify referrer of reward
        self._notify_reward_earned(referral)

    def _process_cash_reward(self, referral: Referral):
        """Process cash reward."""
        # Implement cash reward logic
        pass

    def _process_points_reward(self, referral: Referral):
        """Process points reward."""
        # Implement points reward logic
        pass

    def _process_discount_reward(self, referral: Referral):
        """Process discount reward."""
        # Implement discount reward logic
        pass

    def _calculate_rewards_earned(self, referrals: List[Referral]) -> dict:
        """Calculate total rewards earned from referrals."""
        rewards = {
            'cash': 0,
            'points': 0,
            'discounts': 0
        }
        
        for referral in referrals:
            if referral.status == ReferralStatus.COMPLETED:
                if referral.reward_type == ReferralRewardType.CASH:
                    rewards['cash'] += 1
                elif referral.reward_type == ReferralRewardType.POINTS:
                    rewards['points'] += 1
                elif referral.reward_type == ReferralRewardType.DISCOUNT:
                    rewards['discounts'] += 1
                    
        return rewards

    def _send_referral_invitation(self, referral: Referral):
        """Send referral invitation email."""
        # Implement email sending logic
        pass

    def _notify_referral_expired(self, referral: Referral):
        """Notify referrer that referral has expired."""
        self.notification_service.send_notification(
            user_id=referral.referrer_id,
            title="Referral Expired",
            message=f"Your referral for {referral.referred_email} has expired",
            notification_type="REFERRAL",
            priority="LOW"
        )

    def _notify_reward_earned(self, referral: Referral):
        """Notify referrer of earned reward."""
        self.notification_service.send_notification(
            user_id=referral.referrer_id,
            title="Referral Reward Earned",
            message=f"You've earned a {referral.reward_type.value} reward for your referral!",
            notification_type="REFERRAL",
            priority="HIGH"
        )
