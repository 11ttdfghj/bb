from datetime import datetime, timedelta
from typing import List, Optional
from models.support import (
    SupportTicket, SupportMessage, SupportTicketStatus,
    SupportTicketPriority, SupportTicketCategory
)
from models.user import User
from app import db
from services.notification_service import NotificationService

class SupportService:
    def __init__(self):
        self.notification_service = NotificationService()

    def create_ticket(
        self,
        user_id: int,
        subject: str,
        description: str,
        category: SupportTicketCategory,
        priority: Optional[SupportTicketPriority] = None
    ) -> SupportTicket:
        """Create a new support ticket."""
        ticket = SupportTicket(
            user_id=user_id,
            subject=subject,
            description=description,
            category=category,
            priority=priority or SupportTicketPriority.MEDIUM
        )
        
        db.session.add(ticket)
        db.session.commit()
        
        # Notify support team
        self._notify_support_team(ticket)
        
        return ticket

    def get_ticket(self, ticket_id: int) -> Optional[SupportTicket]:
        """Get a support ticket by ID."""
        return SupportTicket.query.get(ticket_id)

    def get_user_tickets(self, user_id: int) -> List[SupportTicket]:
        """Get all tickets for a user."""
        return SupportTicket.query.filter_by(user_id=user_id).order_by(
            SupportTicket.created_at.desc()
        ).all()

    def get_agent_tickets(self, agent_id: int) -> List[SupportTicket]:
        """Get all tickets assigned to an agent."""
        return SupportTicket.query.filter_by(assigned_to=agent_id).order_by(
            SupportTicket.priority.desc(),
            SupportTicket.created_at.asc()
        ).all()

    def assign_ticket(self, ticket_id: int, agent_id: int) -> bool:
        """Assign a ticket to a support agent."""
        ticket = self.get_ticket(ticket_id)
        if not ticket:
            return False
            
        ticket.assigned_to = agent_id
        ticket.status = SupportTicketStatus.IN_PROGRESS
        db.session.commit()
        
        # Notify agent
        self._notify_agent_assignment(ticket)
        
        return True

    def update_ticket_status(
        self,
        ticket_id: int,
        status: SupportTicketStatus,
        resolution_note: Optional[str] = None
    ) -> bool:
        """Update ticket status."""
        ticket = self.get_ticket(ticket_id)
        if not ticket:
            return False
            
        ticket.status = status
        if status == SupportTicketStatus.RESOLVED:
            ticket.resolved_at = datetime.utcnow()
            if resolution_note:
                self.add_internal_note(ticket_id, ticket.assigned_to, resolution_note)
                
        db.session.commit()
        
        # Notify user of status change
        self._notify_status_change(ticket)
        
        return True

    def add_message(
        self,
        ticket_id: int,
        sender_id: int,
        message: str,
        is_internal: bool = False
    ) -> Optional[SupportMessage]:
        """Add a message to a support ticket."""
        ticket = self.get_ticket(ticket_id)
        if not ticket:
            return None
            
        support_message = SupportMessage(
            ticket_id=ticket_id,
            sender_id=sender_id,
            message=message,
            is_internal=is_internal
        )
        
        db.session.add(support_message)
        ticket.updated_at = datetime.utcnow()
        db.session.commit()
        
        # Notify relevant parties
        self._notify_new_message(support_message)
        
        return support_message

    def add_internal_note(
        self,
        ticket_id: int,
        agent_id: int,
        note: str
    ) -> Optional[SupportMessage]:
        """Add an internal note to a ticket."""
        return self.add_message(ticket_id, agent_id, note, is_internal=True)

    def get_ticket_messages(
        self,
        ticket_id: int,
        include_internal: bool = False
    ) -> List[SupportMessage]:
        """Get all messages for a ticket."""
        query = SupportMessage.query.filter_by(ticket_id=ticket_id)
        if not include_internal:
            query = query.filter_by(is_internal=False)
        return query.order_by(SupportMessage.created_at.asc()).all()

    def _notify_support_team(self, ticket: SupportTicket):
        """Notify support team of new ticket."""
        # Get support team members
        support_agents = User.query.filter_by(role='support_agent').all()
        
        for agent in support_agents:
            self.notification_service.send_notification(
                user_id=agent.id,
                title="New Support Ticket",
                message=f"New {ticket.priority.value} priority ticket: {ticket.subject}",
                notification_type="SUPPORT",
                priority="HIGH" if ticket.priority in [SupportTicketPriority.HIGH, SupportTicketPriority.URGENT] else "MEDIUM"
            )

    def _notify_agent_assignment(self, ticket: SupportTicket):
        """Notify agent of ticket assignment."""
        if ticket.assigned_to:
            self.notification_service.send_notification(
                user_id=ticket.assigned_to,
                title="Ticket Assigned",
                message=f"You have been assigned ticket #{ticket.id}: {ticket.subject}",
                notification_type="SUPPORT",
                priority="HIGH" if ticket.priority in [SupportTicketPriority.HIGH, SupportTicketPriority.URGENT] else "MEDIUM"
            )

    def _notify_status_change(self, ticket: SupportTicket):
        """Notify user of ticket status change."""
        self.notification_service.send_notification(
            user_id=ticket.user_id,
            title="Support Ticket Update",
            message=f"Your ticket #{ticket.id} status has been updated to: {ticket.status.value}",
            notification_type="SUPPORT",
            priority="MEDIUM"
        )

    def _notify_new_message(self, message: SupportMessage):
        """Notify relevant parties of new message."""
        ticket = message.ticket
        
        # If internal note, notify only support team
        if message.is_internal:
            if ticket.assigned_to and ticket.assigned_to != message.sender_id:
                self.notification_service.send_notification(
                    user_id=ticket.assigned_to,
                    title="New Internal Note",
                    message=f"New internal note added to ticket #{ticket.id}",
                    notification_type="SUPPORT",
                    priority="MEDIUM"
                )
            return
            
        # Notify user if message is from support
        if message.sender_id != ticket.user_id:
            self.notification_service.send_notification(
                user_id=ticket.user_id,
                title="New Support Response",
                message=f"New response on your ticket #{ticket.id}",
                notification_type="SUPPORT",
                priority="MEDIUM"
            )
        
        # Notify agent if message is from user
        elif ticket.assigned_to:
            self.notification_service.send_notification(
                user_id=ticket.assigned_to,
                title="New User Message",
                message=f"New message from user on ticket #{ticket.id}",
                notification_type="SUPPORT",
                priority="HIGH"
            )
