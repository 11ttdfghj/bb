import logging
from datetime import datetime
from flask import current_app
from flask_login import current_user
from cryptography.fernet import Fernet
from models.notification import Notification, NotificationAnalytics, NotificationChannel, NotificationPriority, NotificationGroup
from services.sms_service import SMSService
import json
import hashlib
import hmac
import os

class NotificationService:
    def __init__(self):
        self.sms_service = SMSService()
        # Initialize encryption key
        self._init_encryption()
        # Set up logging
        self._setup_logging()
        
    def _init_encryption(self):
        """Initialize encryption for sensitive notification data"""
        key = current_app.config.get('NOTIFICATION_ENCRYPTION_KEY')
        if not key:
            key = Fernet.generate_key()
            current_app.config['NOTIFICATION_ENCRYPTION_KEY'] = key
        self.cipher_suite = Fernet(key)
        
    def _setup_logging(self):
        """Set up secure logging for notification events"""
        self.logger = logging.getLogger('notification_service')
        self.logger.setLevel(logging.INFO)
        
        # Create secure log handler
        handler = logging.FileHandler('logs/notification_audit.log')
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s - User: %(user)s'
        )
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
        
    def _encrypt_sensitive_data(self, data):
        """Encrypt sensitive notification data"""
        if isinstance(data, str):
            return self.cipher_suite.encrypt(data.encode()).decode()
        return data
        
    def _decrypt_sensitive_data(self, encrypted_data):
        """Decrypt sensitive notification data"""
        if isinstance(encrypted_data, str):
            return self.cipher_suite.decrypt(encrypted_data.encode()).decode()
        return encrypted_data
        
    def _generate_hmac(self, data):
        """Generate HMAC for data integrity verification"""
        key = current_app.config.get('HMAC_KEY', os.urandom(32))
        h = hmac.new(key, msg=json.dumps(data).encode(), digestmod=hashlib.sha256)
        return h.hexdigest()
        
    def _verify_hmac(self, data, signature):
        """Verify HMAC signature for data integrity"""
        expected_signature = self._generate_hmac(data)
        return hmac.compare_digest(signature, expected_signature)
        
    def _log_notification_event(self, event_type, details, user_id=None):
        """Securely log notification events"""
        extra = {'user': user_id or (current_user.id if current_user else 'system')}
        self.logger.info(f"{event_type}: {details}", extra=extra)
        
    async def send_notification(self, user_id, title, message, notification_type, priority, channel, phone_number=None):
        """Send notification with enhanced security"""
        try:
            # Validate user permissions
            if not self._verify_user_permissions(user_id):
                raise PermissionError("Unauthorized notification attempt")
                
            # Encrypt sensitive data
            encrypted_message = self._encrypt_sensitive_data(message)
            
            # Create notification with integrity check
            notification_data = {
                'user_id': user_id,
                'title': title,
                'message': encrypted_message,
                'type': notification_type,
                'priority': priority,
                'channel': channel,
                'created_at': datetime.utcnow()
            }
            
            # Generate HMAC for data integrity
            notification_data['integrity_check'] = self._generate_hmac(notification_data)
            
            # Log notification creation
            self._log_notification_event(
                'NOTIFICATION_CREATED',
                f"Type: {notification_type}, Channel: {channel}, Priority: {priority}"
            )
            
            # Handle different notification channels securely
            if channel in [NotificationChannel.SMS, NotificationChannel.BOTH]:
                if not phone_number:
                    raise ValueError("Phone number required for SMS notifications")
                    
                # Validate phone number format
                validated_phone = self._validate_phone_number(phone_number)
                await self.sms_service.send_sms(validated_phone, message)
                
            if channel in [NotificationChannel.WEB_PUSH, NotificationChannel.BOTH]:
                # Implement secure web push notification
                await self._send_secure_web_push(user_id, notification_data)
                
            # Track notification analytics securely
            await self._track_notification_analytics(notification_data)
            
            return True
            
        except Exception as e:
            self._log_notification_event('NOTIFICATION_ERROR', str(e))
            raise
            
    def _verify_user_permissions(self, user_id):
        """Verify user permissions for notifications"""
        try:
            # Check if current user has permission to send notifications
            if not current_user or not current_user.is_authenticated:
                return False
                
            # Allow system notifications
            if current_user.is_admin or current_user.id == user_id:
                return True
                
            return False
            
        except Exception as e:
            self._log_notification_event('PERMISSION_CHECK_ERROR', str(e))
            return False
            
    def _validate_phone_number(self, phone_number):
        """Validate and sanitize phone number"""
        # Remove any non-numeric characters
        cleaned = ''.join(filter(str.isdigit, phone_number))
        
        # Validate Ghana phone number format
        if len(cleaned) == 10 and cleaned.startswith('0'):
            return '+233' + cleaned[1:]
        elif len(cleaned) == 12 and cleaned.startswith('233'):
            return '+' + cleaned
            
        raise ValueError("Invalid phone number format")
        
    async def _send_secure_web_push(self, user_id, notification_data):
        """Send secure web push notification"""
        try:
            # Implement web push with proper encryption
            # This is a placeholder for actual web push implementation
            pass
            
        except Exception as e:
            self._log_notification_event('WEB_PUSH_ERROR', str(e))
            raise
            
    async def _track_notification_analytics(self, notification_data):
        """Track notification analytics securely"""
        try:
            analytics = NotificationAnalytics(
                notification_id=notification_data.get('id'),
                delivery_status='sent',
                delivery_time=datetime.utcnow(),
                channel=notification_data['channel'],
                user_id=notification_data['user_id']
            )
            # Save analytics securely
            
        except Exception as e:
            self._log_notification_event('ANALYTICS_ERROR', str(e))
            raise

    async def track_notification_analytics(self, notification_id, user_id, event_type, platform=None, device_type=None):
        """Track notification analytics"""
        try:
            analytics = NotificationAnalytics.query.filter_by(
                notification_id=notification_id,
                user_id=user_id
            ).first()

            if not analytics:
                analytics = NotificationAnalytics(
                    notification_id=notification_id,
                    user_id=user_id,
                    platform=platform,
                    device_type=device_type
                )
                db.session.add(analytics)

            # Update appropriate timestamp based on event
            if event_type == 'delivered':
                analytics.delivered_at = datetime.utcnow()
            elif event_type == 'read':
                analytics.read_at = datetime.utcnow()
            elif event_type == 'clicked':
                analytics.clicked_at = datetime.utcnow()

            db.session.commit()
            return analytics

        except Exception as e:
            self._log_notification_event('ANALYTICS_ERROR', str(e))
            raise

    def get_notification_stats(self, user_id=None, start_date=None, end_date=None):
        """Get notification statistics"""
        query = db.session.query(
            Notification.type,
            Notification.priority,
            Notification.channel,
            db.func.count(Notification.id).label('total_count'),
            db.func.sum(db.case([(Notification.is_sent, 1)], else_=0)).label('sent_count'),
            db.func.sum(db.case([(Notification.is_read, 1)], else_=0)).label('read_count')
        )

        if user_id:
            query = query.filter(Notification.user_id == user_id)
        if start_date:
            query = query.filter(Notification.created_at >= start_date)
        if end_date:
            query = query.filter(Notification.created_at <= end_date)

        return query.group_by(
            Notification.type,
            Notification.priority,
            Notification.channel
        ).all()

    def get_notification_groups(self, user_id):
        """Get user's notification groups"""
        return NotificationGroup.query.join(Notification).filter(
            Notification.user_id == user_id
        ).distinct().all()

    def mark_notifications_as_read(self, notification_ids, user_id):
        """Mark multiple notifications as read"""
        try:
            notifications = Notification.query.filter(
                Notification.id.in_(notification_ids),
                Notification.user_id == user_id
            ).all()

            for notification in notifications:
                notification.is_read = True
                self.track_notification_analytics(
                    notification.id,
                    user_id,
                    'read'
                )

            db.session.commit()
            return len(notifications)

        except Exception as e:
            self._log_notification_event('MARK_AS_READ_ERROR', str(e))
            raise
