from datetime import datetime
from typing import List, Optional, Dict, Any
from decimal import Decimal
from enum import Enum
from app import db
from services.notification_service import NotificationService

class PaymentProvider(Enum):
    MTN = "mtn"
    AIRTEL = "airtel"
    VODAFONE = "vodafone"
    BANK = "bank"

class TransactionType(Enum):
    DEPOSIT = "deposit"
    WITHDRAWAL = "withdrawal"
    TRANSFER = "transfer"

class TransactionStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    REVERSED = "reversed"

class PaymentIntegrationService:
    def __init__(self):
        self.notification_service = NotificationService()
        self._initialize_providers()

    def _initialize_providers(self):
        """Initialize connections to payment providers."""
        self.providers = {
            PaymentProvider.MTN: self._get_mtn_client(),
            PaymentProvider.AIRTEL: self._get_airtel_client(),
            PaymentProvider.VODAFONE: self._get_vodafone_client()
        }

    def initiate_deposit(
        self,
        user_id: int,
        amount: Decimal,
        provider: PaymentProvider,
        wallet_number: str
    ) -> Dict[str, Any]:
        """Initiate a deposit from mobile money to susu account."""
        # Validate amount and wallet number
        self._validate_transaction(amount, wallet_number, provider)
        
        # Create transaction record
        transaction = self._create_transaction(
            user_id=user_id,
            amount=amount,
            transaction_type=TransactionType.DEPOSIT,
            provider=provider,
            wallet_number=wallet_number
        )
        
        try:
            # Initialize payment with provider
            provider_client = self.providers[provider]
            payment_response = provider_client.initiate_payment({
                'amount': str(amount),
                'wallet': wallet_number,
                'reference': transaction.reference,
                'callback_url': self._get_callback_url(transaction.id)
            })
            
            # Update transaction with provider reference
            transaction.provider_reference = payment_response['provider_reference']
            transaction.status = TransactionStatus.PROCESSING
            db.session.commit()
            
            return {
                'transaction_id': transaction.id,
                'reference': transaction.reference,
                'provider_reference': transaction.provider_reference,
                'status': transaction.status.value,
                'payment_url': payment_response.get('payment_url')
            }
            
        except Exception as e:
            transaction.status = TransactionStatus.FAILED
            transaction.error_message = str(e)
            db.session.commit()
            raise

    def initiate_withdrawal(
        self,
        user_id: int,
        amount: Decimal,
        provider: PaymentProvider,
        wallet_number: str
    ) -> Dict[str, Any]:
        """Initiate a withdrawal from susu account to mobile money."""
        # Validate amount, wallet and available balance
        self._validate_transaction(amount, wallet_number, provider)
        self._validate_withdrawal(user_id, amount)
        
        # Create transaction record
        transaction = self._create_transaction(
            user_id=user_id,
            amount=amount,
            transaction_type=TransactionType.WITHDRAWAL,
            provider=provider,
            wallet_number=wallet_number
        )
        
        try:
            # Initialize withdrawal with provider
            provider_client = self.providers[provider]
            withdrawal_response = provider_client.initiate_withdrawal({
                'amount': str(amount),
                'wallet': wallet_number,
                'reference': transaction.reference
            })
            
            # Update transaction with provider reference
            transaction.provider_reference = withdrawal_response['provider_reference']
            transaction.status = TransactionStatus.PROCESSING
            db.session.commit()
            
            return {
                'transaction_id': transaction.id,
                'reference': transaction.reference,
                'provider_reference': transaction.provider_reference,
                'status': transaction.status.value
            }
            
        except Exception as e:
            transaction.status = TransactionStatus.FAILED
            transaction.error_message = str(e)
            db.session.commit()
            raise

    def process_callback(
        self,
        provider: PaymentProvider,
        callback_data: Dict[str, Any]
    ) -> bool:
        """Process payment callback from provider."""
        transaction = self._get_transaction_by_reference(
            callback_data['reference']
        )
        if not transaction:
            return False
            
        if callback_data['status'] == 'success':
            transaction.status = TransactionStatus.COMPLETED
            self._process_successful_transaction(transaction)
        else:
            transaction.status = TransactionStatus.FAILED
            transaction.error_message = callback_data.get('error')
            self._notify_transaction_failed(transaction)
            
        db.session.commit()
        return True

    def get_transaction_status(
        self,
        transaction_id: int
    ) -> Optional[Dict[str, Any]]:
        """Get current status of a transaction."""
        transaction = self._get_transaction(transaction_id)
        if not transaction:
            return None
            
        # Check with provider if still processing
        if transaction.status == TransactionStatus.PROCESSING:
            self._check_provider_status(transaction)
            
        return {
            'transaction_id': transaction.id,
            'reference': transaction.reference,
            'provider_reference': transaction.provider_reference,
            'status': transaction.status.value,
            'amount': str(transaction.amount),
            'created_at': transaction.created_at.isoformat(),
            'completed_at': transaction.completed_at.isoformat() if transaction.completed_at else None,
            'error_message': transaction.error_message
        }

    def get_user_transactions(
        self,
        user_id: int,
        transaction_type: Optional[TransactionType] = None,
        status: Optional[TransactionStatus] = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get user's transaction history."""
        query = Transaction.query.filter_by(user_id=user_id)
        
        if transaction_type:
            query = query.filter_by(transaction_type=transaction_type)
        if status:
            query = query.filter_by(status=status)
            
        transactions = query.order_by(
            Transaction.created_at.desc()
        ).limit(limit).all()
        
        return [{
            'transaction_id': t.id,
            'reference': t.reference,
            'type': t.transaction_type.value,
            'status': t.status.value,
            'amount': str(t.amount),
            'provider': t.provider.value,
            'wallet_number': t.wallet_number,
            'created_at': t.created_at.isoformat(),
            'completed_at': t.completed_at.isoformat() if t.completed_at else None
        } for t in transactions]

    def _validate_transaction(
        self,
        amount: Decimal,
        wallet_number: str,
        provider: PaymentProvider
    ):
        """Validate transaction details."""
        if amount <= 0:
            raise ValueError("Amount must be greater than 0")
            
        if not self._validate_wallet_number(wallet_number, provider):
            raise ValueError(f"Invalid wallet number for {provider.value}")

    def _validate_withdrawal(self, user_id: int, amount: Decimal):
        """Validate withdrawal amount against available balance."""
        balance = self._get_user_balance(user_id)
        if balance < amount:
            raise ValueError("Insufficient balance")

    def _create_transaction(
        self,
        user_id: int,
        amount: Decimal,
        transaction_type: TransactionType,
        provider: PaymentProvider,
        wallet_number: str
    ) -> 'Transaction':
        """Create a new transaction record."""
        transaction = Transaction(
            user_id=user_id,
            amount=amount,
            transaction_type=transaction_type,
            provider=provider,
            wallet_number=wallet_number,
            reference=self._generate_reference(),
            status=TransactionStatus.PENDING
        )
        
        db.session.add(transaction)
        db.session.commit()
        
        return transaction

    def _process_successful_transaction(self, transaction: 'Transaction'):
        """Process a successful transaction."""
        transaction.completed_at = datetime.utcnow()
        
        if transaction.transaction_type == TransactionType.DEPOSIT:
            self._credit_user_account(
                transaction.user_id,
                transaction.amount
            )
        elif transaction.transaction_type == TransactionType.WITHDRAWAL:
            self._debit_user_account(
                transaction.user_id,
                transaction.amount
            )
            
        self._notify_transaction_success(transaction)

    def _notify_transaction_success(self, transaction: 'Transaction'):
        """Notify user of successful transaction."""
        message = (
            f"Your {transaction.transaction_type.value} of "
            f"GHS {transaction.amount} via {transaction.provider.value} "
            f"has been completed successfully."
        )
        
        self.notification_service.send_notification(
            user_id=transaction.user_id,
            title="Transaction Successful",
            message=message,
            notification_type="PAYMENT",
            priority="HIGH"
        )

    def _notify_transaction_failed(self, transaction: 'Transaction'):
        """Notify user of failed transaction."""
        message = (
            f"Your {transaction.transaction_type.value} of "
            f"GHS {transaction.amount} via {transaction.provider.value} "
            f"has failed. {transaction.error_message}"
        )
        
        self.notification_service.send_notification(
            user_id=transaction.user_id,
            title="Transaction Failed",
            message=message,
            notification_type="PAYMENT",
            priority="HIGH"
        )

    # Provider-specific client initialization methods
    def _get_mtn_client(self):
        """Initialize MTN Mobile Money client."""
        # Implement MTN client initialization
        pass

    def _get_airtel_client(self):
        """Initialize Airtel Money client."""
        # Implement Airtel client initialization
        pass

    def _get_vodafone_client(self):
        """Initialize Vodafone Cash client."""
        # Implement Vodafone client initialization
        pass

    # Helper methods
    def _validate_wallet_number(self, wallet_number: str, provider: PaymentProvider) -> bool:
        """Validate mobile money wallet number format."""
        # Implement provider-specific wallet number validation
        pass

    def _get_user_balance(self, user_id: int) -> Decimal:
        """Get user's current balance."""
        # Implement balance retrieval
        pass

    def _credit_user_account(self, user_id: int, amount: Decimal):
        """Credit amount to user's account."""
        # Implement account crediting
        pass

    def _debit_user_account(self, user_id: int, amount: Decimal):
        """Debit amount from user's account."""
        # Implement account debiting
        pass

    def _generate_reference(self) -> str:
        """Generate unique transaction reference."""
        # Implement reference generation
        pass

    def _get_callback_url(self, transaction_id: int) -> str:
        """Get callback URL for transaction."""
        # Implement callback URL generation
        pass

    def _get_transaction(self, transaction_id: int) -> Optional['Transaction']:
        """Get transaction by ID."""
        return Transaction.query.get(transaction_id)

    def _get_transaction_by_reference(self, reference: str) -> Optional['Transaction']:
        """Get transaction by reference."""
        return Transaction.query.filter_by(reference=reference).first()

    def _check_provider_status(self, transaction: 'Transaction'):
        """Check transaction status with provider."""
        provider_client = self.providers[transaction.provider]
        status = provider_client.check_status(transaction.provider_reference)
        
        if status['status'] == 'completed':
            transaction.status = TransactionStatus.COMPLETED
            self._process_successful_transaction(transaction)
        elif status['status'] == 'failed':
            transaction.status = TransactionStatus.FAILED
            transaction.error_message = status.get('error')
            self._notify_transaction_failed(transaction)
            
        db.session.commit()
