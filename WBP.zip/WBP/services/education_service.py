from datetime import datetime, timedelta
from sqlalchemy import func
from models.education import (
    EducationalContent, ContentComment, ForumTopic, ForumPost, 
    ForumReply, SavingsGroup, GroupMembership, Achievement, 
    UserAchievement, Challenge, ChallengeParticipant
)
from models.user_education import (
    UserEducationPreference, UserProgress, UserQuizAttempt,
    UserEngagement, LearningPath, UserLearningPath
)
from app import db

class EducationService:
    @staticmethod
    def track_content_progress(user_id, content_id, progress_percentage):
        """Track user's progress through educational content."""
        progress = UserProgress.query.filter_by(
            user_id=user_id, content_id=content_id
        ).first()
        
        if not progress:
            progress = UserProgress(
                user_id=user_id,
                content_id=content_id,
                progress_percentage=progress_percentage
            )
            db.session.add(progress)
        else:
            progress.progress_percentage = progress_percentage
            progress.last_accessed = datetime.utcnow()
        
        if progress_percentage >= 100:
            progress.completed = True
            engagement = UserEngagement.query.filter_by(user_id=user_id).first()
            if engagement:
                engagement.articles_read += 1
        
        db.session.commit()
        return progress

    @staticmethod
    def record_quiz_attempt(user_id, content_id, answers, score):
        """Record a user's quiz attempt."""
        attempt = UserQuizAttempt(
            user_id=user_id,
            content_id=content_id,
            answers=answers,
            score=score,
            completed_at=datetime.utcnow()
        )
        db.session.add(attempt)
        
        # Update user progress
        progress = UserProgress.query.filter_by(
            user_id=user_id, content_id=content_id
        ).first()
        
        if progress:
            if not progress.quiz_scores:
                progress.quiz_scores = []
            progress.quiz_scores.append({
                'attempt': len(progress.quiz_scores) + 1,
                'score': score,
                'date': datetime.utcnow().isoformat()
            })
        
        # Update engagement metrics
        engagement = UserEngagement.query.filter_by(user_id=user_id).first()
        if engagement:
            engagement.quizzes_completed += 1
            if score >= 80:  # High score achievement
                achievement = Achievement.query.filter_by(
                    name='Quiz Master'
                ).first()
                if achievement:
                    user_achievement = UserAchievement(
                        user_id=user_id,
                        achievement_id=achievement.id
                    )
                    db.session.add(user_achievement)
                    engagement.achievements_earned += 1
        
        db.session.commit()
        return attempt

    @staticmethod
    def create_savings_group(creator_id, name, description, target_amount, 
                           duration_weeks, member_limit=None, is_private=False):
        """Create a new savings group."""
        group = SavingsGroup(
            creator_id=creator_id,
            name=name,
            description=description,
            target_amount=target_amount,
            duration_weeks=duration_weeks,
            member_limit=member_limit,
            is_private=is_private
        )
        db.session.add(group)
        
        # Add creator as admin member
        membership = GroupMembership(
            group_id=group.id,
            user_id=creator_id,
            role='admin'
        )
        db.session.add(membership)
        
        db.session.commit()
        return group

    @staticmethod
    def join_savings_group(user_id, group_id):
        """Add user to a savings group."""
        group = SavingsGroup.query.get_or_404(group_id)
        
        # Check member limit
        if group.member_limit and len(group.members) >= group.member_limit:
            raise ValueError("Group has reached member limit")
        
        # Check if user is already a member
        existing_membership = GroupMembership.query.filter_by(
            user_id=user_id, group_id=group_id
        ).first()
        
        if existing_membership:
            raise ValueError("User is already a member of this group")
        
        membership = GroupMembership(
            group_id=group_id,
            user_id=user_id,
            role='member'
        )
        db.session.add(membership)
        db.session.commit()
        return membership

    @staticmethod
    def create_challenge(title, description, target_amount, duration_days, 
                        reward_points):
        """Create a new savings challenge."""
        start_date = datetime.utcnow()
        end_date = start_date + timedelta(days=duration_days)
        
        challenge = Challenge(
            title=title,
            description=description,
            target_amount=target_amount,
            reward_points=reward_points,
            start_date=start_date,
            end_date=end_date
        )
        db.session.add(challenge)
        db.session.commit()
        return challenge

    @staticmethod
    def join_challenge(user_id, challenge_id):
        """Add user to a savings challenge."""
        challenge = Challenge.query.get_or_404(challenge_id)
        
        # Check if challenge is still active
        if datetime.utcnow() > challenge.end_date:
            raise ValueError("Challenge has ended")
        
        # Check if user is already participating
        existing_participation = ChallengeParticipant.query.filter_by(
            user_id=user_id, challenge_id=challenge_id
        ).first()
        
        if existing_participation:
            raise ValueError("User is already participating in this challenge")
        
        participant = ChallengeParticipant(
            challenge_id=challenge_id,
            user_id=user_id
        )
        db.session.add(participant)
        db.session.commit()
        return participant

    @staticmethod
    def update_challenge_progress(user_id, challenge_id, amount):
        """Update user's progress in a challenge."""
        participant = ChallengeParticipant.query.filter_by(
            user_id=user_id, challenge_id=challenge_id
        ).first_or_404()
        
        challenge = Challenge.query.get_or_404(challenge_id)
        
        participant.current_amount += amount
        
        # Check if challenge is completed
        if not participant.completed and \
           participant.current_amount >= challenge.target_amount:
            participant.completed = True
            participant.completed_at = datetime.utcnow()
            
            # Update engagement metrics
            engagement = UserEngagement.query.filter_by(user_id=user_id).first()
            if engagement:
                engagement.challenges_completed += 1
                engagement.total_points += challenge.reward_points
        
        db.session.commit()
        return participant

    @staticmethod
    def create_learning_path(title, description, difficulty_level, 
                           estimated_duration, prerequisites, content_sequence):
        """Create a new learning path."""
        path = LearningPath(
            title=title,
            description=description,
            difficulty_level=difficulty_level,
            estimated_duration=estimated_duration,
            prerequisites=prerequisites,
            content_sequence=content_sequence
        )
        db.session.add(path)
        db.session.commit()
        return path

    @staticmethod
    def start_learning_path(user_id, path_id):
        """Start a user on a learning path."""
        # Check if user is already on this path
        existing_progress = UserLearningPath.query.filter_by(
            user_id=user_id, path_id=path_id, is_active=True
        ).first()
        
        if existing_progress:
            raise ValueError("User is already on this learning path")
        
        progress = UserLearningPath(
            user_id=user_id,
            path_id=path_id
        )
        db.session.add(progress)
        db.session.commit()
        return progress

    @staticmethod
    def update_path_progress(user_id, path_id):
        """Update user's progress in a learning path."""
        path_progress = UserLearningPath.query.filter_by(
            user_id=user_id, path_id=path_id, is_active=True
        ).first_or_404()
        
        path = LearningPath.query.get_or_404(path_id)
        total_steps = len(path.content_sequence)
        
        # Calculate progress based on completed content
        completed_content = UserProgress.query.filter(
            UserProgress.user_id == user_id,
            UserProgress.content_id.in_(path.content_sequence),
            UserProgress.completed == True
        ).count()
        
        path_progress.current_step = completed_content
        path_progress.progress_percentage = (completed_content / total_steps) * 100
        
        if path_progress.progress_percentage >= 100:
            path_progress.completed_at = datetime.utcnow()
            
            # Award achievement for completing learning path
            achievement = Achievement.query.filter_by(
                name='Path Completer'
            ).first()
            if achievement:
                user_achievement = UserAchievement(
                    user_id=user_id,
                    achievement_id=achievement.id
                )
                db.session.add(user_achievement)
                
                engagement = UserEngagement.query.filter_by(user_id=user_id).first()
                if engagement:
                    engagement.achievements_earned += 1
        
        db.session.commit()
        return path_progress
