from datetime import datetime
from typing import List, Optional
from models.support import (
    Feedback, FeedbackComment, FeedbackVote,
    FeedbackCategory, FeedbackStatus
)
from app import db
from services.notification_service import NotificationService

class FeedbackService:
    def __init__(self):
        self.notification_service = NotificationService()

    def create_feedback(
        self,
        user_id: int,
        title: str,
        description: str,
        category: FeedbackCategory
    ) -> Feedback:
        """Create new feedback."""
        feedback = Feedback(
            user_id=user_id,
            title=title,
            description=description,
            category=category
        )
        
        db.session.add(feedback)
        db.session.commit()
        
        # Notify product team
        self._notify_product_team(feedback)
        
        return feedback

    def get_feedback(self, feedback_id: int) -> Optional[Feedback]:
        """Get feedback by ID."""
        return Feedback.query.get(feedback_id)

    def get_user_feedback(self, user_id: int) -> List[Feedback]:
        """Get all feedback from a user."""
        return Feedback.query.filter_by(user_id=user_id).order_by(
            Feedback.created_at.desc()
        ).all()

    def get_feedback_by_category(
        self,
        category: FeedbackCategory,
        status: Optional[FeedbackStatus] = None
    ) -> List[Feedback]:
        """Get feedback by category and optionally status."""
        query = Feedback.query.filter_by(category=category)
        if status:
            query = query.filter_by(status=status)
        return query.order_by(Feedback.votes.desc()).all()

    def update_feedback_status(
        self,
        feedback_id: int,
        status: FeedbackStatus,
        comment: Optional[str] = None
    ) -> bool:
        """Update feedback status."""
        feedback = self.get_feedback(feedback_id)
        if not feedback:
            return False
            
        feedback.status = status
        if status == FeedbackStatus.IMPLEMENTED:
            feedback.implemented_at = datetime.utcnow()
            
        db.session.commit()
        
        # Add status change comment if provided
        if comment:
            self.add_comment(feedback_id, None, comment, is_official=True)
            
        # Notify user of status change
        self._notify_status_change(feedback)
        
        return True

    def add_comment(
        self,
        feedback_id: int,
        user_id: Optional[int],
        comment: str,
        is_official: bool = False
    ) -> Optional[FeedbackComment]:
        """Add a comment to feedback."""
        feedback = self.get_feedback(feedback_id)
        if not feedback:
            return None
            
        feedback_comment = FeedbackComment(
            feedback_id=feedback_id,
            user_id=user_id,
            comment=comment
        )
        
        db.session.add(feedback_comment)
        feedback.updated_at = datetime.utcnow()
        db.session.commit()
        
        # Notify relevant parties
        self._notify_new_comment(feedback_comment, is_official)
        
        return feedback_comment

    def vote_feedback(self, feedback_id: int, user_id: int) -> bool:
        """Vote for a feedback."""
        feedback = self.get_feedback(feedback_id)
        if not feedback:
            return False
            
        # Check if user already voted
        existing_vote = FeedbackVote.query.filter_by(
            feedback_id=feedback_id,
            user_id=user_id
        ).first()
        
        if existing_vote:
            return False
            
        # Add vote
        vote = FeedbackVote(feedback_id=feedback_id, user_id=user_id)
        db.session.add(vote)
        
        # Update vote count
        feedback.votes += 1
        db.session.commit()
        
        # Notify if feedback reaches vote threshold
        if feedback.votes in [10, 50, 100]:
            self._notify_vote_milestone(feedback)
        
        return True

    def remove_vote(self, feedback_id: int, user_id: int) -> bool:
        """Remove a vote from feedback."""
        vote = FeedbackVote.query.filter_by(
            feedback_id=feedback_id,
            user_id=user_id
        ).first()
        
        if not vote:
            return False
            
        feedback = self.get_feedback(feedback_id)
        if not feedback:
            return False
            
        db.session.delete(vote)
        feedback.votes -= 1
        db.session.commit()
        
        return True

    def get_trending_feedback(self, limit: int = 10) -> List[Feedback]:
        """Get trending feedback based on votes and recency."""
        return Feedback.query.order_by(
            Feedback.votes.desc(),
            Feedback.created_at.desc()
        ).limit(limit).all()

    def _notify_product_team(self, feedback: Feedback):
        """Notify product team of new feedback."""
        # Get product team members
        product_team = self._get_product_team_members()
        
        for member in product_team:
            self.notification_service.send_notification(
                user_id=member.id,
                title="New Product Feedback",
                message=f"New {feedback.category.value} feedback: {feedback.title}",
                notification_type="PRODUCT",
                priority="MEDIUM"
            )

    def _notify_status_change(self, feedback: Feedback):
        """Notify user of feedback status change."""
        self.notification_service.send_notification(
            user_id=feedback.user_id,
            title="Feedback Status Update",
            message=f"Your feedback '{feedback.title}' status has been updated to: {feedback.status.value}",
            notification_type="PRODUCT",
            priority="MEDIUM"
        )

    def _notify_new_comment(self, comment: FeedbackComment, is_official: bool):
        """Notify relevant parties of new comment."""
        feedback = comment.feedback
        
        # Notify feedback author of official response
        if is_official:
            self.notification_service.send_notification(
                user_id=feedback.user_id,
                title="Official Response to Your Feedback",
                message=f"New official response on your feedback: {feedback.title}",
                notification_type="PRODUCT",
                priority="MEDIUM"
            )
        
        # Notify product team of user comment
        elif comment.user_id != feedback.user_id:
            product_team = self._get_product_team_members()
            for member in product_team:
                self.notification_service.send_notification(
                    user_id=member.id,
                    title="New Feedback Comment",
                    message=f"New user comment on feedback: {feedback.title}",
                    notification_type="PRODUCT",
                    priority="LOW"
                )

    def _notify_vote_milestone(self, feedback: Feedback):
        """Notify product team when feedback reaches vote milestone."""
        product_team = self._get_product_team_members()
        
        for member in product_team:
            self.notification_service.send_notification(
                user_id=member.id,
                title="Feedback Vote Milestone",
                message=f"Feedback '{feedback.title}' has reached {feedback.votes} votes!",
                notification_type="PRODUCT",
                priority="HIGH"
            )

    def _get_product_team_members(self):
        """Get all product team members."""
        # This should be implemented based on your user roles system
        return []  # Placeholder
