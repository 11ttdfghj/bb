"""Transaction logging system for payment operations."""

import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app import config
from app.models import TransactionLog, WebhookLog

logger = logging.getLogger(__name__)

class TransactionLogger:
    """Logger for payment transactions and webhooks."""
    
    def __init__(self):
        self.engine = create_engine(config.DATABASE_URL)
        self.Session = sessionmaker(bind=self.engine)
        
    def log_transaction(
        self,
        transaction_type: str,
        provider: str,
        amount: float,
        wallet_number: str,
        status: str,
        reference: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """Log a payment transaction."""
        try:
            session = self.Session()
            
            log = TransactionLog(
                transaction_type=transaction_type,
                provider=provider,
                amount=amount,
                wallet_number=wallet_number,
                status=status,
                reference=reference,
                metadata=json.dumps(metadata or {}),
                created_at=datetime.utcnow()
            )
            
            session.add(log)
            session.commit()
            
            logger.info(
                "Transaction logged - Type: %s, Provider: %s, Reference: %s",
                transaction_type,
                provider,
                reference
            )
            
        except Exception as e:
            logger.error(
                "Error logging transaction - Type: %s, Provider: %s, Reference: %s, Error: %s",
                transaction_type,
                provider,
                reference,
                str(e)
            )
            session.rollback()
            raise
            
        finally:
            session.close()
            
    def log_webhook(
        self,
        provider: str,
        event_type: str,
        transaction_id: str,
        status: str,
        payload: Dict[str, Any]
    ) -> None:
        """Log a webhook callback."""
        try:
            session = self.Session()
            
            log = WebhookLog(
                provider=provider,
                event_type=event_type,
                transaction_id=transaction_id,
                status=status,
                payload=json.dumps(payload),
                created_at=datetime.utcnow()
            )
            
            session.add(log)
            session.commit()
            
            logger.info(
                "Webhook logged - Provider: %s, Event: %s, Transaction: %s",
                provider,
                event_type,
                transaction_id
            )
            
        except Exception as e:
            logger.error(
                "Error logging webhook - Provider: %s, Event: %s, Transaction: %s, Error: %s",
                provider,
                event_type,
                transaction_id,
                str(e)
            )
            session.rollback()
            raise
            
        finally:
            session.close()
            
    def get_transaction_status(self, reference: str) -> Optional[str]:
        """Get current status of a transaction."""
        try:
            session = self.Session()
            
            log = session.query(TransactionLog)\
                .filter_by(reference=reference)\
                .order_by(TransactionLog.created_at.desc())\
                .first()
                
            return log.status if log else None
            
        except Exception as e:
            logger.error(
                "Error retrieving transaction status - Reference: %s, Error: %s",
                reference,
                str(e)
            )
            raise
            
        finally:
            session.close()
            
    def get_transaction_history(
        self,
        wallet_number: Optional[str] = None,
        provider: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: int = 100
    ) -> list:
        """Get transaction history with optional filters."""
        try:
            session = self.Session()
            
            query = session.query(TransactionLog)
            
            if wallet_number:
                query = query.filter_by(wallet_number=wallet_number)
            if provider:
                query = query.filter_by(provider=provider)
            if start_date:
                query = query.filter(TransactionLog.created_at >= start_date)
            if end_date:
                query = query.filter(TransactionLog.created_at <= end_date)
                
            logs = query.order_by(TransactionLog.created_at.desc())\
                .limit(limit)\
                .all()
                
            return [log.to_dict() for log in logs]
            
        except Exception as e:
            logger.error(
                "Error retrieving transaction history - Error: %s",
                str(e)
            )
            raise
            
        finally:
            session.close()
            
    def get_webhook_history(
        self,
        provider: Optional[str] = None,
        event_type: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: int = 100
    ) -> list:
        """Get webhook history with optional filters."""
        try:
            session = self.Session()
            
            query = session.query(WebhookLog)
            
            if provider:
                query = query.filter_by(provider=provider)
            if event_type:
                query = query.filter_by(event_type=event_type)
            if start_date:
                query = query.filter(WebhookLog.created_at >= start_date)
            if end_date:
                query = query.filter(WebhookLog.created_at <= end_date)
                
            logs = query.order_by(WebhookLog.created_at.desc())\
                .limit(limit)\
                .all()
                
            return [log.to_dict() for log in logs]
            
        except Exception as e:
            logger.error(
                "Error retrieving webhook history - Error: %s",
                str(e)
            )
            raise
            
        finally:
            session.close()
