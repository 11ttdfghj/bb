from datetime import datetime
from typing import List, Optional, Dict, Any
from enum import Enum
from app import db
from services.notification_service import NotificationService

class PartnerType(Enum):
    MICROFINANCE = "microfinance"
    COMMUNITY_ORG = "community_organization"
    INSURANCE = "insurance"
    INVESTMENT = "investment"
    LENDING = "lending"

class PartnershipStatus(Enum):
    PENDING = "pending"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    TERMINATED = "terminated"

class ProductType(Enum):
    SAVINGS = "savings"
    INSURANCE = "insurance"
    LOAN = "loan"
    INVESTMENT = "investment"

class ProductStatus(Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    INACTIVE = "inactive"

class PartnershipService:
    def __init__(self):
        self.notification_service = NotificationService()

    def register_partner(
        self,
        name: str,
        partner_type: PartnerType,
        contact_info: Dict[str, str],
        integration_details: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Register a new partner organization."""
        # Validate partner information
        self._validate_partner_info(name, contact_info)
        
        # Create partner record
        partner = Partner(
            name=name,
            partner_type=partner_type,
            contact_info=contact_info,
            integration_details=integration_details,
            status=PartnershipStatus.PENDING
        )
        
        db.session.add(partner)
        db.session.commit()
        
        # Initialize integration
        self._initialize_partner_integration(partner)
        
        return self._format_partner_info(partner)

    def activate_partnership(self, partner_id: int) -> bool:
        """Activate a pending partnership."""
        partner = self._get_partner(partner_id)
        if not partner or partner.status != PartnershipStatus.PENDING:
            return False
            
        partner.status = PartnershipStatus.ACTIVE
        partner.activated_at = datetime.utcnow()
        db.session.commit()
        
        self._notify_partnership_activation(partner)
        return True

    def suspend_partnership(
        self,
        partner_id: int,
        reason: str
    ) -> bool:
        """Suspend an active partnership."""
        partner = self._get_partner(partner_id)
        if not partner or partner.status != PartnershipStatus.ACTIVE:
            return False
            
        partner.status = PartnershipStatus.SUSPENDED
        partner.suspension_reason = reason
        partner.suspended_at = datetime.utcnow()
        db.session.commit()
        
        self._notify_partnership_suspension(partner)
        return True

    def terminate_partnership(
        self,
        partner_id: int,
        reason: str
    ) -> bool:
        """Terminate a partnership."""
        partner = self._get_partner(partner_id)
        if not partner or partner.status == PartnershipStatus.TERMINATED:
            return False
            
        partner.status = PartnershipStatus.TERMINATED
        partner.termination_reason = reason
        partner.terminated_at = datetime.utcnow()
        db.session.commit()
        
        self._notify_partnership_termination(partner)
        return True

    def get_partner(self, partner_id: int) -> Optional[Dict[str, Any]]:
        """Get partner information."""
        partner = self._get_partner(partner_id)
        if not partner:
            return None
            
        return self._format_partner_info(partner)

    def get_partners_by_type(
        self,
        partner_type: PartnerType,
        status: Optional[PartnershipStatus] = None
    ) -> List[Dict[str, Any]]:
        """Get partners filtered by type and status."""
        query = Partner.query.filter_by(partner_type=partner_type)
        if status:
            query = query.filter_by(status=status)
            
        partners = query.order_by(Partner.name).all()
        return [self._format_partner_info(p) for p in partners]

    def register_partner_product(
        self,
        partner_id: int,
        product_type: ProductType,
        product_details: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Register a new partner product."""
        partner = self._get_partner(partner_id)
        if not partner or partner.status != PartnershipStatus.ACTIVE:
            raise ValueError("Invalid or inactive partner")
            
        # Validate product details
        self._validate_product_details(product_type, product_details)
        
        # Create product record
        product = PartnerProduct(
            partner_id=partner_id,
            product_type=product_type,
            product_details=product_details,
            status=ProductStatus.DRAFT
        )
        
        db.session.add(product)
        db.session.commit()
        
        return self._format_product_info(product)

    def activate_product(self, product_id: int) -> bool:
        """Activate a draft product."""
        product = self._get_product(product_id)
        if not product or product.status != ProductStatus.DRAFT:
            return False
            
        product.status = ProductStatus.ACTIVE
        product.activated_at = datetime.utcnow()
        db.session.commit()
        
        self._notify_product_activation(product)
        return True

    def deactivate_product(self, product_id: int) -> bool:
        """Deactivate an active product."""
        product = self._get_product(product_id)
        if not product or product.status != ProductStatus.ACTIVE:
            return False
            
        product.status = ProductStatus.INACTIVE
        db.session.commit()
        
        self._notify_product_deactivation(product)
        return True

    def get_partner_products(
        self,
        partner_id: int,
        product_type: Optional[ProductType] = None,
        status: Optional[ProductStatus] = None
    ) -> List[Dict[str, Any]]:
        """Get products for a partner."""
        query = PartnerProduct.query.filter_by(partner_id=partner_id)
        
        if product_type:
            query = query.filter_by(product_type=product_type)
        if status:
            query = query.filter_by(status=status)
            
        products = query.order_by(PartnerProduct.created_at.desc()).all()
        return [self._format_product_info(p) for p in products]

    def get_available_products(
        self,
        product_type: Optional[ProductType] = None
    ) -> List[Dict[str, Any]]:
        """Get all available active products."""
        query = PartnerProduct.query.join(Partner).filter(
            PartnerProduct.status == ProductStatus.ACTIVE,
            Partner.status == PartnershipStatus.ACTIVE
        )
        
        if product_type:
            query = query.filter_by(product_type=product_type)
            
        products = query.order_by(
            Partner.name,
            PartnerProduct.created_at.desc()
        ).all()
        
        return [self._format_product_info(p) for p in products]

    def schedule_event(
        self,
        partner_id: int,
        event_details: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Schedule a partner event."""
        partner = self._get_partner(partner_id)
        if not partner or partner.status != PartnershipStatus.ACTIVE:
            raise ValueError("Invalid or inactive partner")
            
        # Validate event details
        self._validate_event_details(event_details)
        
        # Create event record
        event = PartnerEvent(
            partner_id=partner_id,
            event_details=event_details
        )
        
        db.session.add(event)
        db.session.commit()
        
        # Schedule notifications
        self._schedule_event_notifications(event)
        
        return self._format_event_info(event)

    def get_upcoming_events(
        self,
        partner_id: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Get upcoming partner events."""
        query = PartnerEvent.query.filter(
            PartnerEvent.event_date >= datetime.utcnow()
        )
        
        if partner_id:
            query = query.filter_by(partner_id=partner_id)
            
        events = query.order_by(PartnerEvent.event_date).all()
        return [self._format_event_info(e) for e in events]

    # Helper methods
    def _get_partner(self, partner_id: int) -> Optional['Partner']:
        """Get partner by ID."""
        return Partner.query.get(partner_id)

    def _get_product(self, product_id: int) -> Optional['PartnerProduct']:
        """Get product by ID."""
        return PartnerProduct.query.get(product_id)

    def _validate_partner_info(self, name: str, contact_info: Dict[str, str]):
        """Validate partner information."""
        # Implement validation logic
        pass

    def _validate_product_details(
        self,
        product_type: ProductType,
        product_details: Dict[str, Any]
    ):
        """Validate product details."""
        # Implement validation logic
        pass

    def _validate_event_details(self, event_details: Dict[str, Any]):
        """Validate event details."""
        # Implement validation logic
        pass

    def _initialize_partner_integration(self, partner: 'Partner'):
        """Initialize integration with partner systems."""
        # Implement integration initialization
        pass

    def _format_partner_info(self, partner: 'Partner') -> Dict[str, Any]:
        """Format partner information."""
        return {
            'id': partner.id,
            'name': partner.name,
            'type': partner.partner_type.value,
            'status': partner.status.value,
            'contact_info': partner.contact_info,
            'created_at': partner.created_at.isoformat(),
            'activated_at': partner.activated_at.isoformat() if partner.activated_at else None
        }

    def _format_product_info(self, product: 'PartnerProduct') -> Dict[str, Any]:
        """Format product information."""
        return {
            'id': product.id,
            'partner_id': product.partner_id,
            'type': product.product_type.value,
            'status': product.status.value,
            'details': product.product_details,
            'created_at': product.created_at.isoformat(),
            'activated_at': product.activated_at.isoformat() if product.activated_at else None
        }

    def _format_event_info(self, event: 'PartnerEvent') -> Dict[str, Any]:
        """Format event information."""
        return {
            'id': event.id,
            'partner_id': event.partner_id,
            'details': event.event_details,
            'event_date': event.event_date.isoformat(),
            'created_at': event.created_at.isoformat()
        }

    def _notify_partnership_activation(self, partner: 'Partner'):
        """Notify relevant parties of partnership activation."""
        self.notification_service.send_notification(
            user_id=partner.primary_contact_id,
            title="Partnership Activated",
            message=f"Partnership with {partner.name} has been activated",
            notification_type="PARTNERSHIP",
            priority="HIGH"
        )

    def _notify_partnership_suspension(self, partner: 'Partner'):
        """Notify relevant parties of partnership suspension."""
        self.notification_service.send_notification(
            user_id=partner.primary_contact_id,
            title="Partnership Suspended",
            message=f"Partnership with {partner.name} has been suspended: {partner.suspension_reason}",
            notification_type="PARTNERSHIP",
            priority="HIGH"
        )

    def _notify_partnership_termination(self, partner: 'Partner'):
        """Notify relevant parties of partnership termination."""
        self.notification_service.send_notification(
            user_id=partner.primary_contact_id,
            title="Partnership Terminated",
            message=f"Partnership with {partner.name} has been terminated: {partner.termination_reason}",
            notification_type="PARTNERSHIP",
            priority="HIGH"
        )

    def _notify_product_activation(self, product: 'PartnerProduct'):
        """Notify relevant parties of product activation."""
        partner = self._get_partner(product.partner_id)
        self.notification_service.send_notification(
            user_id=partner.primary_contact_id,
            title="Product Activated",
            message=f"Product {product.product_details['name']} has been activated",
            notification_type="PARTNERSHIP",
            priority="MEDIUM"
        )

    def _notify_product_deactivation(self, product: 'PartnerProduct'):
        """Notify relevant parties of product deactivation."""
        partner = self._get_partner(product.partner_id)
        self.notification_service.send_notification(
            user_id=partner.primary_contact_id,
            title="Product Deactivated",
            message=f"Product {product.product_details['name']} has been deactivated",
            notification_type="PARTNERSHIP",
            priority="MEDIUM"
        )

    def _schedule_event_notifications(self, event: 'PartnerEvent'):
        """Schedule notifications for partner event."""
        # Implement event notification scheduling
        pass
