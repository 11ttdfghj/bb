import pyotp
import qrcode
import base64
from io import BytesIO
from datetime import datetime, timedelta
from flask import current_app
from models import User, db
from services.notification_service import NotificationService
from services.sms_service import SMSService
from models.notification import NotificationType, NotificationPriority, NotificationChannel

class MFAService:
    def __init__(self):
        """Initialize MFA service with notification and SMS services."""
        self.notification_service = NotificationService()
        self.sms_service = SMSService()

    def generate_totp_secret(self):
        """Generate a new TOTP secret."""
        return pyotp.random_base32()

    def generate_qr_code(self, user_email, secret):
        """Generate QR code for TOTP setup."""
        totp = pyotp.TOTP(secret)
        provisioning_uri = totp.provisioning_uri(
            user_email, 
            issuer_name="Bengabcom Susu Savings"
        )
        
        # Generate QR code
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(provisioning_uri)
        qr.make(fit=True)
        
        # Create QR code image
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert to base64 for web display
        buffered = BytesIO()
        img.save(buffered, format="PNG")
        return base64.b64encode(buffered.getvalue()).decode()

    def verify_totp(self, secret, token):
        """Verify a TOTP token."""
        totp = pyotp.TOTP(secret)
        return totp.verify(token)

    async def send_sms_code(self, user_id, phone_number):
        """Send verification code via SMS."""
        # Generate a 6-digit code
        code = pyotp.TOTP(pyotp.random_base32()).now()
        
        # Store code in user's session (implement secure storage in production)
        user = User.query.get(user_id)
        if not user:
            raise ValueError("User not found")
        
        user.mfa_code = code
        user.mfa_code_expiry = datetime.utcnow() + timedelta(minutes=5)
        db.session.commit()
        
        # Send code via SMS
        message = f"Your Bengabcom verification code is: {code}. Valid for 5 minutes."
        await self.notification_service.send_notification(
            user_id=user_id,
            title="Verification Code",
            message=message,
            notification_type=NotificationType.SYSTEM,
            priority=NotificationPriority.HIGH,
            channel=NotificationChannel.SMS,
            phone_number=phone_number
        )
        
        return True

    def verify_sms_code(self, user_id, code):
        """Verify SMS verification code."""
        user = User.query.get(user_id)
        if not user:
            return False
        
        # Check if code exists and is not expired
        if (user.mfa_code == code and 
            user.mfa_code_expiry and 
            user.mfa_code_expiry > datetime.utcnow()):
            
            # Clear the code after successful verification
            user.mfa_code = None
            user.mfa_code_expiry = None
            db.session.commit()
            
            return True
            
        return False

    def setup_mfa(self, user_id, mfa_type):
        """Set up MFA for a user."""
        user = User.query.get(user_id)
        if not user:
            raise ValueError("User not found")
        
        if mfa_type == "totp":
            # Generate and store TOTP secret
            secret = self.generate_totp_secret()
            user.totp_secret = secret
            user.mfa_type = "totp"
            db.session.commit()
            
            # Generate QR code for setup
            qr_code = self.generate_qr_code(user.email, secret)
            return {"secret": secret, "qr_code": qr_code}
            
        elif mfa_type == "sms":
            if not user.phone_number:
                raise ValueError("Phone number required for SMS authentication")
            
            user.mfa_type = "sms"
            db.session.commit()
            return {"phone_number": user.phone_number}
            
        else:
            raise ValueError("Invalid MFA type")

    def disable_mfa(self, user_id):
        """Disable MFA for a user."""
        user = User.query.get(user_id)
        if not user:
            raise ValueError("User not found")
        
        user.mfa_type = None
        user.totp_secret = None
        user.mfa_code = None
        user.mfa_code_expiry = None
        db.session.commit()
        
        return True

    async def verify_mfa(self, user_id, code):
        """Verify MFA code based on user's MFA type."""
        user = User.query.get(user_id)
        if not user or not user.mfa_type:
            return False
        
        if user.mfa_type == "totp":
            return self.verify_totp(user.totp_secret, code)
            
        elif user.mfa_type == "sms":
            return self.verify_sms_code(user_id, code)
            
        return False
