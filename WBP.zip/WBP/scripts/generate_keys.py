#!/usr/bin/env python3
"""
Generate secure keys for the application.
Run this script to generate new keys for production deployment.
"""

import os
import base64
import secrets
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend

def generate_notification_key():
    """Generate a secure key for notification encryption."""
    return Fernet.generate_key()

def generate_hmac_key():
    """Generate a secure HMAC key."""
    return base64.b64encode(secrets.token_bytes(32))

def generate_secret_key():
    """Generate a secure secret key for Flask."""
    return secrets.token_hex(32)

def generate_vapid_keys():
    """Generate VAPID keys for web push notifications."""
    private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    public_key = private_key.public_key()
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return private_pem, public_pem

def main():
    """Generate all necessary keys and save to .env file."""
    # Create .env from template if it doesn't exist
    if not os.path.exists('.env'):
        with open('.env.example', 'r') as template, open('.env', 'w') as env:
            env.write(template.read())
    
    # Generate new keys
    notification_key = generate_notification_key()
    hmac_key = generate_hmac_key()
    secret_key = generate_secret_key()
    vapid_private, vapid_public = generate_vapid_keys()
    
    # Read existing .env file
    with open('.env', 'r') as f:
        lines = f.readlines()
    
    # Update keys in .env file
    new_lines = []
    for line in lines:
        if line.startswith('NOTIFICATION_ENCRYPTION_KEY='):
            new_lines.append(f'NOTIFICATION_ENCRYPTION_KEY={notification_key.decode()}\n')
        elif line.startswith('HMAC_KEY='):
            new_lines.append(f'HMAC_KEY={hmac_key.decode()}\n')
        elif line.startswith('SECRET_KEY='):
            new_lines.append(f'SECRET_KEY={secret_key}\n')
        elif line.startswith('VAPID_PRIVATE_KEY='):
            new_lines.append(f'VAPID_PRIVATE_KEY={vapid_private.decode()}\n')
        elif line.startswith('VAPID_PUBLIC_KEY='):
            new_lines.append(f'VAPID_PUBLIC_KEY={vapid_public.decode()}\n')
        else:
            new_lines.append(line)
    
    # Write updated .env file
    with open('.env', 'w') as f:
        f.writelines(new_lines)
    
    print("Generated new secure keys and updated .env file")
    print("Make sure to keep these keys secure and never commit them to version control")

if __name__ == '__main__':
    main()
