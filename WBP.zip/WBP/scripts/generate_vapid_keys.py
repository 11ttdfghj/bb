from pywebpush import webpush
import os
import base64
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization

def generate_vapid_keys():
    """Generate VAPID keys for Web Push notifications"""
    # Generate key pair
    private_key = ec.generate_private_key(ec.SECP256R1())
    public_key = private_key.public_key()

    # Get private key in PEM format
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )

    # Get public key in PEM format
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    # Convert to base64
    private_key_base64 = base64.urlsafe_b64encode(private_pem).decode('utf-8')
    public_key_base64 = base64.urlsafe_b64encode(public_pem).decode('utf-8')

    return {
        'private_key': private_key_base64,
        'public_key': public_key_base64
    }

if __name__ == '__main__':
    # Generate keys
    keys = generate_vapid_keys()
    
    # Create .env file with keys
    env_content = f"""# VAPID Keys for Push Notifications
VAPID_PRIVATE_KEY='{keys["private_key"]}'
VAPID_PUBLIC_KEY='{keys["public_key"]}'
"""
    
    # Write to .env file
    with open('.env', 'a') as f:
        f.write('\n' + env_content)
    
    print("VAPID keys have been generated and added to .env file")
    print("\nPublic Key (for client-side):")
    print(keys["public_key"])
    print("\nPrivate Key (keep secure):")
    print(keys["private_key"])
