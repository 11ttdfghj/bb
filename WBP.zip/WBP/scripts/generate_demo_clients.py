"""Script to generate demo clients for BGC Susu Platform."""

import sys
import os
import random
from datetime import datetime, timedelta
import faker
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.models.client import Client
from app.models.account import Account
from app.models.transaction import Transaction
from app.models.user import User
from app import db, create_app

fake = faker.Faker()

def generate_phone():
    """Generate Ghanaian phone number."""
    prefixes = ['024', '054', '055', '020', '050', '026', '056']
    return f"{random.choice(prefixes)}{random.randint(1000000, 9999999)}"

def generate_demo_clients(susu_account, num_clients=50):
    """Generate demo clients linked to a Susu account."""
    app = create_app()
    with app.app_context():
        # Create clients
        for i in range(num_clients):
            # Generate client data
            client = Client(
                name=fake.name(),
                phone=generate_phone(),
                email=fake.email(),
                address=fake.address(),
                occupation=fake.job(),
                date_of_birth=fake.date_of_birth(minimum_age=18, maximum_age=70),
                gender=random.choice(['Male', 'Female']),
                id_type=random.choice(['Ghana Card', 'Voters ID', 'Passport']),
                id_number=f"GHA-{fake.unique.random_number(digits=9)}",
                susu_account=susu_account,
                created_at=datetime.now(),
                status='active'
            )
            
            # Create account for client
            account = Account(
                account_number=f"BGC-CLI-{str(random.randint(10000, 99999)).zfill(5)}",
                client=client,
                balance=random.uniform(100.0, 5000.0),
                account_type='savings',
                status='active',
                created_at=datetime.now()
            )
            
            # Generate some sample transactions
            num_transactions = random.randint(5, 15)
            for _ in range(num_transactions):
                transaction_date = datetime.now() - timedelta(days=random.randint(1, 30))
                amount = random.uniform(10.0, 500.0)
                
                transaction = Transaction(
                    account=account,
                    type=random.choice(['deposit', 'withdrawal']),
                    amount=amount,
                    balance_before=account.balance,
                    balance_after=account.balance + amount,
                    status='completed',
                    reference=f"TXN-{fake.unique.random_number(digits=10)}",
                    created_at=transaction_date
                )
                
                db.session.add(transaction)
                account.balance += amount
            
            db.session.add(client)
            db.session.add(account)
        
        # Create admin user if not exists
        admin_email = "reginaldagyemang9@gmail.com"
        admin = User.query.filter_by(email=admin_email).first()
        if not admin:
            admin = User(
                name="Reginald Agyemang",
                email=admin_email,
                phone=generate_phone(),
                role='admin',
                status='active',
                password="Avfrancis22"  # This will be hashed by the model
            )
            db.session.add(admin)
        
        try:
            db.session.commit()
            print(f"Successfully generated {num_clients} demo clients")
            print(f"Admin user created/verified: {admin_email}")
        except Exception as e:
            db.session.rollback()
            print(f"Error generating demo data: {str(e)}")

if __name__ == '__main__':
    susu_account = "BGC-SUSU-20250001"
    generate_demo_clients(susu_account)
