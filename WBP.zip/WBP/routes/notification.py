from flask import Blueprint, jsonify, request, current_app
from flask_login import login_required, current_user
from services.notification_service import NotificationService
from models.notification import Notification, db

notifications = Blueprint('notifications', __name__)

@notifications.route('/api/notifications/subscribe', methods=['POST'])
@login_required
def subscribe():
    """Subscribe to push notifications"""
    subscription_info = request.get_json()
    
    if not subscription_info:
        return jsonify({'error': 'No subscription info provided'}), 400
    
    try:
        current_user.push_subscription = subscription_info
        db.session.commit()
        return jsonify({'message': 'Successfully subscribed to notifications'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@notifications.route('/api/notifications/unsubscribe', methods=['POST'])
@login_required
def unsubscribe():
    """Unsubscribe from push notifications"""
    try:
        current_user.push_subscription = None
        db.session.commit()
        return jsonify({'message': 'Successfully unsubscribed from notifications'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@notifications.route('/api/notifications', methods=['GET'])
@login_required
def get_notifications():
    """Get user's notifications"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    notifications = Notification.query.filter_by(user_id=current_user.id)\
        .order_by(Notification.created_at.desc())\
        .paginate(page=page, per_page=per_page)
    
    return jsonify({
        'notifications': [n.to_dict() for n in notifications.items],
        'total': notifications.total,
        'pages': notifications.pages,
        'current_page': notifications.page
    }), 200

@notifications.route('/api/notifications/mark-read', methods=['POST'])
@login_required
def mark_notifications_read():
    """Mark notifications as read"""
    notification_ids = request.json.get('notification_ids', [])
    
    if not notification_ids:
        return jsonify({'error': 'No notification IDs provided'}), 400
    
    try:
        notifications = Notification.query.filter(
            Notification.id.in_(notification_ids),
            Notification.user_id == current_user.id
        ).all()
        
        for notification in notifications:
            notification.mark_as_read()
            
        return jsonify({'message': 'Notifications marked as read'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@notifications.route('/api/notifications/settings', methods=['PUT'])
@login_required
def update_notification_settings():
    """Update notification preferences"""
    settings = request.get_json()
    
    try:
        current_user.notification_settings = settings
        db.session.commit()
        return jsonify({'message': 'Notification settings updated'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@notifications.route('/api/notifications/vapid-public-key', methods=['GET'])
def get_vapid_public_key():
    """Get VAPID public key for push notifications"""
    return jsonify({
        'vapidPublicKey': current_app.config['VAPID_PUBLIC_KEY']
    }), 200
