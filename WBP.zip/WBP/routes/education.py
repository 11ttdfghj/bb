from flask import Blueprint, jsonify, request, current_app
from flask_login import login_required, current_user
from sqlalchemy import desc
from datetime import datetime
from models.education import (
    EducationalContent, ContentComment, ForumTopic, ForumPost, 
    ForumReply, SavingsGroup, GroupMembership, Achievement, 
    UserAchievement, Challenge, ChallengeParticipant
)
from models.user_education import (
    UserEducationPreference, UserProgress, UserQuizAttempt,
    UserEngagement, LearningPath, UserLearningPath
)
from app import db

education = Blueprint('education', __name__)

# Educational Content Routes
@education.route('/content', methods=['GET'])
def get_educational_content():
    """Get paginated educational content with filters."""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    content_type = request.args.get('type')
    difficulty = request.args.get('difficulty')
    language = request.args.get('language', 'en')
    
    query = EducationalContent.query.filter_by(is_published=True)
    
    if content_type:
        query = query.filter_by(content_type=content_type)
    if difficulty:
        query = query.filter_by(difficulty_level=difficulty)
    if language:
        query = query.filter_by(language=language)
    
    content = query.order_by(desc(EducationalContent.created_at))\
        .paginate(page=page, per_page=per_page)
    
    return jsonify({
        'items': [{'id': c.id, 'title': c.title, 'content_type': c.content_type,
                  'difficulty_level': c.difficulty_level, 'views': c.views_count,
                  'likes': c.likes_count} for c in content.items],
        'total': content.total,
        'pages': content.pages,
        'current_page': content.page
    })

@education.route('/content/<int:content_id>', methods=['GET'])
def get_content_detail(content_id):
    """Get detailed view of educational content."""
    content = EducationalContent.query.get_or_404(content_id)
    content.views_count += 1
    db.session.commit()
    
    return jsonify({
        'id': content.id,
        'title': content.title,
        'content': content.content,
        'content_type': content.content_type,
        'difficulty_level': content.difficulty_level,
        'views': content.views_count,
        'likes': content.likes_count,
        'author': content.author.username if content.author else None,
        'created_at': content.created_at.isoformat()
    })

# Forum Routes
@education.route('/forum/topics', methods=['GET'])
def get_forum_topics():
    """Get list of forum topics."""
    topics = ForumTopic.query.filter_by(is_active=True).all()
    return jsonify([{
        'id': topic.id,
        'title': topic.title,
        'description': topic.description,
        'posts_count': len(topic.posts)
    } for topic in topics])

@education.route('/forum/posts', methods=['GET'])
def get_forum_posts():
    """Get paginated forum posts."""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    topic_id = request.args.get('topic_id', type=int)
    
    query = ForumPost.query
    if topic_id:
        query = query.filter_by(topic_id=topic_id)
    
    posts = query.order_by(desc(ForumPost.created_at))\
        .paginate(page=page, per_page=per_page)
    
    return jsonify({
        'items': [{
            'id': post.id,
            'title': post.title,
            'author': post.user.username,
            'created_at': post.created_at.isoformat(),
            'views': post.views_count,
            'replies_count': len(post.replies)
        } for post in posts.items],
        'total': posts.total,
        'pages': posts.pages,
        'current_page': posts.page
    })

# Savings Groups Routes
@education.route('/groups', methods=['GET'])
@login_required
def get_savings_groups():
    """Get list of savings groups."""
    user_groups = GroupMembership.query.filter_by(user_id=current_user.id).all()
    public_groups = SavingsGroup.query.filter_by(is_private=False).all()
    
    return jsonify({
        'user_groups': [{
            'id': membership.group.id,
            'name': membership.group.name,
            'description': membership.group.description,
            'members_count': len(membership.group.members),
            'target_amount': membership.group.target_amount,
            'duration_weeks': membership.group.duration_weeks,
            'role': membership.role
        } for membership in user_groups],
        'public_groups': [{
            'id': group.id,
            'name': group.name,
            'description': group.description,
            'members_count': len(group.members),
            'target_amount': group.target_amount,
            'duration_weeks': group.duration_weeks
        } for group in public_groups if group not in [m.group for m in user_groups]]
    })

# Achievements and Challenges Routes
@education.route('/achievements', methods=['GET'])
@login_required
def get_achievements():
    """Get user achievements."""
    user_achievements = UserAchievement.query.filter_by(user_id=current_user.id).all()
    all_achievements = Achievement.query.all()
    
    return jsonify({
        'earned': [{
            'id': ua.achievement.id,
            'name': ua.achievement.name,
            'description': ua.achievement.description,
            'badge_url': ua.achievement.badge_image_url,
            'points': ua.achievement.points,
            'earned_at': ua.earned_at.isoformat()
        } for ua in user_achievements],
        'available': [{
            'id': a.id,
            'name': a.name,
            'description': a.description,
            'badge_url': a.badge_image_url,
            'points': a.points
        } for a in all_achievements if a not in [ua.achievement for ua in user_achievements]]
    })

@education.route('/challenges', methods=['GET'])
@login_required
def get_challenges():
    """Get active savings challenges."""
    active_challenges = Challenge.query.filter_by(is_active=True)\
        .filter(Challenge.end_date > datetime.utcnow()).all()
    user_participations = ChallengeParticipant.query\
        .filter_by(user_id=current_user.id).all()
    
    return jsonify({
        'active_challenges': [{
            'id': challenge.id,
            'title': challenge.title,
            'description': challenge.description,
            'target_amount': challenge.target_amount,
            'reward_points': challenge.reward_points,
            'start_date': challenge.start_date.isoformat(),
            'end_date': challenge.end_date.isoformat(),
            'participants_count': len(challenge.participants),
            'user_participating': any(p.challenge_id == challenge.id 
                                   for p in user_participations)
        } for challenge in active_challenges]
    })

# Learning Progress Routes
@education.route('/progress', methods=['GET'])
@login_required
def get_learning_progress():
    """Get user's learning progress."""
    progress = UserProgress.query.filter_by(user_id=current_user.id).all()
    engagement = UserEngagement.query.filter_by(user_id=current_user.id).first()
    
    return jsonify({
        'content_progress': [{
            'content_id': p.content_id,
            'title': p.content.title,
            'progress': p.progress_percentage,
            'completed': p.completed,
            'last_accessed': p.last_accessed.isoformat()
        } for p in progress],
        'engagement_metrics': {
            'total_points': engagement.total_points,
            'articles_read': engagement.articles_read,
            'quizzes_completed': engagement.quizzes_completed,
            'forum_posts': engagement.forum_posts,
            'challenges_completed': engagement.challenges_completed,
            'achievements_earned': engagement.achievements_earned,
            'engagement_streak': engagement.engagement_streak
        } if engagement else {}
    })
