from flask import Blueprint, request, jsonify, render_template, session, redirect, url_for
from flask_login import login_required, current_user
from services.mfa_service import MFAService
from models import User, db
from functools import wraps

auth_bp = Blueprint('auth', __name__)
mfa_service = MFAService()

def mfa_required(f):
    """Decorator to require MFA verification."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
            
        # Check if user has MFA enabled and hasn't completed verification
        if current_user.is_mfa_enabled() and not session.get('mfa_verified'):
            # Store the original destination
            session['next_url'] = request.url
            return redirect(url_for('auth.verify_mfa'))
            
        return f(*args, **kwargs)
    return decorated_function

@auth_bp.route('/mfa/setup', methods=['GET', 'POST'])
@login_required
def setup_mfa():
    """Set up MFA for the user."""
    if request.method == 'GET':
        return render_template('auth/mfa_setup.html')
        
    try:
        mfa_type = request.form.get('mfa_type')
        if not mfa_type in ['totp', 'sms']:
            return jsonify({'error': 'Invalid MFA type'}), 400
            
        result = mfa_service.setup_mfa(current_user.id, mfa_type)
        
        if mfa_type == 'totp':
            return render_template(
                'auth/totp_setup.html',
                secret=result['secret'],
                qr_code=result['qr_code']
            )
        else:
            return render_template(
                'auth/sms_setup.html',
                phone_number=result['phone_number']
            )
            
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': 'Failed to set up MFA'}), 500

@auth_bp.route('/mfa/verify', methods=['GET', 'POST'])
@login_required
def verify_mfa():
    """Verify MFA code."""
    if request.method == 'GET':
        return render_template(
            'auth/verify_mfa.html',
            mfa_type=current_user.mfa_type
        )
        
    try:
        code = request.form.get('code')
        if not code:
            return jsonify({'error': 'Verification code required'}), 400
            
        verified = await mfa_service.verify_mfa(current_user.id, code)
        
        if verified:
            session['mfa_verified'] = True
            next_url = session.pop('next_url', url_for('main.dashboard'))
            return redirect(next_url)
        else:
            return jsonify({'error': 'Invalid verification code'}), 400
            
    except Exception as e:
        return jsonify({'error': 'Failed to verify MFA code'}), 500

@auth_bp.route('/mfa/disable', methods=['POST'])
@login_required
@mfa_required
def disable_mfa():
    """Disable MFA for the user."""
    try:
        mfa_service.disable_mfa(current_user.id)
        return jsonify({'message': 'MFA disabled successfully'})
    except Exception as e:
        return jsonify({'error': 'Failed to disable MFA'}), 500

@auth_bp.route('/mfa/send-code', methods=['POST'])
@login_required
def send_sms_code():
    """Send SMS verification code."""
    try:
        if not current_user.phone_number:
            return jsonify({'error': 'Phone number not set'}), 400
            
        await mfa_service.send_sms_code(
            current_user.id,
            current_user.phone_number
        )
        return jsonify({'message': 'Verification code sent'})
        
    except Exception as e:
        return jsonify({'error': 'Failed to send verification code'}), 500

@auth_bp.route('/security-settings', methods=['GET'])
@login_required
@mfa_required
def security_settings():
    """View and manage security settings."""
    security_info = current_user.get_security_info()
    return render_template('auth/security_settings.html', security_info=security_info)

@auth_bp.route('/login', methods=['POST'])
def login():
    """Handle user login with MFA."""
    email = request.form.get('email')
    password = request.form.get('password')
    
    user = User.query.filter_by(email=email).first()
    if not user or not user.check_password(password):
        user.record_login_attempt(success=False)
        db.session.commit()
        return jsonify({'error': 'Invalid credentials'}), 401
        
    if user.is_account_locked():
        return jsonify({
            'error': 'Account locked. Please try again later or contact support.'
        }), 403
        
    # Record successful login attempt
    user.record_login_attempt(success=True)
    db.session.commit()
    
    # Check if MFA is required
    if user.is_mfa_enabled():
        session['mfa_pending_user_id'] = user.id
        return jsonify({
            'message': 'MFA required',
            'mfa_type': user.mfa_type
        }), 200
        
    # No MFA required, proceed with login
    login_user(user)
    return jsonify({'message': 'Login successful'})
