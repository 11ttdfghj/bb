from datetime import datetime, timedelta
from flask import Blueprint, jsonify, render_template, request
from flask_login import login_required, current_user
from sqlalchemy import func, extract
from models.notification import Notification, NotificationAnalytics
from services.notification_service import NotificationService

bp = Blueprint('notification_analytics', __name__)
notification_service = NotificationService()

@bp.route('/notifications/analytics')
@login_required
def analytics_dashboard():
    """Render the notification analytics dashboard"""
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=30)  # Default to last 30 days
    
    stats = get_notification_stats(start_date, end_date)
    recent_notifications = get_recent_notifications()
    notification_data = get_notification_data(start_date, end_date)
    
    return render_template('notification_analytics.html',
                         stats=stats,
                         recent_notifications=recent_notifications,
                         notification_data=notification_data)

@bp.route('/api/notifications/analytics')
@login_required
def get_analytics():
    """API endpoint for notification analytics"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if start_date:
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
        else:
            start_date = datetime.utcnow() - timedelta(days=30)
            
        if end_date:
            end_date = datetime.strptime(end_date, '%Y-%m-%d')
        else:
            end_date = datetime.utcnow()
            
        stats = get_notification_stats(start_date, end_date)
        recent_notifications = get_recent_notifications()
        notification_data = get_notification_data(start_date, end_date)
        
        return jsonify({
            'stats': stats,
            'recent_notifications': recent_notifications,
            'notification_data': notification_data
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def get_notification_stats(start_date, end_date):
    """Get notification statistics for the given date range"""
    total = Notification.query.filter(
        Notification.user_id == current_user.id,
        Notification.created_at.between(start_date, end_date)
    ).count()
    
    delivered = Notification.query.filter(
        Notification.user_id == current_user.id,
        Notification.created_at.between(start_date, end_date),
        Notification.is_sent == True
    ).count()
    
    read = Notification.query.filter(
        Notification.user_id == current_user.id,
        Notification.created_at.between(start_date, end_date),
        Notification.is_read == True
    ).count()
    
    clicked = NotificationAnalytics.query.join(Notification).filter(
        Notification.user_id == current_user.id,
        Notification.created_at.between(start_date, end_date),
        NotificationAnalytics.clicked_at.isnot(None)
    ).count()
    
    return {
        'total': total,
        'delivery_rate': round((delivered / total * 100) if total > 0 else 0, 1),
        'read_rate': round((read / total * 100) if total > 0 else 0, 1),
        'click_rate': round((clicked / total * 100) if total > 0 else 0, 1)
    }

def get_recent_notifications(limit=10):
    """Get recent notifications with their status"""
    notifications = Notification.query.filter(
        Notification.user_id == current_user.id
    ).order_by(
        Notification.created_at.desc()
    ).limit(limit).all()
    
    result = []
    for notification in notifications:
        analytics = NotificationAnalytics.query.filter_by(
            notification_id=notification.id
        ).first()
        
        priority_class = {
            'urgent': 'danger',
            'high': 'warning',
            'medium': 'primary',
            'low': 'secondary'
        }.get(notification.priority.value, 'primary')
        
        result.append({
            'type': notification.type.value,
            'title': notification.title,
            'channel': notification.channel.value,
            'priority': notification.priority.value,
            'priority_class': priority_class,
            'sent_at': notification.sent_at.strftime('%Y-%m-%d %H:%M') if notification.sent_at else None,
            'delivered': notification.is_sent,
            'read': notification.is_read,
            'clicked': bool(analytics and analytics.clicked_at)
        })
    
    return result

def get_notification_data(start_date, end_date):
    """Get notification data for charts"""
    # Type distribution
    type_stats = db.session.query(
        Notification.type,
        func.count(Notification.id)
    ).filter(
        Notification.user_id == current_user.id,
        Notification.created_at.between(start_date, end_date)
    ).group_by(Notification.type).all()
    
    # Channel performance
    channel_stats = db.session.query(
        Notification.channel,
        func.count(Notification.id).label('total'),
        func.sum(case([(Notification.is_sent, 1)], else_=0)).label('delivered')
    ).filter(
        Notification.user_id == current_user.id,
        Notification.created_at.between(start_date, end_date)
    ).group_by(Notification.channel).all()
    
    # Priority distribution
    priority_stats = db.session.query(
        Notification.priority,
        func.count(Notification.id)
    ).filter(
        Notification.user_id == current_user.id,
        Notification.created_at.between(start_date, end_date)
    ).group_by(Notification.priority).all()
    
    # Time of day analysis
    hour_stats = db.session.query(
        extract('hour', Notification.created_at).label('hour'),
        func.count(Notification.id)
    ).filter(
        Notification.user_id == current_user.id,
        Notification.created_at.between(start_date, end_date)
    ).group_by('hour').all()
    
    return {
        'type_distribution': {
            'labels': [t[0].value for t in type_stats],
            'values': [t[1] for t in type_stats]
        },
        'channel_performance': {
            'channels': [c[0].value for c in channel_stats],
            'delivery_rates': [
                round(c[2] / c[1] * 100, 1) if c[1] > 0 else 0 
                for c in channel_stats
            ]
        },
        'priority_distribution': {
            'labels': [p[0].value for p in priority_stats],
            'values': [p[1] for p in priority_stats]
        },
        'time_analysis': {
            'hours': list(range(24)),
            'counts': [
                next((count for hour, count in hour_stats if hour == h), 0)
                for h in range(24)
            ]
        }
    }
