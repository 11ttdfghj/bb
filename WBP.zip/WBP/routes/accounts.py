from flask import Blueprint, render_template, redirect, url_for, flash, jsonify, request
from flask_login import login_required, current_user
from models import db, BankAccount, MobileWallet
from forms import BankAccountForm, MobileWalletForm

accounts = Blueprint('accounts', __name__)

@accounts.route('/link-accounts', methods=['GET'])
@login_required
def link_accounts():
    bank_form = BankAccountForm()
    mobile_form = MobileWalletForm()
    
    # Get user's linked accounts
    bank_accounts = BankAccount.query.filter_by(user_id=current_user.id).all()
    mobile_wallets = MobileWallet.query.filter_by(user_id=current_user.id).all()
    
    return render_template('link_accounts.html',
                         bank_form=bank_form,
                         mobile_form=mobile_form,
                         bank_accounts=bank_accounts,
                         mobile_wallets=mobile_wallets)

@accounts.route('/link-bank-account', methods=['POST'])
@login_required
def link_bank_account():
    form = BankAccountForm()
    
    if form.validate_on_submit():
        # Check if this is the first account (make it primary by default)
        existing_accounts = BankAccount.query.filter_by(user_id=current_user.id).count()
        is_primary = form.is_primary.data or existing_accounts == 0
        
        # If this is being set as primary, unset other primary accounts
        if is_primary:
            BankAccount.query.filter_by(user_id=current_user.id, is_primary=True).update({'is_primary': False})
        
        # Create new bank account
        bank_account = BankAccount(
            user_id=current_user.id,
            bank_name=form.bank_name.data,
            account_number=form.account_number.data,
            account_name=form.account_name.data,
            is_primary=is_primary
        )
        
        try:
            db.session.add(bank_account)
            db.session.commit()
            flash('Bank account linked successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash('Error linking bank account. Please try again.', 'error')
            
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"{field}: {error}", 'error')
    
    return redirect(url_for('accounts.link_accounts'))

@accounts.route('/link-mobile-wallet', methods=['POST'])
@login_required
def link_mobile_wallet():
    form = MobileWalletForm()
    
    if form.validate_on_submit():
        # Check if this is the first wallet (make it primary by default)
        existing_wallets = MobileWallet.query.filter_by(user_id=current_user.id).count()
        is_primary = form.is_primary.data or existing_wallets == 0
        
        # If this is being set as primary, unset other primary wallets
        if is_primary:
            MobileWallet.query.filter_by(user_id=current_user.id, is_primary=True).update({'is_primary': False})
        
        # Create new mobile wallet
        mobile_wallet = MobileWallet(
            user_id=current_user.id,
            provider=form.provider.data,
            phone_number=form.phone_number.data,
            account_name=form.account_name.data,
            is_primary=is_primary
        )
        
        try:
            db.session.add(mobile_wallet)
            db.session.commit()
            flash('Mobile money account linked successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash('Error linking mobile money account. Please try again.', 'error')
            
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"{field}: {error}", 'error')
    
    return redirect(url_for('accounts.link_accounts'))

@accounts.route('/api/unlink-account/<type>/<int:id>', methods=['POST'])
@login_required
def unlink_account(type, id):
    try:
        if type == 'bank':
            account = BankAccount.query.get_or_404(id)
            if account.user_id != current_user.id:
                return jsonify({'error': 'Unauthorized'}), 403
            
            # If removing primary account, set another account as primary if exists
            if account.is_primary:
                next_account = BankAccount.query.filter_by(user_id=current_user.id).filter(BankAccount.id != id).first()
                if next_account:
                    next_account.is_primary = True
            
            db.session.delete(account)
            
        elif type == 'mobile':
            wallet = MobileWallet.query.get_or_404(id)
            if wallet.user_id != current_user.id:
                return jsonify({'error': 'Unauthorized'}), 403
            
            # If removing primary wallet, set another wallet as primary if exists
            if wallet.is_primary:
                next_wallet = MobileWallet.query.filter_by(user_id=current_user.id).filter(MobileWallet.id != id).first()
                if next_wallet:
                    next_wallet.is_primary = True
            
            db.session.delete(wallet)
            
        else:
            return jsonify({'error': 'Invalid account type'}), 400
        
        db.session.commit()
        return jsonify({'message': 'Account unlinked successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to unlink account'}), 500
