from flask import Blueprint, jsonify, request, send_file
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from io import BytesIO
import matplotlib.pyplot as plt
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from models.susu import SusuAccount, SavingsGoal, Transaction
from models.analytics import SavingsProjection, SavingsInsight
from utils.analytics_helper import (
    calculate_savings_growth,
    calculate_goal_progress,
    analyze_spending_patterns,
    generate_savings_recommendations,
    calculate_milestone_progress
)
from utils.export_helper import generate_pdf_report, generate_excel_report
from sqlalchemy import func
from database import db

analytics = Blueprint('analytics', __name__)

@analytics.route('/api/analytics/chart-data')
def get_chart_data():
    """Get data for all charts based on timeframe."""
    try:
        timeframe = request.args.get('timeframe', '30')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')

        # Calculate date range
        if timeframe != 'custom':
            end_date = datetime.now()
            start_date = end_date - timedelta(days=int(timeframe))
        else:
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
            end_date = datetime.strptime(end_date, '%Y-%m-%d')

        # Get user's accounts
        user_id = request.user.id  # Assuming user authentication is implemented
        accounts = SusuAccount.query.filter_by(user_id=user_id).all()
        account_ids = [account.id for account in accounts]

        # Get savings growth data
        savings_growth = calculate_savings_growth(account_ids, start_date, end_date)

        # Get goals progress
        goals_progress = calculate_goal_progress(account_ids)

        # Get monthly contributions
        monthly_contributions = (
            db.session.query(
                func.date_trunc('month', Transaction.date).label('month'),
                func.sum(Transaction.amount).label('total')
            )
            .filter(
                Transaction.account_id.in_(account_ids),
                Transaction.type == 'deposit',
                Transaction.date.between(start_date, end_date)
            )
            .group_by('month')
            .order_by('month')
            .all()
        )

        # Get savings distribution
        savings_distribution = (
            db.session.query(
                SavingsGoal.category,
                func.sum(SavingsGoal.current_amount).label('total')
            )
            .filter(SavingsGoal.account_id.in_(account_ids))
            .group_by(SavingsGoal.category)
            .all()
        )

        # Generate insights
        spending_patterns = analyze_spending_patterns(account_ids, start_date, end_date)
        recommendations = generate_savings_recommendations(spending_patterns)
        milestones = calculate_milestone_progress(account_ids)

        return jsonify({
            'savingsGrowth': {
                'labels': [date.strftime('%Y-%m-%d') for date in savings_growth['dates']],
                'values': savings_growth['amounts']
            },
            'goalsProgress': {
                'labels': [goal.name for goal in goals_progress],
                'values': [goal.progress for goal in goals_progress]
            },
            'monthlyContributions': {
                'labels': [m.month.strftime('%B %Y') for m in monthly_contributions],
                'values': [float(m.total) for m in monthly_contributions]
            },
            'savingsDistribution': {
                'labels': [d.category for d in savings_distribution],
                'values': [float(d.total) for d in savings_distribution]
            },
            'insights': {
                'projections': [p.to_dict() for p in recommendations['projections']],
                'recommendations': [r.to_dict() for r in recommendations['recommendations']]
            },
            'milestones': [m.to_dict() for m in milestones]
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@analytics.route('/api/analytics/insights')
def get_insights():
    """Get personalized insights and recommendations."""
    try:
        user_id = request.user.id
        accounts = SusuAccount.query.filter_by(user_id=user_id).all()
        account_ids = [account.id for account in accounts]

        # Calculate insights
        end_date = datetime.now()
        start_date = end_date - timedelta(days=90)  # Analyze last 90 days
        spending_patterns = analyze_spending_patterns(account_ids, start_date, end_date)
        recommendations = generate_savings_recommendations(spending_patterns)

        return jsonify({
            'insights': {
                'projections': [p.to_dict() for p in recommendations['projections']],
                'recommendations': [r.to_dict() for r in recommendations['recommendations']]
            }
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@analytics.route('/api/analytics/export', methods=['POST'])
def export_analytics():
    """Export analytics data in various formats."""
    try:
        data = request.json
        format = data.get('format')
        selected_charts = data.get('selectedCharts')
        options = data.get('options')

        # Get user's accounts
        user_id = request.user.id
        accounts = SusuAccount.query.filter_by(user_id=user_id).all()
        account_ids = [account.id for account in accounts]

        # Get data for selected charts
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30)  # Default to last 30 days
        
        export_data = {}
        
        if selected_charts.get('savingsGrowth'):
            export_data['savingsGrowth'] = calculate_savings_growth(
                account_ids, start_date, end_date
            )
        
        if selected_charts.get('goalsProgress'):
            export_data['goalsProgress'] = calculate_goal_progress(account_ids)
        
        if selected_charts.get('monthlyContributions'):
            export_data['monthlyContributions'] = (
                db.session.query(
                    func.date_trunc('month', Transaction.date).label('month'),
                    func.sum(Transaction.amount).label('total')
                )
                .filter(
                    Transaction.account_id.in_(account_ids),
                    Transaction.type == 'deposit',
                    Transaction.date.between(start_date, end_date)
                )
                .group_by('month')
                .order_by('month')
                .all()
            )
        
        if selected_charts.get('savingsDistribution'):
            export_data['savingsDistribution'] = (
                db.session.query(
                    SavingsGoal.category,
                    func.sum(SavingsGoal.current_amount).label('total')
                )
                .filter(SavingsGoal.account_id.in_(account_ids))
                .group_by(SavingsGoal.category)
                .all()
            )

        # Include additional data if requested
        if options.get('includeProjections'):
            spending_patterns = analyze_spending_patterns(account_ids, start_date, end_date)
            recommendations = generate_savings_recommendations(spending_patterns)
            export_data['projections'] = recommendations['projections']

        if options.get('includeInsights'):
            if 'recommendations' not in export_data:
                spending_patterns = analyze_spending_patterns(account_ids, start_date, end_date)
                recommendations = generate_savings_recommendations(spending_patterns)
            export_data['insights'] = recommendations['recommendations']

        # Generate export file based on format
        if format == 'pdf':
            pdf_buffer = generate_pdf_report(export_data)
            return send_file(
                pdf_buffer,
                download_name='savings-analytics.pdf',
                as_attachment=True,
                mimetype='application/pdf'
            )
        
        elif format == 'excel':
            excel_buffer = generate_excel_report(export_data)
            return send_file(
                excel_buffer,
                download_name='savings-analytics.xlsx',
                as_attachment=True,
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )
        
        elif format == 'csv':
            # Convert data to CSV format
            csv_data = []
            if 'savingsGrowth' in export_data:
                df = pd.DataFrame({
                    'Date': export_data['savingsGrowth']['dates'],
                    'Amount': export_data['savingsGrowth']['amounts']
                })
                csv_data.append(('savings_growth.csv', df.to_csv(index=False)))
            
            if 'goalsProgress' in export_data:
                df = pd.DataFrame({
                    'Goal': [g.name for g in export_data['goalsProgress']],
                    'Progress': [g.progress for g in export_data['goalsProgress']]
                })
                csv_data.append(('goals_progress.csv', df.to_csv(index=False)))
            
            # Return first CSV file (can be modified to return multiple files)
            if csv_data:
                return send_file(
                    BytesIO(csv_data[0][1].encode()),
                    download_name=csv_data[0][0],
                    as_attachment=True,
                    mimetype='text/csv'
                )
        
        elif format == 'images':
            # Generate chart images using matplotlib
            charts = []
            if 'savingsGrowth' in export_data:
                fig, ax = plt.subplots()
                ax.plot(export_data['savingsGrowth']['dates'], 
                       export_data['savingsGrowth']['amounts'])
                ax.set_title('Savings Growth')
                img_buffer = BytesIO()
                fig.savefig(img_buffer, format='png')
                plt.close(fig)
                charts.append(('savings_growth.png', img_buffer))
            
            # Return first image (can be modified to return multiple images)
            if charts:
                charts[0][1].seek(0)
                return send_file(
                    charts[0][1],
                    download_name=charts[0][0],
                    as_attachment=True,
                    mimetype='image/png'
                )

        return jsonify({'error': 'Invalid export format'}), 400

    except Exception as e:
        return jsonify({'error': str(e)}), 500
