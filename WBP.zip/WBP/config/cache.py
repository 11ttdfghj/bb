from flask_caching import Cache
import redis

# Cache configuration
cache_config = {
    'CACHE_TYPE': 'redis',
    'CACHE_REDIS_HOST': 'localhost',
    'CACHE_REDIS_PORT': 6379,
    'CACHE_REDIS_DB': 0,
    'CACHE_DEFAULT_TIMEOUT': 300  # 5 minutes
}

# Initialize cache
cache = Cache(config=cache_config)

# Redis client for more complex caching scenarios
redis_client = redis.Redis(
    host=cache_config['CACHE_REDIS_HOST'],
    port=cache_config['CACHE_REDIS_PORT'],
    db=cache_config['CACHE_REDIS_DB'],
    decode_responses=True
)

# Cache key prefixes
CACHE_KEYS = {
    'chart_data': 'analytics:chart_data:{}:{}:{}',  # timeframe:start_date:end_date
    'insights': 'analytics:insights:{}',  # user_id
    'milestones': 'analytics:milestones:{}',  # user_id
    'projections': 'analytics:projections:{}',  # user_id
    'recommendations': 'analytics:recommendations:{}'  # user_id
}

# Cache timeouts (in seconds)
CACHE_TIMEOUTS = {
    'chart_data': 300,  # 5 minutes
    'insights': 1800,  # 30 minutes
    'milestones': 3600,  # 1 hour
    'projections': 3600,  # 1 hour
    'recommendations': 1800  # 30 minutes
}

def get_cache_key(key_type, *args):
    """Generate a cache key based on the key type and arguments."""
    if key_type not in CACHE_KEYS:
        raise ValueError(f"Invalid cache key type: {key_type}")
    return CACHE_KEYS[key_type].format(*args)

def get_cache_timeout(key_type):
    """Get the cache timeout for a specific key type."""
    return CACHE_TIMEOUTS.get(key_type, 300)  # Default to 5 minutes

class CacheManager:
    @staticmethod
    def cache_key(key_type):
        """Decorator to automatically generate cache keys."""
        def decorator(f):
            def wrapper(*args, **kwargs):
                # Generate cache key based on function arguments
                cache_key = get_cache_key(key_type, *args)
                
                # Try to get from cache
                cached_value = cache.get(cache_key)
                if cached_value is not None:
                    return cached_value
                
                # If not in cache, execute function and cache result
                result = f(*args, **kwargs)
                cache.set(
                    cache_key,
                    result,
                    timeout=get_cache_timeout(key_type)
                )
                return result
            return wrapper
        return decorator

    @staticmethod
    def invalidate_user_cache(user_id):
        """Invalidate all cache entries for a specific user."""
        patterns = [
            f"analytics:*:{user_id}*",
            f"analytics:*:{user_id}:*"
        ]
        for pattern in patterns:
            keys = redis_client.keys(pattern)
            if keys:
                redis_client.delete(*keys)

    @staticmethod
    def bulk_cache_update(updates):
        """Perform multiple cache updates atomically."""
        pipeline = redis_client.pipeline()
        try:
            for key, value, timeout in updates:
                pipeline.setex(key, timeout, value)
            pipeline.execute()
        except redis.RedisError as e:
            print(f"Error in bulk cache update: {e}")
            pipeline.reset()

    @staticmethod
    def get_cache_stats():
        """Get cache statistics."""
        stats = {
            'total_keys': len(redis_client.keys('analytics:*')),
            'memory_used': redis_client.info()['used_memory_human'],
            'hit_rate': redis_client.info()['keyspace_hits'] / (
                redis_client.info()['keyspace_hits'] +
                redis_client.info()['keyspace_misses']
            ) if redis_client.info()['keyspace_hits'] > 0 else 0
        }
        return stats

# Example usage of cache decorators
"""
@cache.memoize(timeout=300)
def get_user_analytics(user_id, timeframe):
    # Your analytics calculation code here
    pass

@CacheManager.cache_key('chart_data')
def get_chart_data(timeframe, start_date, end_date):
    # Your chart data calculation code here
    pass

@CacheManager.cache_key('insights')
def get_user_insights(user_id):
    # Your insights calculation code here
    pass
"""
