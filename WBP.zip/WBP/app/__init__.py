"""Initialize Flask application."""

import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from config import config

# Initialize Flask extensions
db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'

def create_app(config_name=None):
    """Application factory function."""
    app = Flask(__name__)
    
    # Get config from environment or use default
    if config_name is None:
        config_name = os.getenv('FLASK_ENV', 'development')
    
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    
    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    
    # Register blueprints
    from app.routes.main import main
    from app.routes.admin import admin
    from app.routes.worker import worker
    from app.routes.auth import auth
    
    app.register_blueprint(main)
    app.register_blueprint(admin)
    app.register_blueprint(worker)
    app.register_blueprint(auth)
    
    return app
