"""Configuration settings for the application."""

import os
from typing import Dict, Any

# Environment
ENVIRONMENT = os.getenv('ENVIRONMENT', 'development')

# Database
DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://localhost/bengabcom')

# MTN Mobile Money Configuration
MTN_API_KEY = os.getenv('MTN_API_KEY', '')
MTN_API_SECRET = os.getenv('MTN_API_SECRET', '')
MTN_ENVIRONMENT = os.getenv('MTN_ENVIRONMENT', 'sandbox')

# Airtel Money Configuration
AIRTEL_CLIENT_ID = os.getenv('AIRTEL_CLIENT_ID', '')
AIRTEL_CLIENT_SECRET = os.getenv('AIRTEL_CLIENT_SECRET', '')
AIRTEL_ENVIRONMENT = os.getenv('AIRTEL_ENVIRONMENT', 'sandbox')

# Vodafone Cash Configuration
VODAFONE_MERCHANT_ID = os.getenv('VODAFONE_MERCHANT_ID', '')
VODAFONE_API_KEY = os.getenv('VODAFONE_API_KEY', '')
VODAFONE_ENVIRONMENT = os.getenv('VODAFONE_ENVIRONMENT', 'sandbox')
VODAFONE_CALLBACK_BASE_URL = os.getenv('VODAFONE_CALLBACK_BASE_URL', 'https://api.bengabcom.com')

# Payment Provider Settings
PAYMENT_PROVIDERS: Dict[str, Any] = {
    'mtn': {
        'name': 'MTN Mobile Money',
        'code': 'mtn',
        'enabled': True,
        'prefixes': ['024', '054', '055', '059'],
        'min_amount': 1.0,
        'max_amount': 10000.0,
        'currency': 'GHS'
    },
    'airtel': {
        'name': 'Airtel Money',
        'code': 'airtel',
        'enabled': True,
        'prefixes': ['026', '056'],
        'min_amount': 1.0,
        'max_amount': 10000.0,
        'currency': 'GHS'
    },
    'vodafone': {
        'name': 'Vodafone Cash',
        'code': 'vodafone',
        'enabled': True,
        'prefixes': ['020', '050'],
        'min_amount': 1.0,
        'max_amount': 10000.0,
        'currency': 'GHS'
    }
}

# Security
SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-here')
JWT_SECRET_KEY = os.getenv('JWT_SECRET_KEY', 'your-jwt-secret-key-here')
JWT_ACCESS_TOKEN_EXPIRES = 3600  # 1 hour

# API Settings
API_VERSION = 'v1'
API_PREFIX = f'/api/{API_VERSION}'
DEBUG = ENVIRONMENT == 'development'
TESTING = ENVIRONMENT == 'testing'

# Logging Configuration
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

# Redis Configuration (for caching and session management)
REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/0')

# Email Configuration
SMTP_SERVER = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
SMTP_PORT = int(os.getenv('SMTP_PORT', '587'))
SMTP_USERNAME = os.getenv('SMTP_USERNAME', '')
SMTP_PASSWORD = os.getenv('SMTP_PASSWORD', '')
MAIL_DEFAULT_SENDER = os.getenv('MAIL_DEFAULT_SENDER', 'noreply@bengabcom.com')

# SMS Configuration
SMS_PROVIDER = os.getenv('SMS_PROVIDER', 'twilio')
SMS_API_KEY = os.getenv('SMS_API_KEY', '')
SMS_API_SECRET = os.getenv('SMS_API_SECRET', '')
SMS_SENDER_ID = os.getenv('SMS_SENDER_ID', 'Bengabcom')
