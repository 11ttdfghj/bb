"""Authentication routes."""

from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, login_required
from app.models.user import User
from app import db

auth = Blueprint('auth', __name__)

@auth.route('/login', methods=['GET', 'POST'])
def login():
    """Login page."""
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False
        
        user = User.query.filter_by(email=email).first()
        
        if not user or not user.check_password(password):
            flash('Please check your login details and try again.')
            return redirect(url_for('auth.login'))
        
        login_user(user, remember=remember)
        
        # Redirect admin users to admin dashboard
        if user.is_admin:
            return redirect(url_for('admin.dashboard'))
        # Redirect workers to their tasks
        return redirect(url_for('worker.tasks'))
    
    return render_template('auth/login.html')

@auth.route('/logout')
@login_required
def logout():
    """Logout route."""
    logout_user()
    return redirect(url_for('main.index'))

# Create initial admin user if not exists
def init_admin():
    """Create initial admin user."""
    admin = User.query.filter_by(email='reginaldagyemang9@gmail.com').first()
    if not admin:
        admin = User(
            email='reginaldagyemang9@gmail.com',
            name='Admin',
            role='admin',
            is_admin=True
        )
        admin.set_password('Avfrancis22')
        db.session.add(admin)
        db.session.commit()
