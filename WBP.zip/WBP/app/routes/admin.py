"""Admin routes for task management."""

from datetime import datetime
from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash
from flask_login import login_required, current_user
from app.models.task import Task, TaskComment
from app.models.user import User
from app.services.task_service import TaskService
from app import db

admin = Blueprint('admin', __name__, url_prefix='/admin')

@admin.route('/dashboard')
@login_required
def dashboard():
    """Admin dashboard."""
    if not current_user.is_admin:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('main.index'))
    
    # Get tasks
    pending_tasks = Task.query.filter_by(status='pending').all()
    completed_tasks = Task.query.filter_by(status='completed').all()
    
    # Get workers (non-admin users)
    workers = User.query.filter_by(role='worker').all()
    
    return render_template('admin/dashboard.html',
                         pending_tasks=pending_tasks,
                         completed_tasks=completed_tasks,
                         workers=workers)

@admin.route('/tasks', methods=['POST'])
@login_required
def create_task():
    """Create new task."""
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    try:
        data = request.form
        success, result = TaskService.create_task(
            title=data['title'],
            description=data.get('description'),
            assigned_to_id=int(data['assigned_to']),
            assigned_by_id=current_user.id,
            due_date=datetime.strptime(data['due_date'], '%Y-%m-%d'),
            priority=data.get('priority', 'medium')
        )
        
        if success:
            flash('Task created successfully', 'success')
            return redirect(url_for('admin.dashboard'))
        else:
            flash(f'Error creating task: {result}', 'danger')
            return redirect(url_for('admin.dashboard'))
            
    except Exception as e:
        flash(f'Error creating task: {str(e)}', 'danger')
        return redirect(url_for('admin.dashboard'))

@admin.route('/tasks/<int:task_id>', methods=['GET'])
@login_required
def get_task(task_id):
    """Get task details."""
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    task = Task.query.get_or_404(task_id)
    comments = TaskComment.query.filter_by(task_id=task_id).order_by(TaskComment.created_at.desc()).all()
    
    return jsonify({
        'task': {
            'id': task.id,
            'title': task.title,
            'description': task.description,
            'assigned_to': {
                'id': task.assigned_to.id,
                'name': task.assigned_to.name
            },
            'due_date': task.due_date.strftime('%Y-%m-%d'),
            'priority': task.priority,
            'status': task.status
        },
        'comments': [{
            'id': comment.id,
            'comment': comment.comment,
            'created_at': comment.created_at.strftime('%Y-%m-%d %H:%M'),
            'user': {
                'id': comment.user.id,
                'name': comment.user.name
            }
        } for comment in comments]
    })

@admin.route('/tasks/<int:task_id>/comments', methods=['POST'])
@login_required
def add_comment(task_id):
    """Add comment to task."""
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    success, result = TaskService.add_comment(
        task_id=task_id,
        user_id=current_user.id,
        comment_text=data['comment']
    )
    
    if success:
        return jsonify({
            'id': result.id,
            'comment': result.comment,
            'created_at': result.created_at.strftime('%Y-%m-%d %H:%M'),
            'user': {
                'id': result.user.id,
                'name': result.user.name
            }
        })
    else:
        return jsonify({'error': result}), 400

@admin.route('/tasks/<int:task_id>/status', methods=['PUT'])
@login_required
def update_task_status(task_id):
    """Update task status."""
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    success, result = TaskService.update_task_status(
        task_id=task_id,
        status=data['status'],
        user_id=current_user.id
    )
    
    if success:
        return jsonify({
            'id': result.id,
            'status': result.status
        })
    else:
        return jsonify({'error': result}), 400
