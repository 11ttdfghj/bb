"""Worker routes for task management."""

from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash
from flask_login import login_required, current_user
from app.models.task import Task, TaskComment
from app.services.task_service import TaskService
from app import db

worker = Blueprint('worker', __name__, url_prefix='/worker')

@worker.route('/tasks')
@login_required
def tasks():
    """Worker's task list."""
    if current_user.is_admin:
        return redirect(url_for('admin.dashboard'))
    
    # Get tasks assigned to worker
    pending_tasks = Task.query.filter_by(
        assigned_to_id=current_user.id,
        status='pending'
    ).order_by(Task.due_date.asc()).all()
    
    completed_tasks = Task.query.filter_by(
        assigned_to_id=current_user.id,
        status='completed'
    ).order_by(Task.updated_at.desc()).all()
    
    return render_template('worker/tasks.html',
                         pending_tasks=pending_tasks,
                         completed_tasks=completed_tasks)

@worker.route('/tasks/<int:task_id>/status', methods=['PUT'])
@login_required
def update_task_status(task_id):
    """Update task status."""
    task = Task.query.get_or_404(task_id)
    
    # Check if task is assigned to current worker
    if task.assigned_to_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    success, result = TaskService.update_task_status(
        task_id=task_id,
        status=data['status'],
        user_id=current_user.id
    )
    
    if success:
        return jsonify({
            'id': result.id,
            'status': result.status
        })
    else:
        return jsonify({'error': result}), 400

@worker.route('/tasks/<int:task_id>/comments', methods=['POST'])
@login_required
def add_comment(task_id):
    """Add comment to task."""
    task = Task.query.get_or_404(task_id)
    
    # Check if task is assigned to current worker
    if task.assigned_to_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    success, result = TaskService.add_comment(
        task_id=task_id,
        user_id=current_user.id,
        comment_text=data['comment']
    )
    
    if success:
        return jsonify({
            'id': result.id,
            'comment': result.comment,
            'created_at': result.created_at.strftime('%Y-%m-%d %H:%M'),
            'user': {
                'id': result.user.id,
                'name': result.user.name
            }
        })
    else:
        return jsonify({'error': result}), 400
