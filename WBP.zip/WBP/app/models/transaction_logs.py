"""Database models for transaction logging."""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Text
from sqlalchemy.dialects.postgresql import JSONB
from app.database import Base

class TransactionLog(Base):
    """Model for payment transaction logs."""
    
    __tablename__ = 'transaction_logs'
    
    id = Column(Integer, primary_key=True)
    transaction_type = Column(String(50), nullable=False)  # deposit, withdrawal
    provider = Column(String(50), nullable=False)  # mtn, airtel, vodafone
    amount = Column(Float, nullable=False)
    wallet_number = Column(String(20), nullable=False)
    status = Column(String(50), nullable=False)  # pending, completed, failed
    reference = Column(String(100), nullable=False, unique=True)
    metadata = Column(JSONB, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        """Convert model to dictionary."""
        return {
            'id': self.id,
            'transaction_type': self.transaction_type,
            'provider': self.provider,
            'amount': self.amount,
            'wallet_number': self.wallet_number,
            'status': self.status,
            'reference': self.reference,
            'metadata': self.metadata,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

class WebhookLog(Base):
    """Model for webhook callback logs."""
    
    __tablename__ = 'webhook_logs'
    
    id = Column(Integer, primary_key=True)
    provider = Column(String(50), nullable=False)  # mtn, airtel, vodafone
    event_type = Column(String(100), nullable=False)
    transaction_id = Column(String(100), nullable=False)
    status = Column(String(50), nullable=False)
    payload = Column(JSONB, nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    
    def to_dict(self):
        """Convert model to dictionary."""
        return {
            'id': self.id,
            'provider': self.provider,
            'event_type': self.event_type,
            'transaction_id': self.transaction_id,
            'status': self.status,
            'payload': self.payload,
            'created_at': self.created_at.isoformat()
        }
