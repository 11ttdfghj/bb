"""User model for authentication."""

from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, login_manager

class User(UserMixin, db.Model):
    """User model."""
    
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    password_hash = db.Column(db.String(128))
    role = db.Column(db.String(20), default='worker')  # 'admin' or 'worker'
    is_admin = db.Column(db.Boolean, default=False)
    
    # Relationships
    tasks_assigned = db.relationship('Task', backref='assigned_to', foreign_keys='Task.assigned_to_id')
    tasks_created = db.relationship('Task', backref='assigned_by', foreign_keys='Task.assigned_by_id')
    comments = db.relationship('TaskComment', backref='user')
    
    def set_password(self, password):
        """Set password."""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check password."""
        return check_password_hash(self.password_hash, password)

@login_manager.user_loader
def load_user(id):
    """Load user by ID."""
    return User.query.get(int(id))
