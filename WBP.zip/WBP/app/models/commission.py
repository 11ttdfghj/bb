"""Commission settings and deduction models."""

from datetime import datetime
from app import db

class CommissionSettings(db.Model):
    """Commission settings model."""
    
    __tablename__ = 'commission_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    rate = db.Column(db.Float, nullable=False, default=0.0)  # Commission rate as percentage
    frequency = db.Column(db.Integer, nullable=False, default=30)  # Days between deductions
    min_balance = db.Column(db.Float, nullable=False, default=0.0)  # Minimum balance for deduction
    last_run = db.Column(db.DateTime, nullable=True)  # Last deduction run
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Relationships
    created_by = db.relationship('User', backref='commission_settings')
    deductions = db.relationship('CommissionDeduction', backref='settings', lazy=True)

class CommissionDeduction(db.Model):
    """Commission deduction records."""
    
    __tablename__ = 'commission_deductions'
    
    id = db.Column(db.Integer, primary_key=True)
    settings_id = db.Column(db.Integer, db.ForeignKey('commission_settings.id'), nullable=False)
    account_id = db.Column(db.Integer, db.ForeignKey('accounts.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    balance_before = db.Column(db.Float, nullable=False)
    balance_after = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='pending')
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    
    # Relationships
    account = db.relationship('Account', backref='commission_deductions')
