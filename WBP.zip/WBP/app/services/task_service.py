"""Task management service."""

from datetime import datetime
from app import db
from app.models.task import Task, TaskComment
from app.models.user import User

class TaskService:
    """Service for managing tasks."""
    
    @staticmethod
    def create_task(title, description, assigned_to_id, assigned_by_id, due_date, priority='medium'):
        """Create a new task."""
        try:
            task = Task(
                title=title,
                description=description,
                assigned_to_id=assigned_to_id,
                assigned_by_id=assigned_by_id,
                due_date=due_date,
                priority=priority,
                status='pending'
            )
            
            db.session.add(task)
            db.session.commit()
            return True, task
        except Exception as e:
            db.session.rollback()
            return False, str(e)
    
    @staticmethod
    def update_task_status(task_id, status, user_id):
        """Update task status."""
        try:
            task = Task.query.get(task_id)
            if not task:
                return False, "Task not found"
                
            if task.assigned_to_id != user_id and task.assigned_by_id != user_id:
                return False, "Unauthorized to update task"
                
            task.status = status
            task.updated_at = datetime.utcnow()
            
            db.session.commit()
            return True, task
        except Exception as e:
            db.session.rollback()
            return False, str(e)
    
    @staticmethod
    def add_comment(task_id, user_id, comment_text):
        """Add comment to task."""
        try:
            task = Task.query.get(task_id)
            if not task:
                return False, "Task not found"
            
            comment = TaskComment(
                task_id=task_id,
                user_id=user_id,
                comment=comment_text
            )
            
            db.session.add(comment)
            db.session.commit()
            return True, comment
        except Exception as e:
            db.session.rollback()
            return False, str(e)
    
    @staticmethod
    def get_user_tasks(user_id, status=None):
        """Get tasks assigned to user."""
        query = Task.query.filter_by(assigned_to_id=user_id)
        if status:
            query = query.filter_by(status=status)
        return query.order_by(Task.due_date.asc()).all()
    
    @staticmethod
    def get_created_tasks(user_id, status=None):
        """Get tasks created by user."""
        query = Task.query.filter_by(assigned_by_id=user_id)
        if status:
            query = query.filter_by(status=status)
        return query.order_by(Task.created_at.desc()).all()
