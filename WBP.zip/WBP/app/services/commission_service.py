"""Commission service for automated deductions."""

from datetime import datetime, timedelta
from sqlalchemy import and_
from app import db
from app.models.commission import CommissionSettings, CommissionDeduction
from app.models.account import Account

class CommissionService:
    """Service for handling commission deductions."""
    
    @staticmethod
    def process_commission_deductions():
        """Process commission deductions for all eligible accounts."""
        settings = CommissionSettings.query.first()
        if not settings:
            return "No commission settings found"
            
        # Check if it's time for deduction
        if settings.last_run:
            days_since_last_run = (datetime.utcnow() - settings.last_run).days
            if days_since_last_run < settings.frequency:
                return f"Next deduction in {settings.frequency - days_since_last_run} days"
        
        # Get eligible accounts
        eligible_accounts = Account.query.filter(
            and_(
                Account.status == 'active',
                Account.balance >= settings.min_balance
            )
        ).all()
        
        deductions_processed = 0
        for account in eligible_accounts:
            try:
                # Calculate commission
                commission_amount = (account.balance * settings.rate) / 100
                
                # Create deduction record
                deduction = CommissionDeduction(
                    settings_id=settings.id,
                    account_id=account.id,
                    amount=commission_amount,
                    balance_before=account.balance,
                    balance_after=account.balance - commission_amount,
                    status='completed'
                )
                
                # Update account balance
                account.balance -= commission_amount
                
                db.session.add(deduction)
                deductions_processed += 1
                
            except Exception as e:
                db.session.rollback()
                continue
        
        if deductions_processed > 0:
            # Update last run time
            settings.last_run = datetime.utcnow()
            try:
                db.session.commit()
                return f"Successfully processed {deductions_processed} commission deductions"
            except Exception as e:
                db.session.rollback()
                return f"Error committing transactions: {str(e)}"
        
        return "No eligible accounts found for commission deduction"

    @staticmethod
    def update_settings(rate, frequency, min_balance, user_id):
        """Update commission settings."""
        settings = CommissionSettings.query.first()
        if not settings:
            settings = CommissionSettings(
                rate=rate,
                frequency=frequency,
                min_balance=min_balance,
                created_by_id=user_id
            )
            db.session.add(settings)
        else:
            settings.rate = rate
            settings.frequency = frequency
            settings.min_balance = min_balance
            settings.updated_at = datetime.utcnow()
        
        try:
            db.session.commit()
            return True, "Commission settings updated successfully"
        except Exception as e:
            db.session.rollback()
            return False, f"Error updating commission settings: {str(e)}"
